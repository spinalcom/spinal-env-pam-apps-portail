declare module "spinal-components" {
  import SpinalComponents from "spinal-components";
  export default SpinalComponents;
}
declare module "axios";

declare module "*";
