module.exports = {
  steps: {
    closed: ["Archived", "Refusée", "Clôturée", "Fermé"],
  },
  workflowList: [
    "Ticket Mission",
    "Ticket Mamady",
    "Workflow test",
    "Demande d'intervention",
  ],
};
