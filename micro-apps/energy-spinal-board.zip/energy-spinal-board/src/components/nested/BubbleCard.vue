<template>
    <v-card @click="toto()" style="min-height: 220px !important" class="bar-card pa-1 rounded-lg d-flex flex-column"
        outlined>
        <v-card-title style="font-size: 20px; height: 56px" class="card-title pa-3 text-uppercase justify-space-between">
            <p>{{ title }}</p>
            <div v-if="navEnabled" style="height: 40px">
                <v-btn @click="$emit('nav', -1)" style="
              font-size: 14px !important;
              border-radius: 10px;
              min-width: 36px !important;
              box-shadow: none;
            ">
                    <v-icon icon>mdi-chevron-left</v-icon>
                </v-btn>
                {{ navText }}
                <v-btn @click="$emit('nav', +1)" style="
              font-size: 14px !important;
              border-radius: 10px;
              min-width: 36px !important;
              box-shadow: none;
            ">
                    <v-icon icon>mdi-chevron-right</v-icon>
                </v-btn>
            </div>
        </v-card-title>
        <div style="height: calc(100% - 56px)" class="d-flex flex-column">
            <slot name="extras" class="flex-shrink-1"></slot>
            <div id="bar-legend-container" class="d-flex flex-row justify-space-between"
                style="height: 81px ; transform: translate(0, 60%);"></div>
            <div style="height: calc(100% - 21px)">
                <Scatter style="width: 100% !important;position: relative;" :data="bubbleChartData"
                    :options="bubbleChartOptions" />
            </div>
        </div>
    </v-card>
</template>
  
<script>
const fs = require('fs');
import { Scatter } from "vue-chartjs";
import {
    customBackgroundPlugin,
    customLegendPlugin,
} from "../../plugins/canvasPlugins";
import {
    Legend,
    BarElement,
    LinearScale,
    CategoryScale,
    LogarithmicScale,
    Chart as ChartJS,
} from "chart.js";
import {
    defaultColor,
    gradiant,
    RGBtoHexa,
    HSVtoRGB,
    hexaToRGB,
} from "../colors";

ChartJS.register(
    Legend,
    BarElement,
    CategoryScale,
    LinearScale,
    LogarithmicScale,
    customBackgroundPlugin,
    customLegendPlugin
);

export default {
    name: "bar-card",
    components: {
        Scatter
    },
    props: {
        title: {
            type: String,
            default: "Bubble Card",
        },
        data1: {
            type: Array,
            default: () => [],
        },
        data2: {
            type: Array,
            default: () => [],
        },
    },
    data() {
        return {
            bubbleChartData: generateBubbleData(this.data1[0].data, this.data2[0].data)
            // bubbleChartData: {
            //     datasets: [
            //         {
            //             label: 'Point 1',
            //             data: [
            //                 { x: 10, y: 20, r: 5 }
            //             ],
            //             backgroundColor: 'rgba(255, 99, 132, 0.2)',
            //             borderColor: 'rgba(255, 99, 132, 1)',
            //             borderWidth: 1,
            //         },
            //         {
            //             label: 'Point 2',
            //             data: [
            //                 { x: 15, y: 25, r: 15 }
            //             ],
            //             backgroundColor: 'rgba(54, 162, 235, 0.2)',
            //             borderColor: 'rgba(54, 162, 235, 1)',
            //             borderWidth: 1,
            //         },
            //         {
            //             label: 'Point 2',
            //             data: [
            //                 { x: 12, y: 22, r: 15 }
            //             ],
            //             backgroundColor: 'rgba(54, 162, 235, 0.2)',
            //             borderColor: 'rgba(54, 162, 235, 1)',
            //             borderWidth: 1,
            //         },
            //         {
            //             label: 'Point 2',
            //             data: [
            //                 { x: 12, y: 22, r: 15 }
            //             ],
            //             backgroundColor: 'rgba(54, 162, 235, 0.2)',
            //             borderColor: 'rgba(54, 162, 235, 1)',
            //             borderWidth: 1,
            //         },
            //         // ... ajoutez d'autres points si nécessaire
            //     ]
            // }
        };
    },
    methods: {



        generateBubbleData(a, b) {
            let data = [
                {
                    "date": 1681311600000,
                    "value": 106,
                    "value2": 21.09
                },
                {
                    "date": 1681398000000,
                    "value": 84,
                    "value2": 24.830000000000002
                },
                {
                    "date": 1681401600000,
                    "value": 99.875,
                    "value2": 13.74
                },
                {
                    "date": 1681412400000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1681416000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1681419600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1681423200000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1681430400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1681434000000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1681437600000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1681441200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1681444800000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1681448400000,
                    "value": 87.125,
                    "value2": 0
                },
                {
                    "date": 1681452000000,
                    "value": 122.875,
                    "value2": 0
                },
                {
                    "date": 1681455600000,
                    "value": 136.125,
                    "value2": 6.91
                },
                {
                    "date": 1681459200000,
                    "value": 121.125,
                    "value2": 14.31
                },
                {
                    "date": 1681462800000,
                    "value": 126,
                    "value2": 14.77
                },
                {
                    "date": 1681466400000,
                    "value": 114.875,
                    "value2": 13.91
                },
                {
                    "date": 1681470000000,
                    "value": 118,
                    "value2": 9.600000000000001
                },
                {
                    "date": 1681473600000,
                    "value": 114.125,
                    "value2": 11.31
                },
                {
                    "date": 1681477200000,
                    "value": 118,
                    "value2": 13
                },
                {
                    "date": 1681491600000,
                    "value": 97,
                    "value2": 0
                },
                {
                    "date": 1681498800000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1681502400000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1681506000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1681509600000,
                    "value": 53,
                    "value2": 0
                },
                {
                    "date": 1681516800000,
                    "value": 59.125,
                    "value2": 0
                },
                {
                    "date": 1681520400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1681524000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1681527600000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1681531200000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1681534800000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1681538400000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1681542000000,
                    "value": 62.875,
                    "value2": 0.09
                },
                {
                    "date": 1681545600000,
                    "value": 66,
                    "value2": 0.03
                },
                {
                    "date": 1681549200000,
                    "value": 55.875,
                    "value2": 0.03
                },
                {
                    "date": 1681552800000,
                    "value": 59,
                    "value2": 0.06
                },
                {
                    "date": 1681556400000,
                    "value": 49,
                    "value2": 0.06
                },
                {
                    "date": 1681560000000,
                    "value": 38.875,
                    "value2": 0.03
                },
                {
                    "date": 1681563600000,
                    "value": 19.875,
                    "value2": 0
                },
                {
                    "date": 1681567200000,
                    "value": 46.125,
                    "value2": 0
                },
                {
                    "date": 1681570800000,
                    "value": 24,
                    "value2": 0.03
                },
                {
                    "date": 1681574400000,
                    "value": 27.875,
                    "value2": 0.03
                },
                {
                    "date": 1681578000000,
                    "value": 20.875,
                    "value2": 0.09
                },
                {
                    "date": 1681581600000,
                    "value": 49,
                    "value2": 0.09
                },
                {
                    "date": 1681585200000,
                    "value": 59,
                    "value2": 0.09
                },
                {
                    "date": 1681588800000,
                    "value": 61.125,
                    "value2": 0.09
                },
                {
                    "date": 1681592400000,
                    "value": 59,
                    "value2": 0.09
                },
                {
                    "date": 1681596000000,
                    "value": 54,
                    "value2": 0.09
                },
                {
                    "date": 1681603200000,
                    "value": 59,
                    "value2": 0.09
                },
                {
                    "date": 1681606800000,
                    "value": 61,
                    "value2": 0.09
                },
                {
                    "date": 1681610400000,
                    "value": 60.875,
                    "value2": 0.09
                },
                {
                    "date": 1681614000000,
                    "value": 63,
                    "value2": 0.09
                },
                {
                    "date": 1681617600000,
                    "value": 62.125,
                    "value2": 0.09
                },
                {
                    "date": 1681621200000,
                    "value": 60.875,
                    "value2": 0.09
                },
                {
                    "date": 1681624800000,
                    "value": 60,
                    "value2": 0.09
                },
                {
                    "date": 1681628400000,
                    "value": 56.875,
                    "value2": 0.06
                },
                {
                    "date": 1681632000000,
                    "value": 52.125,
                    "value2": 0.06
                },
                {
                    "date": 1681635600000,
                    "value": 20,
                    "value2": 0.06
                },
                {
                    "date": 1681639200000,
                    "value": 1,
                    "value2": 0.06
                },
                {
                    "date": 1681642800000,
                    "value": 0,
                    "value2": 0.09
                },
                {
                    "date": 1681646400000,
                    "value": 0,
                    "value2": 0.03
                },
                {
                    "date": 1681650000000,
                    "value": 0,
                    "value2": 0.03
                },
                {
                    "date": 1681653600000,
                    "value": 0,
                    "value2": 0.06
                },
                {
                    "date": 1681657200000,
                    "value": 1.125,
                    "value2": 0.06
                },
                {
                    "date": 1681660800000,
                    "value": 7,
                    "value2": 0.06
                },
                {
                    "date": 1681664400000,
                    "value": 22.875,
                    "value2": 0.06
                },
                {
                    "date": 1681668000000,
                    "value": 49,
                    "value2": 0.06
                },
                {
                    "date": 1681671600000,
                    "value": 60.875,
                    "value2": 0.06
                },
                {
                    "date": 1681675200000,
                    "value": 62.125,
                    "value2": 0.06
                },
                {
                    "date": 1681678800000,
                    "value": 59.875,
                    "value2": 0.06
                },
                {
                    "date": 1681682400000,
                    "value": 54.875,
                    "value2": 0.06
                },
                {
                    "date": 1681689600000,
                    "value": 82.125,
                    "value2": 0.06
                },
                {
                    "date": 1681693200000,
                    "value": 81.875,
                    "value2": 0.06
                },
                {
                    "date": 1681696800000,
                    "value": 82.875,
                    "value2": 0.06
                },
                {
                    "date": 1681700400000,
                    "value": 87.875,
                    "value2": 0.06
                },
                {
                    "date": 1681704000000,
                    "value": 87.875,
                    "value2": 0.06
                },
                {
                    "date": 1681707600000,
                    "value": 90,
                    "value2": 0.06
                },
                {
                    "date": 1681711200000,
                    "value": 114.125,
                    "value2": 0.06
                },
                {
                    "date": 1681714800000,
                    "value": 121,
                    "value2": 14.89
                },
                {
                    "date": 1681718400000,
                    "value": 131.125,
                    "value2": 33.83
                },
                {
                    "date": 1681722000000,
                    "value": 139,
                    "value2": 34.54
                },
                {
                    "date": 1681725600000,
                    "value": 126.125,
                    "value2": 33.11
                },
                {
                    "date": 1681729200000,
                    "value": 121.125,
                    "value2": 20.91
                },
                {
                    "date": 1681732800000,
                    "value": 123.875,
                    "value2": 24.310000000000002
                },
                {
                    "date": 1681736400000,
                    "value": 127,
                    "value2": 26.26
                },
                {
                    "date": 1681740000000,
                    "value": 130.125,
                    "value2": 23.57
                },
                {
                    "date": 1681743600000,
                    "value": 126,
                    "value2": 15.31
                },
                {
                    "date": 1681747200000,
                    "value": 124,
                    "value2": 1.29
                },
                {
                    "date": 1681754400000,
                    "value": 84.125,
                    "value2": 0
                },
                {
                    "date": 1681758000000,
                    "value": 71.125,
                    "value2": 0
                },
                {
                    "date": 1681761600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1681765200000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1681768800000,
                    "value": 53,
                    "value2": 0
                },
                {
                    "date": 1681776000000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1681779600000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1681783200000,
                    "value": 58.875,
                    "value2": 0
                },
                {
                    "date": 1681786800000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1681790400000,
                    "value": 68.875,
                    "value2": 0
                },
                {
                    "date": 1681794000000,
                    "value": 86,
                    "value2": 0
                },
                {
                    "date": 1681797600000,
                    "value": 124.125,
                    "value2": 0
                },
                {
                    "date": 1681801200000,
                    "value": 136.875,
                    "value2": 17.57
                },
                {
                    "date": 1681804800000,
                    "value": 138.875,
                    "value2": 39.660000000000004
                },
                {
                    "date": 1681808400000,
                    "value": 134,
                    "value2": 43.230000000000004
                },
                {
                    "date": 1681812000000,
                    "value": 93.875,
                    "value2": 41.89
                },
                {
                    "date": 1681815600000,
                    "value": 83.875,
                    "value2": 29.34
                },
                {
                    "date": 1681819200000,
                    "value": 96.875,
                    "value2": 34.34
                },
                {
                    "date": 1681822800000,
                    "value": 103,
                    "value2": 37.63
                },
                {
                    "date": 1681830000000,
                    "value": 108.875,
                    "value2": 24.17
                },
                {
                    "date": 1681833600000,
                    "value": 130.125,
                    "value2": 5
                },
                {
                    "date": 1681840800000,
                    "value": 84.125,
                    "value2": 0
                },
                {
                    "date": 1681844400000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1681848000000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1681851600000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1681855200000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1681862400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1681866000000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1681869600000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1681873200000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1681876800000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1681880400000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1681884000000,
                    "value": 109.125,
                    "value2": 0
                },
                {
                    "date": 1681887600000,
                    "value": 123,
                    "value2": 13.8
                },
                {
                    "date": 1682002800000,
                    "value": 104.125,
                    "value2": 15.83
                },
                {
                    "date": 1682006400000,
                    "value": 117,
                    "value2": 4.91
                },
                {
                    "date": 1682017200000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1682020800000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1682024400000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1682028000000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1682035200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682038800000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682042400000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1682046000000,
                    "value": 65.125,
                    "value2": 0
                },
                {
                    "date": 1682049600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1682053200000,
                    "value": 83.875,
                    "value2": 0
                },
                {
                    "date": 1682056800000,
                    "value": 108,
                    "value2": 0
                },
                {
                    "date": 1682060400000,
                    "value": 118,
                    "value2": 5.3100000000000005
                },
                {
                    "date": 1682064000000,
                    "value": 119,
                    "value2": 10.600000000000001
                },
                {
                    "date": 1682067600000,
                    "value": 116,
                    "value2": 11.49
                },
                {
                    "date": 1682071200000,
                    "value": 114.125,
                    "value2": 10.290000000000001
                },
                {
                    "date": 1682074800000,
                    "value": 98.875,
                    "value2": 5.7700000000000005
                },
                {
                    "date": 1682078400000,
                    "value": 105.875,
                    "value2": 6.69
                },
                {
                    "date": 1682082000000,
                    "value": 96,
                    "value2": 7.46
                },
                {
                    "date": 1682085600000,
                    "value": 99.125,
                    "value2": 5.97
                },
                {
                    "date": 1682089200000,
                    "value": 86,
                    "value2": 2.0300000000000002
                },
                {
                    "date": 1682092800000,
                    "value": 91,
                    "value2": 0.03
                },
                {
                    "date": 1682100000000,
                    "value": 72.125,
                    "value2": 0
                },
                {
                    "date": 1682103600000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1682107200000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1682110800000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1682114400000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1682121600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1682125200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682128800000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1682132400000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1682136000000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1682139600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1682143200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1682146800000,
                    "value": 62.875,
                    "value2": 0.11
                },
                {
                    "date": 1682150400000,
                    "value": 64,
                    "value2": 0.14
                },
                {
                    "date": 1682154000000,
                    "value": 64,
                    "value2": 0.09
                },
                {
                    "date": 1682157600000,
                    "value": 55.875,
                    "value2": 0.09
                },
                {
                    "date": 1682161200000,
                    "value": 43,
                    "value2": 0.06
                },
                {
                    "date": 1682164800000,
                    "value": 25,
                    "value2": 0.09
                },
                {
                    "date": 1682168400000,
                    "value": 28.875,
                    "value2": 0.06
                },
                {
                    "date": 1682172000000,
                    "value": 2,
                    "value2": 0
                },
                {
                    "date": 1682175600000,
                    "value": 4,
                    "value2": 0.03
                },
                {
                    "date": 1682179200000,
                    "value": 20.125,
                    "value2": 0.09
                },
                {
                    "date": 1682186400000,
                    "value": 28,
                    "value2": 0.11
                },
                {
                    "date": 1682190000000,
                    "value": 57,
                    "value2": 0.11
                },
                {
                    "date": 1682193600000,
                    "value": 57,
                    "value2": 0.11
                },
                {
                    "date": 1682197200000,
                    "value": 59.875,
                    "value2": 0.11
                },
                {
                    "date": 1682200800000,
                    "value": 53,
                    "value2": 0.11
                },
                {
                    "date": 1682208000000,
                    "value": 57.125,
                    "value2": 0.11
                },
                {
                    "date": 1682211600000,
                    "value": 57,
                    "value2": 0.11
                },
                {
                    "date": 1682215200000,
                    "value": 60,
                    "value2": 0.11
                },
                {
                    "date": 1682218800000,
                    "value": 59,
                    "value2": 0.11
                },
                {
                    "date": 1682222400000,
                    "value": 59,
                    "value2": 0.11
                },
                {
                    "date": 1682226000000,
                    "value": 59,
                    "value2": 0.11
                },
                {
                    "date": 1682229600000,
                    "value": 58,
                    "value2": 0.11
                },
                {
                    "date": 1682233200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682236800000,
                    "value": 57.875,
                    "value2": 0
                },
                {
                    "date": 1682240400000,
                    "value": 42,
                    "value2": 0
                },
                {
                    "date": 1682244000000,
                    "value": 15,
                    "value2": 0
                },
                {
                    "date": 1682247600000,
                    "value": 30,
                    "value2": 0
                },
                {
                    "date": 1682251200000,
                    "value": 43,
                    "value2": 0
                },
                {
                    "date": 1682254800000,
                    "value": 35.875,
                    "value2": 0.09
                },
                {
                    "date": 1682258400000,
                    "value": 28,
                    "value2": 0.06
                },
                {
                    "date": 1682262000000,
                    "value": 8.875,
                    "value2": 0.09
                },
                {
                    "date": 1682265600000,
                    "value": 18.125,
                    "value2": 0.09
                },
                {
                    "date": 1682272800000,
                    "value": 49.125,
                    "value2": 0.09
                },
                {
                    "date": 1682276400000,
                    "value": 56.875,
                    "value2": 0.09
                },
                {
                    "date": 1682280000000,
                    "value": 58,
                    "value2": 0.09
                },
                {
                    "date": 1682283600000,
                    "value": 60.125,
                    "value2": 0.09
                },
                {
                    "date": 1682287200000,
                    "value": 53,
                    "value2": 0.09
                },
                {
                    "date": 1682294400000,
                    "value": 82,
                    "value2": 0.09
                },
                {
                    "date": 1682298000000,
                    "value": 83.125,
                    "value2": 0.09
                },
                {
                    "date": 1682301600000,
                    "value": 84.125,
                    "value2": 0.09
                },
                {
                    "date": 1682305200000,
                    "value": 87.125,
                    "value2": 0.09
                },
                {
                    "date": 1682308800000,
                    "value": 87.125,
                    "value2": 0.09
                },
                {
                    "date": 1682312400000,
                    "value": 87.875,
                    "value2": 0.09
                },
                {
                    "date": 1682316000000,
                    "value": 122.125,
                    "value2": 0.09
                },
                {
                    "date": 1682319600000,
                    "value": 131,
                    "value2": 11.540000000000001
                },
                {
                    "date": 1682323200000,
                    "value": 123.875,
                    "value2": 29.26
                },
                {
                    "date": 1682326800000,
                    "value": 129,
                    "value2": 30.830000000000002
                },
                {
                    "date": 1682330400000,
                    "value": 113,
                    "value2": 42.62
                },
                {
                    "date": 1682334000000,
                    "value": 101,
                    "value2": 29.02
                },
                {
                    "date": 1682337600000,
                    "value": 86,
                    "value2": 34.25
                },
                {
                    "date": 1682344800000,
                    "value": 101.125,
                    "value2": 34.660000000000004
                },
                {
                    "date": 1682348400000,
                    "value": 96,
                    "value2": 23.22
                },
                {
                    "date": 1682359200000,
                    "value": 73.875,
                    "value2": 0.04
                },
                {
                    "date": 1682362800000,
                    "value": 70,
                    "value2": 0.04
                },
                {
                    "date": 1682366400000,
                    "value": 61.875,
                    "value2": 0.04
                },
                {
                    "date": 1682370000000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1682373600000,
                    "value": 55.125,
                    "value2": 0.04
                },
                {
                    "date": 1682380800000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1682384400000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1682388000000,
                    "value": 59,
                    "value2": 0.04
                },
                {
                    "date": 1682391600000,
                    "value": 63,
                    "value2": 0.04
                },
                {
                    "date": 1682395200000,
                    "value": 63,
                    "value2": 0.04
                },
                {
                    "date": 1682398800000,
                    "value": 85,
                    "value2": 0.04
                },
                {
                    "date": 1682402400000,
                    "value": 122.125,
                    "value2": 0.04
                },
                {
                    "date": 1682406000000,
                    "value": 136.125,
                    "value2": 23.18
                },
                {
                    "date": 1682409600000,
                    "value": 137,
                    "value2": 53.44
                },
                {
                    "date": 1682413200000,
                    "value": 141.875,
                    "value2": 57.42
                },
                {
                    "date": 1682416800000,
                    "value": 114.125,
                    "value2": 55.22
                },
                {
                    "date": 1682420400000,
                    "value": 113,
                    "value2": 37.94
                },
                {
                    "date": 1682424000000,
                    "value": 113.125,
                    "value2": 46.02
                },
                {
                    "date": 1682427600000,
                    "value": 114.875,
                    "value2": 49.79
                },
                {
                    "date": 1682431200000,
                    "value": 118,
                    "value2": 45.400000000000006
                },
                {
                    "date": 1682434800000,
                    "value": 114.875,
                    "value2": 34.410000000000004
                },
                {
                    "date": 1682438400000,
                    "value": 119.875,
                    "value2": 12.4
                },
                {
                    "date": 1682445600000,
                    "value": 75,
                    "value2": 0
                },
                {
                    "date": 1682449200000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1682452800000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1682456400000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1682460000000,
                    "value": 54,
                    "value2": 0
                },
                {
                    "date": 1682467200000,
                    "value": 58.875,
                    "value2": 0
                },
                {
                    "date": 1682470800000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682474400000,
                    "value": 58.875,
                    "value2": 0
                },
                {
                    "date": 1682478000000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1682481600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1682485200000,
                    "value": 84.125,
                    "value2": 0
                },
                {
                    "date": 1682488800000,
                    "value": 112,
                    "value2": 0
                },
                {
                    "date": 1682492400000,
                    "value": 120,
                    "value2": 18.82
                },
                {
                    "date": 1682496000000,
                    "value": 122.875,
                    "value2": 41.87
                },
                {
                    "date": 1682499600000,
                    "value": 116.125,
                    "value2": 46.1
                },
                {
                    "date": 1682503200000,
                    "value": 102,
                    "value2": 44.94
                },
                {
                    "date": 1682506800000,
                    "value": 96,
                    "value2": 30.8
                },
                {
                    "date": 1682510400000,
                    "value": 99.875,
                    "value2": 35.03
                },
                {
                    "date": 1682514000000,
                    "value": 110.125,
                    "value2": 39.88
                },
                {
                    "date": 1682517600000,
                    "value": 113,
                    "value2": 35.82
                },
                {
                    "date": 1682521200000,
                    "value": 112.875,
                    "value2": 26.53
                },
                {
                    "date": 1682524800000,
                    "value": 122,
                    "value2": 5.8500000000000005
                },
                {
                    "date": 1682532000000,
                    "value": 82,
                    "value2": 0.04
                },
                {
                    "date": 1682535600000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1682539200000,
                    "value": 55.875,
                    "value2": 0.04
                },
                {
                    "date": 1682542800000,
                    "value": 62.875,
                    "value2": 0.04
                },
                {
                    "date": 1682546400000,
                    "value": 54.125,
                    "value2": 0.04
                },
                {
                    "date": 1682553600000,
                    "value": 61.125,
                    "value2": 0.04
                },
                {
                    "date": 1682557200000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1682560800000,
                    "value": 57.875,
                    "value2": 0.04
                },
                {
                    "date": 1682564400000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1682568000000,
                    "value": 63,
                    "value2": 0.04
                },
                {
                    "date": 1682571600000,
                    "value": 85,
                    "value2": 0.04
                },
                {
                    "date": 1682575200000,
                    "value": 120.125,
                    "value2": 0.04
                },
                {
                    "date": 1682578800000,
                    "value": 113.875,
                    "value2": 18.95
                },
                {
                    "date": 1682582400000,
                    "value": 114.125,
                    "value2": 43.37
                },
                {
                    "date": 1682586000000,
                    "value": 103,
                    "value2": 45.730000000000004
                },
                {
                    "date": 1682589600000,
                    "value": 87,
                    "value2": 44.65
                },
                {
                    "date": 1682593200000,
                    "value": 76,
                    "value2": 24.830000000000002
                },
                {
                    "date": 1682596800000,
                    "value": 81,
                    "value2": 32.59
                },
                {
                    "date": 1682600400000,
                    "value": 90,
                    "value2": 35.82
                },
                {
                    "date": 1682604000000,
                    "value": 103.875,
                    "value2": 31.84
                },
                {
                    "date": 1682607600000,
                    "value": 115.875,
                    "value2": 23.13
                },
                {
                    "date": 1682611200000,
                    "value": 118,
                    "value2": 3.73
                },
                {
                    "date": 1682618400000,
                    "value": 79,
                    "value2": 0
                },
                {
                    "date": 1682622000000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1682625600000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1682629200000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1682632800000,
                    "value": 51.875,
                    "value2": 0
                },
                {
                    "date": 1682640000000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1682643600000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682647200000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1682650800000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1682654400000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1682658000000,
                    "value": 82,
                    "value2": 0
                },
                {
                    "date": 1682661600000,
                    "value": 118,
                    "value2": 0
                },
                {
                    "date": 1682665200000,
                    "value": 111,
                    "value2": 5.0200000000000005
                },
                {
                    "date": 1682668800000,
                    "value": 108,
                    "value2": 10.82
                },
                {
                    "date": 1682672400000,
                    "value": 107.875,
                    "value2": 12.77
                },
                {
                    "date": 1682676000000,
                    "value": 106,
                    "value2": 12.4
                },
                {
                    "date": 1682679600000,
                    "value": 98,
                    "value2": 8.83
                },
                {
                    "date": 1682683200000,
                    "value": 86.875,
                    "value2": 10.03
                },
                {
                    "date": 1682686800000,
                    "value": 90,
                    "value2": 9.700000000000001
                },
                {
                    "date": 1682690400000,
                    "value": 71,
                    "value2": 7.26
                },
                {
                    "date": 1682694000000,
                    "value": 81.125,
                    "value2": 1.58
                },
                {
                    "date": 1682697600000,
                    "value": 101,
                    "value2": 0
                },
                {
                    "date": 1682701200000,
                    "value": 91,
                    "value2": 0
                },
                {
                    "date": 1682704800000,
                    "value": 72.125,
                    "value2": 0
                },
                {
                    "date": 1682708400000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1682712000000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1682715600000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1682719200000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1682726400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682730000000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682733600000,
                    "value": 57.875,
                    "value2": 0
                },
                {
                    "date": 1682737200000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1682740800000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1682744400000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1682748000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1682751600000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1682755200000,
                    "value": 63.125,
                    "value2": 0.04
                },
                {
                    "date": 1682758800000,
                    "value": 58.875,
                    "value2": 0.04
                },
                {
                    "date": 1682762400000,
                    "value": 49.875,
                    "value2": 0.04
                },
                {
                    "date": 1682766000000,
                    "value": 37.875,
                    "value2": 0.04
                },
                {
                    "date": 1682769600000,
                    "value": 18.875,
                    "value2": 0
                },
                {
                    "date": 1682773200000,
                    "value": 19.125,
                    "value2": 0
                },
                {
                    "date": 1682776800000,
                    "value": 12,
                    "value2": 0.08
                },
                {
                    "date": 1682780400000,
                    "value": 5,
                    "value2": 0.08
                },
                {
                    "date": 1682784000000,
                    "value": 9.875,
                    "value2": 0.08
                },
                {
                    "date": 1682791200000,
                    "value": 32,
                    "value2": 0.12
                },
                {
                    "date": 1682794800000,
                    "value": 59,
                    "value2": 0.12
                },
                {
                    "date": 1682798400000,
                    "value": 59.875,
                    "value2": 0.12
                },
                {
                    "date": 1682802000000,
                    "value": 59.875,
                    "value2": 0.12
                },
                {
                    "date": 1682805600000,
                    "value": 54,
                    "value2": 0.12
                },
                {
                    "date": 1682812800000,
                    "value": 58.125,
                    "value2": 0.12
                },
                {
                    "date": 1682816400000,
                    "value": 58,
                    "value2": 0.12
                },
                {
                    "date": 1682820000000,
                    "value": 59,
                    "value2": 0.12
                },
                {
                    "date": 1682823600000,
                    "value": 60.875,
                    "value2": 0.12
                },
                {
                    "date": 1682827200000,
                    "value": 59.125,
                    "value2": 0.12
                },
                {
                    "date": 1682830800000,
                    "value": 60.125,
                    "value2": 0.12
                },
                {
                    "date": 1682834400000,
                    "value": 58,
                    "value2": 0.12
                },
                {
                    "date": 1682838000000,
                    "value": 50,
                    "value2": 0
                },
                {
                    "date": 1682841600000,
                    "value": 37,
                    "value2": 0.04
                },
                {
                    "date": 1682845200000,
                    "value": 20.125,
                    "value2": 0.04
                },
                {
                    "date": 1682848800000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1682852400000,
                    "value": 1.875,
                    "value2": 0.04
                },
                {
                    "date": 1682856000000,
                    "value": 11,
                    "value2": 0.04
                },
                {
                    "date": 1682859600000,
                    "value": 0,
                    "value2": 0.08
                },
                {
                    "date": 1682863200000,
                    "value": 8.125,
                    "value2": 0
                },
                {
                    "date": 1682866800000,
                    "value": 32,
                    "value2": 0
                },
                {
                    "date": 1682870400000,
                    "value": 34,
                    "value2": 0
                },
                {
                    "date": 1682877600000,
                    "value": 43,
                    "value2": 0
                },
                {
                    "date": 1682881200000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1682884800000,
                    "value": 58.125,
                    "value2": 0
                },
                {
                    "date": 1682888400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1682892000000,
                    "value": 52,
                    "value2": 0
                },
                {
                    "date": 1682899200000,
                    "value": 81,
                    "value2": 0
                },
                {
                    "date": 1682902800000,
                    "value": 86,
                    "value2": 0
                },
                {
                    "date": 1682906400000,
                    "value": 81.125,
                    "value2": 0
                },
                {
                    "date": 1682910000000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1682913600000,
                    "value": 84.125,
                    "value2": 0
                },
                {
                    "date": 1682917200000,
                    "value": 86,
                    "value2": 0
                },
                {
                    "date": 1682920800000,
                    "value": 111.125,
                    "value2": 0
                },
                {
                    "date": 1682924400000,
                    "value": 112,
                    "value2": 0.04
                },
                {
                    "date": 1682928000000,
                    "value": 85,
                    "value2": 0.08
                },
                {
                    "date": 1682931600000,
                    "value": 84,
                    "value2": 0.08
                },
                {
                    "date": 1682935200000,
                    "value": 76.875,
                    "value2": 0.08
                },
                {
                    "date": 1682938800000,
                    "value": 83,
                    "value2": 0.08
                },
                {
                    "date": 1682942400000,
                    "value": 50,
                    "value2": 0.12
                },
                {
                    "date": 1682946000000,
                    "value": 89.875,
                    "value2": 0.12
                },
                {
                    "date": 1682949600000,
                    "value": 80,
                    "value2": 0.04
                },
                {
                    "date": 1682953200000,
                    "value": 81.125,
                    "value2": 0.12
                },
                {
                    "date": 1682956800000,
                    "value": 81,
                    "value2": 0.12
                },
                {
                    "date": 1682964000000,
                    "value": 64,
                    "value2": 0.17
                },
                {
                    "date": 1682967600000,
                    "value": 64,
                    "value2": 0.17
                },
                {
                    "date": 1682971200000,
                    "value": 62.125,
                    "value2": 0.17
                },
                {
                    "date": 1682974800000,
                    "value": 60.875,
                    "value2": 0.17
                },
                {
                    "date": 1682978400000,
                    "value": 53,
                    "value2": 0.17
                },
                {
                    "date": 1682985600000,
                    "value": 57,
                    "value2": 0.17
                },
                {
                    "date": 1682989200000,
                    "value": 57.875,
                    "value2": 0.17
                },
                {
                    "date": 1682992800000,
                    "value": 58,
                    "value2": 0.17
                },
                {
                    "date": 1682996400000,
                    "value": 65,
                    "value2": 0.17
                },
                {
                    "date": 1683000000000,
                    "value": 62.875,
                    "value2": 0.17
                },
                {
                    "date": 1683003600000,
                    "value": 83.125,
                    "value2": 0.17
                },
                {
                    "date": 1683007200000,
                    "value": 114.875,
                    "value2": 0.17
                },
                {
                    "date": 1683010800000,
                    "value": 109.875,
                    "value2": 17.79
                },
                {
                    "date": 1683014400000,
                    "value": 114.125,
                    "value2": 36.4
                },
                {
                    "date": 1683018000000,
                    "value": 103.875,
                    "value2": 40.800000000000004
                },
                {
                    "date": 1683021600000,
                    "value": 82.875,
                    "value2": 39.97
                },
                {
                    "date": 1683025200000,
                    "value": 71.875,
                    "value2": 27.69
                },
                {
                    "date": 1683028800000,
                    "value": 67.125,
                    "value2": 34.45
                },
                {
                    "date": 1683032400000,
                    "value": 78.125,
                    "value2": 36.480000000000004
                },
                {
                    "date": 1683036000000,
                    "value": 83.125,
                    "value2": 33.83
                },
                {
                    "date": 1683039600000,
                    "value": 78.875,
                    "value2": 28.32
                },
                {
                    "date": 1683043200000,
                    "value": 92,
                    "value2": 28.32
                },
                {
                    "date": 1683050400000,
                    "value": 73,
                    "value2": 28.32
                },
                {
                    "date": 1683054000000,
                    "value": 65,
                    "value2": 28.32
                },
                {
                    "date": 1683057600000,
                    "value": 60.875,
                    "value2": 28.32
                },
                {
                    "date": 1683061200000,
                    "value": 60.125,
                    "value2": 28.32
                },
                {
                    "date": 1683064800000,
                    "value": 54,
                    "value2": 28.32
                },
                {
                    "date": 1683072000000,
                    "value": 58,
                    "value2": 28.32
                },
                {
                    "date": 1683075600000,
                    "value": 58,
                    "value2": 28.32
                },
                {
                    "date": 1683079200000,
                    "value": 59,
                    "value2": 28.32
                },
                {
                    "date": 1683082800000,
                    "value": 63,
                    "value2": 28.32
                },
                {
                    "date": 1683086400000,
                    "value": 65,
                    "value2": 28.32
                },
                {
                    "date": 1683090000000,
                    "value": 83.875,
                    "value2": 28.32
                },
                {
                    "date": 1683093600000,
                    "value": 103.875,
                    "value2": 28.32
                },
                {
                    "date": 1683097200000,
                    "value": 118,
                    "value2": 19.69
                },
                {
                    "date": 1683100800000,
                    "value": 121.875,
                    "value2": 42.62
                },
                {
                    "date": 1683104400000,
                    "value": 102.125,
                    "value2": 46.14
                },
                {
                    "date": 1683108000000,
                    "value": 81.875,
                    "value2": 44.36
                },
                {
                    "date": 1683111600000,
                    "value": 71,
                    "value2": 27.86
                },
                {
                    "date": 1683115200000,
                    "value": 67.125,
                    "value2": 36.03
                },
                {
                    "date": 1683118800000,
                    "value": 72.125,
                    "value2": 40.01
                },
                {
                    "date": 1683122400000,
                    "value": 72.875,
                    "value2": 35.74
                },
                {
                    "date": 1683126000000,
                    "value": 76.875,
                    "value2": 24.59
                },
                {
                    "date": 1683129600000,
                    "value": 89,
                    "value2": 6.67
                },
                {
                    "date": 1683136800000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1683140400000,
                    "value": 68.125,
                    "value2": 0
                },
                {
                    "date": 1683144000000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1683147600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1683151200000,
                    "value": 55,
                    "value2": 0
                },
                {
                    "date": 1683158400000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1683162000000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1683165600000,
                    "value": 58.125,
                    "value2": 0
                },
                {
                    "date": 1683169200000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1683172800000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1683176400000,
                    "value": 82.875,
                    "value2": 0
                },
                {
                    "date": 1683180000000,
                    "value": 102,
                    "value2": 0
                },
                {
                    "date": 1683183600000,
                    "value": 111,
                    "value2": 16.79
                },
                {
                    "date": 1683187200000,
                    "value": 112,
                    "value2": 37.27
                },
                {
                    "date": 1683190800000,
                    "value": 99.125,
                    "value2": 39.76
                },
                {
                    "date": 1683194400000,
                    "value": 92,
                    "value2": 38.93
                },
                {
                    "date": 1683198000000,
                    "value": 70.875,
                    "value2": 26.45
                },
                {
                    "date": 1683201600000,
                    "value": 98.875,
                    "value2": 32.88
                },
                {
                    "date": 1683205200000,
                    "value": 97.125,
                    "value2": 36.94
                },
                {
                    "date": 1683208800000,
                    "value": 100,
                    "value2": 33.13
                },
                {
                    "date": 1683212400000,
                    "value": 110.125,
                    "value2": 22.6
                },
                {
                    "date": 1683216000000,
                    "value": 95,
                    "value2": 6.43
                },
                {
                    "date": 1683219600000,
                    "value": 95.125,
                    "value2": 0
                },
                {
                    "date": 1683223200000,
                    "value": 72.875,
                    "value2": 0
                },
                {
                    "date": 1683226800000,
                    "value": 65.125,
                    "value2": 0
                },
                {
                    "date": 1683230400000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1683234000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1683237600000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1683244800000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1683248400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1683252000000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1683255600000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1683259200000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1683262800000,
                    "value": 72.875,
                    "value2": 0
                },
                {
                    "date": 1683266400000,
                    "value": 90,
                    "value2": 0
                },
                {
                    "date": 1683270000000,
                    "value": 103,
                    "value2": 5.3500000000000005
                },
                {
                    "date": 1683273600000,
                    "value": 112,
                    "value2": 12.48
                },
                {
                    "date": 1683277200000,
                    "value": 98.125,
                    "value2": 13.56
                },
                {
                    "date": 1683280800000,
                    "value": 87.125,
                    "value2": 12.73
                },
                {
                    "date": 1683284400000,
                    "value": 73.125,
                    "value2": 9.41
                },
                {
                    "date": 1683288000000,
                    "value": 76,
                    "value2": 10.950000000000001
                },
                {
                    "date": 1683291600000,
                    "value": 76.875,
                    "value2": 10.82
                },
                {
                    "date": 1683295200000,
                    "value": 77,
                    "value2": 7.79
                },
                {
                    "date": 1683298800000,
                    "value": 96,
                    "value2": 1.58
                },
                {
                    "date": 1683302400000,
                    "value": 96,
                    "value2": 0
                },
                {
                    "date": 1683309600000,
                    "value": 72.875,
                    "value2": 0
                },
                {
                    "date": 1683313200000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1683316800000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1683320400000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1683324000000,
                    "value": 51.875,
                    "value2": 0
                },
                {
                    "date": 1683331200000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1683334800000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1683338400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1683342000000,
                    "value": 58.875,
                    "value2": 0
                },
                {
                    "date": 1683345600000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1683349200000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1683352800000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1683356400000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1683360000000,
                    "value": 55.125,
                    "value2": 0.04
                },
                {
                    "date": 1683363600000,
                    "value": 41.875,
                    "value2": 0.04
                },
                {
                    "date": 1683367200000,
                    "value": 22.125,
                    "value2": 0.04
                },
                {
                    "date": 1683370800000,
                    "value": 6,
                    "value2": 0
                },
                {
                    "date": 1683374400000,
                    "value": 5,
                    "value2": 0.08
                },
                {
                    "date": 1683378000000,
                    "value": 1.875,
                    "value2": 0.04
                },
                {
                    "date": 1683381600000,
                    "value": 26,
                    "value2": 0
                },
                {
                    "date": 1683385200000,
                    "value": 39,
                    "value2": 0.08
                },
                {
                    "date": 1683388800000,
                    "value": 54.125,
                    "value2": 0.12
                },
                {
                    "date": 1683396000000,
                    "value": 56.875,
                    "value2": 0.04
                },
                {
                    "date": 1683399600000,
                    "value": 59,
                    "value2": 0.04
                },
                {
                    "date": 1683403200000,
                    "value": 60.125,
                    "value2": 0.04
                },
                {
                    "date": 1683406800000,
                    "value": 56.875,
                    "value2": 0.04
                },
                {
                    "date": 1683410400000,
                    "value": 54.125,
                    "value2": 0.04
                },
                {
                    "date": 1683417600000,
                    "value": 56.125,
                    "value2": 0.04
                },
                {
                    "date": 1683421200000,
                    "value": 56,
                    "value2": 0.04
                },
                {
                    "date": 1683424800000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1683428400000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1683432000000,
                    "value": 60,
                    "value2": 0.04
                },
                {
                    "date": 1683435600000,
                    "value": 59,
                    "value2": 0.04
                },
                {
                    "date": 1683439200000,
                    "value": 59,
                    "value2": 0.04
                },
                {
                    "date": 1683442800000,
                    "value": 60,
                    "value2": 0.08
                },
                {
                    "date": 1683446400000,
                    "value": 56.125,
                    "value2": 0.08
                },
                {
                    "date": 1683450000000,
                    "value": 35,
                    "value2": 0.08
                },
                {
                    "date": 1683453600000,
                    "value": 30,
                    "value2": 0.08
                },
                {
                    "date": 1683457200000,
                    "value": 27,
                    "value2": 0
                },
                {
                    "date": 1683460800000,
                    "value": 5.125,
                    "value2": 0
                },
                {
                    "date": 1683464400000,
                    "value": 31,
                    "value2": 0
                },
                {
                    "date": 1683468000000,
                    "value": 39,
                    "value2": 0.04
                },
                {
                    "date": 1683471600000,
                    "value": 22.125,
                    "value2": 0.04
                },
                {
                    "date": 1683475200000,
                    "value": 30.125,
                    "value2": 0.04
                },
                {
                    "date": 1683486000000,
                    "value": 52,
                    "value2": 0.21
                },
                {
                    "date": 1683489600000,
                    "value": 58.125,
                    "value2": 0.21
                },
                {
                    "date": 1683493200000,
                    "value": 59.875,
                    "value2": 0.21
                },
                {
                    "date": 1683496800000,
                    "value": 53.125,
                    "value2": 0.21
                },
                {
                    "date": 1683504000000,
                    "value": 81.125,
                    "value2": 0.21
                },
                {
                    "date": 1683507600000,
                    "value": 81.875,
                    "value2": 0.21
                },
                {
                    "date": 1683511200000,
                    "value": 81,
                    "value2": 0.21
                },
                {
                    "date": 1683514800000,
                    "value": 84.125,
                    "value2": 0.21
                },
                {
                    "date": 1683518400000,
                    "value": 85,
                    "value2": 0.21
                },
                {
                    "date": 1683522000000,
                    "value": 85.875,
                    "value2": 0.21
                },
                {
                    "date": 1683525600000,
                    "value": 95,
                    "value2": 0.21
                },
                {
                    "date": 1683529200000,
                    "value": 96.875,
                    "value2": 0
                },
                {
                    "date": 1683532800000,
                    "value": 86.875,
                    "value2": 0
                },
                {
                    "date": 1683536400000,
                    "value": 83.125,
                    "value2": 0
                },
                {
                    "date": 1683540000000,
                    "value": 78.125,
                    "value2": 0
                },
                {
                    "date": 1683543600000,
                    "value": 43,
                    "value2": 0
                },
                {
                    "date": 1683547200000,
                    "value": 67.875,
                    "value2": 0
                },
                {
                    "date": 1683550800000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1683554400000,
                    "value": 77.875,
                    "value2": 0
                },
                {
                    "date": 1683558000000,
                    "value": 76,
                    "value2": 0
                },
                {
                    "date": 1683561600000,
                    "value": 88.125,
                    "value2": 0
                },
                {
                    "date": 1683568800000,
                    "value": 64,
                    "value2": 0.21
                },
                {
                    "date": 1683572400000,
                    "value": 64,
                    "value2": 0.21
                },
                {
                    "date": 1683576000000,
                    "value": 60.875,
                    "value2": 0.21
                },
                {
                    "date": 1683579600000,
                    "value": 61.125,
                    "value2": 0.21
                },
                {
                    "date": 1683583200000,
                    "value": 52,
                    "value2": 0.21
                },
                {
                    "date": 1683590400000,
                    "value": 59,
                    "value2": 0.21
                },
                {
                    "date": 1683594000000,
                    "value": 56,
                    "value2": 0.21
                },
                {
                    "date": 1683597600000,
                    "value": 59,
                    "value2": 0.21
                },
                {
                    "date": 1683601200000,
                    "value": 59.875,
                    "value2": 0.21
                },
                {
                    "date": 1683604800000,
                    "value": 61.125,
                    "value2": 0.21
                },
                {
                    "date": 1683608400000,
                    "value": 82.875,
                    "value2": 0.21
                },
                {
                    "date": 1683612000000,
                    "value": 103,
                    "value2": 0.21
                },
                {
                    "date": 1683615600000,
                    "value": 114,
                    "value2": 22.14
                },
                {
                    "date": 1683619200000,
                    "value": 125.125,
                    "value2": 52.03
                },
                {
                    "date": 1683622800000,
                    "value": 128,
                    "value2": 57.13
                },
                {
                    "date": 1683626400000,
                    "value": 126,
                    "value2": 57.88
                },
                {
                    "date": 1683630000000,
                    "value": 120.875,
                    "value2": 45.69
                },
                {
                    "date": 1683633600000,
                    "value": 115.125,
                    "value2": 49.88
                },
                {
                    "date": 1683637200000,
                    "value": 124,
                    "value2": 52.45
                },
                {
                    "date": 1683640800000,
                    "value": 118,
                    "value2": 48.26
                },
                {
                    "date": 1683644400000,
                    "value": 107,
                    "value2": 37.56
                },
                {
                    "date": 1683648000000,
                    "value": 106,
                    "value2": 16.13
                },
                {
                    "date": 1683655200000,
                    "value": 78.125,
                    "value2": 0
                },
                {
                    "date": 1683658800000,
                    "value": 68.125,
                    "value2": 0
                },
                {
                    "date": 1683662400000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1683666000000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1683669600000,
                    "value": 53,
                    "value2": 0
                },
                {
                    "date": 1683676800000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1683680400000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1683684000000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1683687600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1683691200000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1683694800000,
                    "value": 81.875,
                    "value2": 0
                },
                {
                    "date": 1683698400000,
                    "value": 105,
                    "value2": 0
                },
                {
                    "date": 1683702000000,
                    "value": 121,
                    "value2": 18.28
                },
                {
                    "date": 1683705600000,
                    "value": 129.125,
                    "value2": 39.72
                },
                {
                    "date": 1683709200000,
                    "value": 127,
                    "value2": 42.58
                },
                {
                    "date": 1683712800000,
                    "value": 123,
                    "value2": 40.71
                },
                {
                    "date": 1683716400000,
                    "value": 117,
                    "value2": 29.68
                },
                {
                    "date": 1683720000000,
                    "value": 87.875,
                    "value2": 35.74
                },
                {
                    "date": 1683727200000,
                    "value": 91,
                    "value2": 33.29
                },
                {
                    "date": 1683730800000,
                    "value": 99.125,
                    "value2": 23.67
                },
                {
                    "date": 1683734400000,
                    "value": 101,
                    "value2": 5.6000000000000005
                },
                {
                    "date": 1683741600000,
                    "value": 73,
                    "value2": 0
                },
                {
                    "date": 1683745200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1683748800000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1683752400000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1683756000000,
                    "value": 53,
                    "value2": 0
                },
                {
                    "date": 1683763200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1683766800000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1683770400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1683774000000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1683777600000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1683781200000,
                    "value": 83.125,
                    "value2": 0
                },
                {
                    "date": 1683784800000,
                    "value": 105.875,
                    "value2": 0
                },
                {
                    "date": 1683788400000,
                    "value": 117,
                    "value2": 24.13
                },
                {
                    "date": 1683792000000,
                    "value": 121.125,
                    "value2": 48.47
                },
                {
                    "date": 1683795600000,
                    "value": 111.125,
                    "value2": 52.900000000000006
                },
                {
                    "date": 1683799200000,
                    "value": 104.875,
                    "value2": 53.07
                },
                {
                    "date": 1683802800000,
                    "value": 107,
                    "value2": 39.84
                },
                {
                    "date": 1683806400000,
                    "value": 113,
                    "value2": 46.31
                },
                {
                    "date": 1683810000000,
                    "value": 123,
                    "value2": 50.120000000000005
                },
                {
                    "date": 1683813600000,
                    "value": 113,
                    "value2": 44.61
                },
                {
                    "date": 1683817200000,
                    "value": 121.875,
                    "value2": 36.19
                },
                {
                    "date": 1683820800000,
                    "value": 117,
                    "value2": 13.35
                },
                {
                    "date": 1683828000000,
                    "value": 78.125,
                    "value2": 0
                },
                {
                    "date": 1683831600000,
                    "value": 68.125,
                    "value2": 0
                },
                {
                    "date": 1683835200000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1683838800000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1683842400000,
                    "value": 52,
                    "value2": 0
                },
                {
                    "date": 1683849600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1683853200000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1683856800000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1683860400000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1683864000000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1683867600000,
                    "value": 84.125,
                    "value2": 0
                },
                {
                    "date": 1683871200000,
                    "value": 103.875,
                    "value2": 0
                },
                {
                    "date": 1683874800000,
                    "value": 116.125,
                    "value2": 8.25
                },
                {
                    "date": 1683878400000,
                    "value": 119,
                    "value2": 19.11
                },
                {
                    "date": 1683885600000,
                    "value": 118,
                    "value2": 20.07
                },
                {
                    "date": 1683889200000,
                    "value": 103.875,
                    "value2": 15.92
                },
                {
                    "date": 1683892800000,
                    "value": 103.875,
                    "value2": 15.13
                },
                {
                    "date": 1683896400000,
                    "value": 126.875,
                    "value2": 17.04
                },
                {
                    "date": 1683900000000,
                    "value": 122,
                    "value2": 14.100000000000001
                },
                {
                    "date": 1683903600000,
                    "value": 118,
                    "value2": 6.97
                },
                {
                    "date": 1683907200000,
                    "value": 125.125,
                    "value2": 0
                },
                {
                    "date": 1683914400000,
                    "value": 78.125,
                    "value2": 0
                },
                {
                    "date": 1683918000000,
                    "value": 65.125,
                    "value2": 0
                },
                {
                    "date": 1683921600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1683925200000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1683928800000,
                    "value": 53,
                    "value2": 0
                },
                {
                    "date": 1683936000000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1683939600000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1683943200000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1683946800000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1683950400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1683954000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1683957600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1683961200000,
                    "value": 60.125,
                    "value2": 0.12
                },
                {
                    "date": 1683964800000,
                    "value": 45,
                    "value2": 0.12
                },
                {
                    "date": 1683968400000,
                    "value": 47,
                    "value2": 0.12
                },
                {
                    "date": 1683972000000,
                    "value": 42,
                    "value2": 0
                },
                {
                    "date": 1683975600000,
                    "value": 7,
                    "value2": 0.04
                },
                {
                    "date": 1683979200000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1683982800000,
                    "value": 1.125,
                    "value2": 0.04
                },
                {
                    "date": 1683986400000,
                    "value": 6,
                    "value2": 0.08
                },
                {
                    "date": 1683990000000,
                    "value": 1.875,
                    "value2": 0.04
                },
                {
                    "date": 1683993600000,
                    "value": 2,
                    "value2": 0.04
                },
                {
                    "date": 1684000800000,
                    "value": 45.125,
                    "value2": 0.04
                },
                {
                    "date": 1684004400000,
                    "value": 56.125,
                    "value2": 0.04
                },
                {
                    "date": 1684008000000,
                    "value": 55.875,
                    "value2": 0.04
                },
                {
                    "date": 1684011600000,
                    "value": 57,
                    "value2": 0.04
                },
                {
                    "date": 1684015200000,
                    "value": 50,
                    "value2": 0.04
                },
                {
                    "date": 1684022400000,
                    "value": 56.125,
                    "value2": 0.04
                },
                {
                    "date": 1684026000000,
                    "value": 55.875,
                    "value2": 0.04
                },
                {
                    "date": 1684029600000,
                    "value": 56.125,
                    "value2": 0.04
                },
                {
                    "date": 1684033200000,
                    "value": 60.875,
                    "value2": 0.04
                },
                {
                    "date": 1684036800000,
                    "value": 57,
                    "value2": 0.04
                },
                {
                    "date": 1684040400000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1684044000000,
                    "value": 57.125,
                    "value2": 0.04
                },
                {
                    "date": 1684047600000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1684051200000,
                    "value": 56,
                    "value2": 0
                },
                {
                    "date": 1684054800000,
                    "value": 43,
                    "value2": 0
                },
                {
                    "date": 1684058400000,
                    "value": 39.875,
                    "value2": 0
                },
                {
                    "date": 1684062000000,
                    "value": 20,
                    "value2": 0
                },
                {
                    "date": 1684065600000,
                    "value": 1,
                    "value2": 0
                },
                {
                    "date": 1684069200000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1684072800000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1684076400000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1684080000000,
                    "value": 13.875,
                    "value2": 0.04
                },
                {
                    "date": 1684087200000,
                    "value": 29.875,
                    "value2": 0.04
                },
                {
                    "date": 1684090800000,
                    "value": 52.125,
                    "value2": 0.04
                },
                {
                    "date": 1684094400000,
                    "value": 59,
                    "value2": 0.04
                },
                {
                    "date": 1684098000000,
                    "value": 57,
                    "value2": 0.04
                },
                {
                    "date": 1684101600000,
                    "value": 52.875,
                    "value2": 0.04
                },
                {
                    "date": 1684108800000,
                    "value": 82.125,
                    "value2": 0.04
                },
                {
                    "date": 1684112400000,
                    "value": 81.875,
                    "value2": 0.04
                },
                {
                    "date": 1684116000000,
                    "value": 81.875,
                    "value2": 0.04
                },
                {
                    "date": 1684119600000,
                    "value": 86.125,
                    "value2": 0.04
                },
                {
                    "date": 1684123200000,
                    "value": 86.875,
                    "value2": 0.04
                },
                {
                    "date": 1684126800000,
                    "value": 87.875,
                    "value2": 0.04
                },
                {
                    "date": 1684130400000,
                    "value": 106,
                    "value2": 0.04
                },
                {
                    "date": 1684134000000,
                    "value": 118,
                    "value2": 21.31
                },
                {
                    "date": 1684137600000,
                    "value": 127,
                    "value2": 52.99
                },
                {
                    "date": 1684141200000,
                    "value": 124.875,
                    "value2": 55.51
                },
                {
                    "date": 1684144800000,
                    "value": 118,
                    "value2": 53.32
                },
                {
                    "date": 1684148400000,
                    "value": 112,
                    "value2": 37.27
                },
                {
                    "date": 1684152000000,
                    "value": 118.875,
                    "value2": 40.51
                },
                {
                    "date": 1684155600000,
                    "value": 115.125,
                    "value2": 42.7
                },
                {
                    "date": 1684159200000,
                    "value": 113.875,
                    "value2": 36.82
                },
                {
                    "date": 1684162800000,
                    "value": 117.125,
                    "value2": 27.45
                },
                {
                    "date": 1684166400000,
                    "value": 125.125,
                    "value2": 4.3500000000000005
                },
                {
                    "date": 1684173600000,
                    "value": 80,
                    "value2": 0
                },
                {
                    "date": 1684177200000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1684180800000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1684184400000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1684188000000,
                    "value": 53,
                    "value2": 0
                },
                {
                    "date": 1684195200000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1684198800000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1684202400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1684206000000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1684209600000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1684213200000,
                    "value": 84,
                    "value2": 0
                },
                {
                    "date": 1684216800000,
                    "value": 103.875,
                    "value2": 0
                },
                {
                    "date": 1684220400000,
                    "value": 122,
                    "value2": 25.17
                },
                {
                    "date": 1684224000000,
                    "value": 129.875,
                    "value2": 56.84
                },
                {
                    "date": 1684227600000,
                    "value": 119,
                    "value2": 62.11
                },
                {
                    "date": 1684231200000,
                    "value": 97,
                    "value2": 62.11
                },
                {
                    "date": 1684234800000,
                    "value": 78.125,
                    "value2": 62.11
                },
                {
                    "date": 1684238400000,
                    "value": 78.125,
                    "value2": 62.11
                },
                {
                    "date": 1684242000000,
                    "value": 91,
                    "value2": 62.11
                },
                {
                    "date": 1684245600000,
                    "value": 97,
                    "value2": 62.11
                },
                {
                    "date": 1684249200000,
                    "value": 106.125,
                    "value2": 62.11
                },
                {
                    "date": 1684252800000,
                    "value": 114.875,
                    "value2": 62.11
                },
                {
                    "date": 1684260000000,
                    "value": 75,
                    "value2": 62.11
                },
                {
                    "date": 1684263600000,
                    "value": 65,
                    "value2": 62.11
                },
                {
                    "date": 1684267200000,
                    "value": 64,
                    "value2": 62.11
                },
                {
                    "date": 1684270800000,
                    "value": 62.125,
                    "value2": 62.11
                },
                {
                    "date": 1684274400000,
                    "value": 53.875,
                    "value2": 62.11
                },
                {
                    "date": 1684281600000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1684285200000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1684288800000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1684292400000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1684296000000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1684299600000,
                    "value": 82.875,
                    "value2": 0
                },
                {
                    "date": 1684303200000,
                    "value": 102,
                    "value2": 0
                },
                {
                    "date": 1684306800000,
                    "value": 118,
                    "value2": 16.04
                },
                {
                    "date": 1684314000000,
                    "value": 111,
                    "value2": 37.15
                },
                {
                    "date": 1684317600000,
                    "value": 88.125,
                    "value2": 38.1
                },
                {
                    "date": 1684321200000,
                    "value": 74.875,
                    "value2": 26.91
                },
                {
                    "date": 1684324800000,
                    "value": 91,
                    "value2": 29.89
                },
                {
                    "date": 1684328400000,
                    "value": 104.125,
                    "value2": 31.51
                },
                {
                    "date": 1684332000000,
                    "value": 98.875,
                    "value2": 26.29
                },
                {
                    "date": 1684335600000,
                    "value": 95,
                    "value2": 16.63
                },
                {
                    "date": 1684339200000,
                    "value": 107.875,
                    "value2": 0.79
                },
                {
                    "date": 1684346400000,
                    "value": 71.125,
                    "value2": 0
                },
                {
                    "date": 1684350000000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1684353600000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1684357200000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1684360800000,
                    "value": 53,
                    "value2": 0
                },
                {
                    "date": 1684368000000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1684371600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1684375200000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1684378800000,
                    "value": 72.875,
                    "value2": 0
                },
                {
                    "date": 1684382400000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1684386000000,
                    "value": 88.125,
                    "value2": 0
                },
                {
                    "date": 1684389600000,
                    "value": 102,
                    "value2": 0
                },
                {
                    "date": 1684393200000,
                    "value": 97.875,
                    "value2": 0.17
                },
                {
                    "date": 1684396800000,
                    "value": 83,
                    "value2": 0.17
                },
                {
                    "date": 1684400400000,
                    "value": 75,
                    "value2": 0.17
                },
                {
                    "date": 1684404000000,
                    "value": 50,
                    "value2": 0.17
                },
                {
                    "date": 1684407600000,
                    "value": 48,
                    "value2": 0.08
                },
                {
                    "date": 1684411200000,
                    "value": 33.875,
                    "value2": 0.08
                },
                {
                    "date": 1684414800000,
                    "value": 37,
                    "value2": 0.62
                },
                {
                    "date": 1684418400000,
                    "value": 40.875,
                    "value2": 0.62
                },
                {
                    "date": 1684422000000,
                    "value": 48,
                    "value2": 0.62
                },
                {
                    "date": 1684425600000,
                    "value": 65,
                    "value2": 0.46
                },
                {
                    "date": 1684432800000,
                    "value": 51.125,
                    "value2": 0.33
                },
                {
                    "date": 1684436400000,
                    "value": 60.875,
                    "value2": 0.33
                },
                {
                    "date": 1684440000000,
                    "value": 62.125,
                    "value2": 0.33
                },
                {
                    "date": 1684443600000,
                    "value": 60.875,
                    "value2": 0.33
                },
                {
                    "date": 1684447200000,
                    "value": 54,
                    "value2": 0.33
                },
                {
                    "date": 1684454400000,
                    "value": 60.125,
                    "value2": 0.33
                },
                {
                    "date": 1684458000000,
                    "value": 57.875,
                    "value2": 0.33
                },
                {
                    "date": 1684461600000,
                    "value": 61.125,
                    "value2": 0.33
                },
                {
                    "date": 1684465200000,
                    "value": 61.875,
                    "value2": 0.33
                },
                {
                    "date": 1684468800000,
                    "value": 61.875,
                    "value2": 0.33
                },
                {
                    "date": 1684472400000,
                    "value": 83.125,
                    "value2": 0.33
                },
                {
                    "date": 1684476000000,
                    "value": 100,
                    "value2": 0.33
                },
                {
                    "date": 1684479600000,
                    "value": 107,
                    "value2": 3.15
                },
                {
                    "date": 1684483200000,
                    "value": 101,
                    "value2": 6.26
                },
                {
                    "date": 1684486800000,
                    "value": 98.125,
                    "value2": 7.34
                },
                {
                    "date": 1684490400000,
                    "value": 65.875,
                    "value2": 7.5
                },
                {
                    "date": 1684494000000,
                    "value": 44.125,
                    "value2": 5.22
                },
                {
                    "date": 1684497600000,
                    "value": 45.875,
                    "value2": 5.2700000000000005
                },
                {
                    "date": 1684501200000,
                    "value": 52.125,
                    "value2": 5.1000000000000005
                },
                {
                    "date": 1684504800000,
                    "value": 59,
                    "value2": 3.23
                },
                {
                    "date": 1684508400000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1684512000000,
                    "value": 79.125,
                    "value2": 0
                },
                {
                    "date": 1684519200000,
                    "value": 54,
                    "value2": 0
                },
                {
                    "date": 1684522800000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1684526400000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1684530000000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1684533600000,
                    "value": 50.125,
                    "value2": 0
                },
                {
                    "date": 1684540800000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1684544400000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1684548000000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1684551600000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1684555200000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1684558800000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1684562400000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1684566000000,
                    "value": 51.125,
                    "value2": 0
                },
                {
                    "date": 1684569600000,
                    "value": 69.875,
                    "value2": 0
                },
                {
                    "date": 1684573200000,
                    "value": 52,
                    "value2": 0
                },
                {
                    "date": 1684576800000,
                    "value": 4,
                    "value2": 0
                },
                {
                    "date": 1684580400000,
                    "value": 0,
                    "value2": 0.08
                },
                {
                    "date": 1684584000000,
                    "value": 0,
                    "value2": 0.25
                },
                {
                    "date": 1684587600000,
                    "value": 5,
                    "value2": 0.25
                },
                {
                    "date": 1684591200000,
                    "value": 16,
                    "value2": 0.25
                },
                {
                    "date": 1684594800000,
                    "value": 18,
                    "value2": 0.17
                },
                {
                    "date": 1684598400000,
                    "value": 32,
                    "value2": 0.12
                },
                {
                    "date": 1684605600000,
                    "value": 59,
                    "value2": 0.12
                },
                {
                    "date": 1684609200000,
                    "value": 59,
                    "value2": 0.12
                },
                {
                    "date": 1684612800000,
                    "value": 64,
                    "value2": 0.12
                },
                {
                    "date": 1684616400000,
                    "value": 60.875,
                    "value2": 0.12
                },
                {
                    "date": 1684620000000,
                    "value": 54,
                    "value2": 0.12
                },
                {
                    "date": 1684627200000,
                    "value": 59,
                    "value2": 0.12
                },
                {
                    "date": 1684630800000,
                    "value": 59,
                    "value2": 0.12
                },
                {
                    "date": 1684634400000,
                    "value": 60,
                    "value2": 0.12
                },
                {
                    "date": 1684638000000,
                    "value": 60.875,
                    "value2": 0.12
                },
                {
                    "date": 1684641600000,
                    "value": 62,
                    "value2": 0.12
                },
                {
                    "date": 1684645200000,
                    "value": 62,
                    "value2": 0.12
                },
                {
                    "date": 1684648800000,
                    "value": 60,
                    "value2": 0.12
                },
                {
                    "date": 1684652400000,
                    "value": 56.875,
                    "value2": 0.12
                },
                {
                    "date": 1684656000000,
                    "value": 56.125,
                    "value2": 0.12
                },
                {
                    "date": 1684659600000,
                    "value": 28.875,
                    "value2": 0.12
                },
                {
                    "date": 1684663200000,
                    "value": 0,
                    "value2": 0.12
                },
                {
                    "date": 1684666800000,
                    "value": 2.125,
                    "value2": 0.17
                },
                {
                    "date": 1684670400000,
                    "value": 1.875,
                    "value2": 0.17
                },
                {
                    "date": 1684674000000,
                    "value": 6,
                    "value2": 0.21
                },
                {
                    "date": 1684677600000,
                    "value": 8.125,
                    "value2": 0.12
                },
                {
                    "date": 1684681200000,
                    "value": 10,
                    "value2": 0.17
                },
                {
                    "date": 1684684800000,
                    "value": 21,
                    "value2": 0.17
                },
                {
                    "date": 1684692000000,
                    "value": 59,
                    "value2": 0.21
                },
                {
                    "date": 1684695600000,
                    "value": 65.125,
                    "value2": 0.21
                },
                {
                    "date": 1684699200000,
                    "value": 65,
                    "value2": 0.21
                },
                {
                    "date": 1684702800000,
                    "value": 62,
                    "value2": 0.21
                },
                {
                    "date": 1684706400000,
                    "value": 55,
                    "value2": 0.21
                },
                {
                    "date": 1684713600000,
                    "value": 82.875,
                    "value2": 0.21
                },
                {
                    "date": 1684717200000,
                    "value": 81.875,
                    "value2": 0.21
                },
                {
                    "date": 1684720800000,
                    "value": 84,
                    "value2": 0.21
                },
                {
                    "date": 1684724400000,
                    "value": 86.875,
                    "value2": 0.21
                },
                {
                    "date": 1684728000000,
                    "value": 87,
                    "value2": 0.21
                },
                {
                    "date": 1684731600000,
                    "value": 87,
                    "value2": 0.21
                },
                {
                    "date": 1684735200000,
                    "value": 104.125,
                    "value2": 0.21
                },
                {
                    "date": 1684738800000,
                    "value": 114,
                    "value2": 17.16
                },
                {
                    "date": 1684742400000,
                    "value": 119.875,
                    "value2": 43.660000000000004
                },
                {
                    "date": 1684746000000,
                    "value": 108.125,
                    "value2": 48.09
                },
                {
                    "date": 1684749600000,
                    "value": 97,
                    "value2": 46.43
                },
                {
                    "date": 1684753200000,
                    "value": 85,
                    "value2": 34.12
                },
                {
                    "date": 1684756800000,
                    "value": 78.875,
                    "value2": 36.980000000000004
                },
                {
                    "date": 1684760400000,
                    "value": 101.125,
                    "value2": 40.96
                },
                {
                    "date": 1684764000000,
                    "value": 100.875,
                    "value2": 36.77
                },
                {
                    "date": 1684767600000,
                    "value": 108,
                    "value2": 26.66
                },
                {
                    "date": 1684771200000,
                    "value": 112,
                    "value2": 6.51
                },
                {
                    "date": 1684778400000,
                    "value": 86,
                    "value2": 0.08
                },
                {
                    "date": 1684782000000,
                    "value": 73,
                    "value2": 0.08
                },
                {
                    "date": 1684785600000,
                    "value": 65.125,
                    "value2": 0.08
                },
                {
                    "date": 1684789200000,
                    "value": 65.875,
                    "value2": 0.08
                },
                {
                    "date": 1684792800000,
                    "value": 57.125,
                    "value2": 0.08
                },
                {
                    "date": 1684800000000,
                    "value": 64.875,
                    "value2": 0.08
                },
                {
                    "date": 1684803600000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1684807200000,
                    "value": 66.125,
                    "value2": 0.08
                },
                {
                    "date": 1684810800000,
                    "value": 70,
                    "value2": 0.08
                },
                {
                    "date": 1684814400000,
                    "value": 69,
                    "value2": 0.08
                },
                {
                    "date": 1684818000000,
                    "value": 89,
                    "value2": 0.08
                },
                {
                    "date": 1684821600000,
                    "value": 108.875,
                    "value2": 0.08
                },
                {
                    "date": 1684825200000,
                    "value": 125.125,
                    "value2": 23.3
                },
                {
                    "date": 1684828800000,
                    "value": 130,
                    "value2": 44.15
                },
                {
                    "date": 1684832400000,
                    "value": 132,
                    "value2": 44.15
                },
                {
                    "date": 1684836000000,
                    "value": 129,
                    "value2": 44.15
                },
                {
                    "date": 1684839600000,
                    "value": 118,
                    "value2": 44.15
                },
                {
                    "date": 1684843200000,
                    "value": 109.125,
                    "value2": 44.15
                },
                {
                    "date": 1684846800000,
                    "value": 109.125,
                    "value2": 44.15
                },
                {
                    "date": 1684850400000,
                    "value": 97.875,
                    "value2": 44.15
                },
                {
                    "date": 1684854000000,
                    "value": 102.875,
                    "value2": 44.15
                },
                {
                    "date": 1684857600000,
                    "value": 104,
                    "value2": 44.15
                },
                {
                    "date": 1684864800000,
                    "value": 75,
                    "value2": 44.15
                },
                {
                    "date": 1684868400000,
                    "value": 67.125,
                    "value2": 44.15
                },
                {
                    "date": 1684872000000,
                    "value": 64.875,
                    "value2": 44.15
                },
                {
                    "date": 1684875600000,
                    "value": 65,
                    "value2": 44.15
                },
                {
                    "date": 1684879200000,
                    "value": 53,
                    "value2": 44.15
                },
                {
                    "date": 1684886400000,
                    "value": 58.125,
                    "value2": 44.15
                },
                {
                    "date": 1684890000000,
                    "value": 59.875,
                    "value2": 44.15
                },
                {
                    "date": 1684893600000,
                    "value": 59,
                    "value2": 44.15
                },
                {
                    "date": 1684897200000,
                    "value": 61.875,
                    "value2": 44.15
                },
                {
                    "date": 1684900800000,
                    "value": 62.125,
                    "value2": 44.15
                },
                {
                    "date": 1684904400000,
                    "value": 82.875,
                    "value2": 44.15
                },
                {
                    "date": 1684908000000,
                    "value": 102,
                    "value2": 44.15
                },
                {
                    "date": 1684911600000,
                    "value": 114.875,
                    "value2": 44.15
                },
                {
                    "date": 1684915200000,
                    "value": 124,
                    "value2": 44.15
                },
                {
                    "date": 1684918800000,
                    "value": 112,
                    "value2": 44.15
                },
                {
                    "date": 1684922400000,
                    "value": 91,
                    "value2": 43.57
                },
                {
                    "date": 1684926000000,
                    "value": 74,
                    "value2": 30.39
                },
                {
                    "date": 1684929600000,
                    "value": 72.125,
                    "value2": 32.38
                },
                {
                    "date": 1684933200000,
                    "value": 80,
                    "value2": 36.15
                },
                {
                    "date": 1684936800000,
                    "value": 80,
                    "value2": 32.26
                },
                {
                    "date": 1684940400000,
                    "value": 78,
                    "value2": 18.66
                },
                {
                    "date": 1684944000000,
                    "value": 105,
                    "value2": 0.04
                },
                {
                    "date": 1684951200000,
                    "value": 79,
                    "value2": 0
                },
                {
                    "date": 1684954800000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1684958400000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1684962000000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1684965600000,
                    "value": 52,
                    "value2": 0
                },
                {
                    "date": 1684972800000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1684976400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1684980000000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1684983600000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1684987200000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1684990800000,
                    "value": 83.125,
                    "value2": 0
                },
                {
                    "date": 1684994400000,
                    "value": 102.125,
                    "value2": 0
                },
                {
                    "date": 1684998000000,
                    "value": 116.125,
                    "value2": 17.95
                },
                {
                    "date": 1685001600000,
                    "value": 122.125,
                    "value2": 42.95
                },
                {
                    "date": 1685005200000,
                    "value": 112,
                    "value2": 45.36
                },
                {
                    "date": 1685008800000,
                    "value": 86.875,
                    "value2": 43.53
                },
                {
                    "date": 1685012400000,
                    "value": 73,
                    "value2": 27.16
                },
                {
                    "date": 1685016000000,
                    "value": 69,
                    "value2": 32.92
                },
                {
                    "date": 1685019600000,
                    "value": 77.875,
                    "value2": 37.56
                },
                {
                    "date": 1685023200000,
                    "value": 78.875,
                    "value2": 32.46
                },
                {
                    "date": 1685026800000,
                    "value": 78,
                    "value2": 22.35
                },
                {
                    "date": 1685030400000,
                    "value": 91.875,
                    "value2": 0
                },
                {
                    "date": 1685037600000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1685041200000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1685044800000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1685048400000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1685052000000,
                    "value": 52,
                    "value2": 0
                },
                {
                    "date": 1685059200000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685062800000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1685066400000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1685070000000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1685073600000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1685077200000,
                    "value": 80,
                    "value2": 0
                },
                {
                    "date": 1685080800000,
                    "value": 99.875,
                    "value2": 0
                },
                {
                    "date": 1685084400000,
                    "value": 111,
                    "value2": 4.73
                },
                {
                    "date": 1685088000000,
                    "value": 117,
                    "value2": 4.73
                },
                {
                    "date": 1685098800000,
                    "value": 67.875,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1685102400000,
                    "value": 64,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1685109600000,
                    "value": 74,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1685113200000,
                    "value": 77,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1685116800000,
                    "value": 87.125,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1685124000000,
                    "value": 67.875,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1685127600000,
                    "value": 65,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1685131200000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1685134800000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1685138400000,
                    "value": 54,
                    "value2": 0
                },
                {
                    "date": 1685145600000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1685149200000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1685152800000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1685156400000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685160000000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1685163600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1685167200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1685170800000,
                    "value": 61.125,
                    "value2": 0.08
                },
                {
                    "date": 1685174400000,
                    "value": 59,
                    "value2": 0.12
                },
                {
                    "date": 1685178000000,
                    "value": 40.875,
                    "value2": 0.12
                },
                {
                    "date": 1685181600000,
                    "value": 1.125,
                    "value2": 0
                },
                {
                    "date": 1685185200000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1685188800000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1685192400000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1685196000000,
                    "value": 5,
                    "value2": 0.04
                },
                {
                    "date": 1685199600000,
                    "value": 26,
                    "value2": 0.17
                },
                {
                    "date": 1685203200000,
                    "value": 8.875,
                    "value2": 0.17
                },
                {
                    "date": 1685210400000,
                    "value": 39,
                    "value2": 0.17
                },
                {
                    "date": 1685214000000,
                    "value": 57,
                    "value2": 0.17
                },
                {
                    "date": 1685217600000,
                    "value": 62.875,
                    "value2": 0.17
                },
                {
                    "date": 1685221200000,
                    "value": 61,
                    "value2": 0.17
                },
                {
                    "date": 1685224800000,
                    "value": 56.125,
                    "value2": 0.17
                },
                {
                    "date": 1685232000000,
                    "value": 61.125,
                    "value2": 0.17
                },
                {
                    "date": 1685235600000,
                    "value": 58,
                    "value2": 0.17
                },
                {
                    "date": 1685239200000,
                    "value": 56.875,
                    "value2": 0.17
                },
                {
                    "date": 1685242800000,
                    "value": 57.125,
                    "value2": 0.17
                },
                {
                    "date": 1685246400000,
                    "value": 58,
                    "value2": 0.17
                },
                {
                    "date": 1685250000000,
                    "value": 58,
                    "value2": 0.17
                },
                {
                    "date": 1685253600000,
                    "value": 56.875,
                    "value2": 0.17
                },
                {
                    "date": 1685257200000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1685260800000,
                    "value": 48,
                    "value2": 0.12
                },
                {
                    "date": 1685264400000,
                    "value": 32,
                    "value2": 0.04
                },
                {
                    "date": 1685268000000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1685271600000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1685275200000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1685278800000,
                    "value": 0,
                    "value2": 0.08
                },
                {
                    "date": 1685282400000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1685286000000,
                    "value": 0,
                    "value2": 0.08
                },
                {
                    "date": 1685289600000,
                    "value": 4.875,
                    "value2": 0.08
                },
                {
                    "date": 1685296800000,
                    "value": 33,
                    "value2": 0.08
                },
                {
                    "date": 1685300400000,
                    "value": 60,
                    "value2": 0.08
                },
                {
                    "date": 1685304000000,
                    "value": 61,
                    "value2": 0.08
                },
                {
                    "date": 1685307600000,
                    "value": 61.125,
                    "value2": 0.08
                },
                {
                    "date": 1685311200000,
                    "value": 55,
                    "value2": 0.08
                },
                {
                    "date": 1685318400000,
                    "value": 87,
                    "value2": 0.08
                },
                {
                    "date": 1685322000000,
                    "value": 80,
                    "value2": 0.08
                },
                {
                    "date": 1685325600000,
                    "value": 81,
                    "value2": 0.08
                },
                {
                    "date": 1685329200000,
                    "value": 81.875,
                    "value2": 0.08
                },
                {
                    "date": 1685332800000,
                    "value": 82.875,
                    "value2": 0.08
                },
                {
                    "date": 1685336400000,
                    "value": 84,
                    "value2": 0.08
                },
                {
                    "date": 1685340000000,
                    "value": 93.875,
                    "value2": 0.08
                },
                {
                    "date": 1685343600000,
                    "value": 94.875,
                    "value2": 9.120000000000001
                },
                {
                    "date": 1685347200000,
                    "value": 91,
                    "value2": 20.85
                },
                {
                    "date": 1685350800000,
                    "value": 77.875,
                    "value2": 23.63
                },
                {
                    "date": 1685354400000,
                    "value": 35.125,
                    "value2": 21.52
                },
                {
                    "date": 1685358000000,
                    "value": 41,
                    "value2": 13.47
                },
                {
                    "date": 1685361600000,
                    "value": 35.125,
                    "value2": 17.580000000000002
                },
                {
                    "date": 1685365200000,
                    "value": 40.125,
                    "value2": 20.61
                },
                {
                    "date": 1685368800000,
                    "value": 41.875,
                    "value2": 16.330000000000002
                },
                {
                    "date": 1685372400000,
                    "value": 49.125,
                    "value2": 9.950000000000001
                },
                {
                    "date": 1685376000000,
                    "value": 67.875,
                    "value2": 0.04
                },
                {
                    "date": 1685383200000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685386800000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1685390400000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1685394000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1685397600000,
                    "value": 51.875,
                    "value2": 0
                },
                {
                    "date": 1685404800000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1685408400000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1685412000000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1685415600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685419200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1685422800000,
                    "value": 78.125,
                    "value2": 0
                },
                {
                    "date": 1685426400000,
                    "value": 99.125,
                    "value2": 0
                },
                {
                    "date": 1685430000000,
                    "value": 113,
                    "value2": 23.84
                },
                {
                    "date": 1685433600000,
                    "value": 123.875,
                    "value2": 55.31
                },
                {
                    "date": 1685437200000,
                    "value": 114.125,
                    "value2": 59.33
                },
                {
                    "date": 1685440800000,
                    "value": 90,
                    "value2": 56.01
                },
                {
                    "date": 1685444400000,
                    "value": 75,
                    "value2": 33.21
                },
                {
                    "date": 1685448000000,
                    "value": 70.875,
                    "value2": 44.53
                },
                {
                    "date": 1685451600000,
                    "value": 76,
                    "value2": 48.01
                },
                {
                    "date": 1685455200000,
                    "value": 70.875,
                    "value2": 42.54
                },
                {
                    "date": 1685458800000,
                    "value": 72.875,
                    "value2": 30.22
                },
                {
                    "date": 1685462400000,
                    "value": 85,
                    "value2": 5.18
                },
                {
                    "date": 1685469600000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1685473200000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1685476800000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1685480400000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1685484000000,
                    "value": 53,
                    "value2": 0
                },
                {
                    "date": 1685491200000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1685494800000,
                    "value": 55,
                    "value2": 0
                },
                {
                    "date": 1685498400000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1685502000000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685505600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685509200000,
                    "value": 72,
                    "value2": 0
                },
                {
                    "date": 1685512800000,
                    "value": 91.875,
                    "value2": 0
                },
                {
                    "date": 1685516400000,
                    "value": 106,
                    "value2": 18.86
                },
                {
                    "date": 1685520000000,
                    "value": 112,
                    "value2": 41.5
                },
                {
                    "date": 1685523600000,
                    "value": 102,
                    "value2": 45.85
                },
                {
                    "date": 1685527200000,
                    "value": 82.125,
                    "value2": 43.08
                },
                {
                    "date": 1685530800000,
                    "value": 66.875,
                    "value2": 30.22
                },
                {
                    "date": 1685534400000,
                    "value": 64,
                    "value2": 35.99
                },
                {
                    "date": 1685538000000,
                    "value": 72.875,
                    "value2": 41.04
                },
                {
                    "date": 1685541600000,
                    "value": 75,
                    "value2": 36.980000000000004
                },
                {
                    "date": 1685545200000,
                    "value": 74,
                    "value2": 23.3
                },
                {
                    "date": 1685548800000,
                    "value": 86,
                    "value2": 3.81
                },
                {
                    "date": 1685556000000,
                    "value": 72.125,
                    "value2": 0
                },
                {
                    "date": 1685559600000,
                    "value": 68.125,
                    "value2": 0
                },
                {
                    "date": 1685563200000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1685566800000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1685570400000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1685577600000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1685581200000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1685584800000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1685588400000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1685592000000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685595600000,
                    "value": 73.125,
                    "value2": 0
                },
                {
                    "date": 1685599200000,
                    "value": 100.125,
                    "value2": 0
                },
                {
                    "date": 1685602800000,
                    "value": 113.875,
                    "value2": 23.05
                },
                {
                    "date": 1685606400000,
                    "value": 123,
                    "value2": 48.92
                },
                {
                    "date": 1685610000000,
                    "value": 115.125,
                    "value2": 54.44
                },
                {
                    "date": 1685613600000,
                    "value": 93.875,
                    "value2": 52.11
                },
                {
                    "date": 1685617200000,
                    "value": 80,
                    "value2": 35.07
                },
                {
                    "date": 1685620800000,
                    "value": 76.875,
                    "value2": 41.92
                },
                {
                    "date": 1685624400000,
                    "value": 85,
                    "value2": 47.31
                },
                {
                    "date": 1685628000000,
                    "value": 89.125,
                    "value2": 42.410000000000004
                },
                {
                    "date": 1685631600000,
                    "value": 88.125,
                    "value2": 31.88
                },
                {
                    "date": 1685635200000,
                    "value": 97.125,
                    "value2": 6.72
                },
                {
                    "date": 1685642400000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1685646000000,
                    "value": 68.125,
                    "value2": 0
                },
                {
                    "date": 1685649600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1685653200000,
                    "value": 73,
                    "value2": 0
                },
                {
                    "date": 1685656800000,
                    "value": 53.875,
                    "value2": 0
                },
                {
                    "date": 1685664000000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1685667600000,
                    "value": 55,
                    "value2": 0
                },
                {
                    "date": 1685671200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1685674800000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1685678400000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685682000000,
                    "value": 81,
                    "value2": 0
                },
                {
                    "date": 1685685600000,
                    "value": 98.875,
                    "value2": 0
                },
                {
                    "date": 1685689200000,
                    "value": 108.125,
                    "value2": 9.25
                },
                {
                    "date": 1685692800000,
                    "value": 110.125,
                    "value2": 19.28
                },
                {
                    "date": 1685696400000,
                    "value": 105,
                    "value2": 19.900000000000002
                },
                {
                    "date": 1685700000000,
                    "value": 83.125,
                    "value2": 18.62
                },
                {
                    "date": 1685703600000,
                    "value": 65.875,
                    "value2": 14.59
                },
                {
                    "date": 1685707200000,
                    "value": 65,
                    "value2": 15.26
                },
                {
                    "date": 1685710800000,
                    "value": 77,
                    "value2": 17.37
                },
                {
                    "date": 1685714400000,
                    "value": 81.125,
                    "value2": 14.14
                },
                {
                    "date": 1685718000000,
                    "value": 80,
                    "value2": 7.71
                },
                {
                    "date": 1685721600000,
                    "value": 87,
                    "value2": 0.25
                },
                {
                    "date": 1685725200000,
                    "value": 79,
                    "value2": 0
                },
                {
                    "date": 1685728800000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1685732400000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1685736000000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1685739600000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1685743200000,
                    "value": 52.125,
                    "value2": 0
                },
                {
                    "date": 1685750400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1685754000000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1685757600000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1685761200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1685764800000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1685768400000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1685772000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1685775600000,
                    "value": 65,
                    "value2": 0.04
                },
                {
                    "date": 1685779200000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1685782800000,
                    "value": 46.125,
                    "value2": 0
                },
                {
                    "date": 1685786400000,
                    "value": 8.125,
                    "value2": 0
                },
                {
                    "date": 1685790000000,
                    "value": 0,
                    "value2": 0.12
                },
                {
                    "date": 1685793600000,
                    "value": 0,
                    "value2": 0.12
                },
                {
                    "date": 1685797200000,
                    "value": 0,
                    "value2": 0.12
                },
                {
                    "date": 1685800800000,
                    "value": 0,
                    "value2": 0.21
                },
                {
                    "date": 1685804400000,
                    "value": 0,
                    "value2": 0.12
                },
                {
                    "date": 1685808000000,
                    "value": 6,
                    "value2": 0.21
                },
                {
                    "date": 1685815200000,
                    "value": 35.125,
                    "value2": 0.08
                },
                {
                    "date": 1685818800000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1685822400000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1685826000000,
                    "value": 60,
                    "value2": 0.08
                },
                {
                    "date": 1685829600000,
                    "value": 54.875,
                    "value2": 0.08
                },
                {
                    "date": 1685836800000,
                    "value": 59.875,
                    "value2": 0.08
                },
                {
                    "date": 1685840400000,
                    "value": 59,
                    "value2": 0.08
                },
                {
                    "date": 1685844000000,
                    "value": 56.125,
                    "value2": 0.08
                },
                {
                    "date": 1685847600000,
                    "value": 55.875,
                    "value2": 0.08
                },
                {
                    "date": 1685851200000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1685854800000,
                    "value": 57.125,
                    "value2": 0.08
                },
                {
                    "date": 1685858400000,
                    "value": 56.875,
                    "value2": 0.08
                },
                {
                    "date": 1685862000000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1685865600000,
                    "value": 52.125,
                    "value2": 0
                },
                {
                    "date": 1685869200000,
                    "value": 27,
                    "value2": 0
                },
                {
                    "date": 1685872800000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1685952000000,
                    "value": 124,
                    "value2": 54.980000000000004
                },
                {
                    "date": 1685955600000,
                    "value": 116,
                    "value2": 58.54
                },
                {
                    "date": 1685959200000,
                    "value": 92.125,
                    "value2": 49.83
                },
                {
                    "date": 1685962800000,
                    "value": 79,
                    "value2": 28.48
                },
                {
                    "date": 1685966400000,
                    "value": 75.875,
                    "value2": 44.65
                },
                {
                    "date": 1685970000000,
                    "value": 84.875,
                    "value2": 47.68
                },
                {
                    "date": 1685973600000,
                    "value": 85.875,
                    "value2": 44.11
                },
                {
                    "date": 1685977200000,
                    "value": 87,
                    "value2": 29.52
                },
                {
                    "date": 1685980800000,
                    "value": 102.125,
                    "value2": 7.63
                },
                {
                    "date": 1685988000000,
                    "value": 74,
                    "value2": 0
                },
                {
                    "date": 1685991600000,
                    "value": 67.875,
                    "value2": 0
                },
                {
                    "date": 1685995200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1685998800000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1686002400000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1686009600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1686013200000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1686016800000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1686020400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1686024000000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1686027600000,
                    "value": 80,
                    "value2": 0
                },
                {
                    "date": 1686031200000,
                    "value": 109.875,
                    "value2": 0
                },
                {
                    "date": 1686034800000,
                    "value": 114.125,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1686038400000,
                    "value": 117,
                    "value2": 41.67
                },
                {
                    "date": 1686042000000,
                    "value": 119,
                    "value2": 43.24
                },
                {
                    "date": 1686045600000,
                    "value": 91,
                    "value2": 38.35
                },
                {
                    "date": 1686049200000,
                    "value": 78.875,
                    "value2": 0.08
                },
                {
                    "date": 1686052800000,
                    "value": 76.875,
                    "value2": 4.8100000000000005
                },
                {
                    "date": 1686056400000,
                    "value": 90,
                    "value2": 7.5
                },
                {
                    "date": 1686060000000,
                    "value": 87.125,
                    "value2": 5.8500000000000005
                },
                {
                    "date": 1686063600000,
                    "value": 87,
                    "value2": 1.45
                },
                {
                    "date": 1686067200000,
                    "value": 97.875,
                    "value2": 0
                },
                {
                    "date": 1686074400000,
                    "value": 70.875,
                    "value2": 0
                },
                {
                    "date": 1686078000000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1686081600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1686085200000,
                    "value": 65.125,
                    "value2": 0
                },
                {
                    "date": 1686088800000,
                    "value": 55.875,
                    "value2": 0
                },
                {
                    "date": 1686096000000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1686099600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1686103200000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1686106800000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1686110400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1686114000000,
                    "value": 81,
                    "value2": 0
                },
                {
                    "date": 1686117600000,
                    "value": 102.125,
                    "value2": 0
                },
                {
                    "date": 1686121200000,
                    "value": 114.125,
                    "value2": 20.52
                },
                {
                    "date": 1686124800000,
                    "value": 115.875,
                    "value2": 43.45
                },
                {
                    "date": 1686128400000,
                    "value": 112,
                    "value2": 47.22
                },
                {
                    "date": 1686132000000,
                    "value": 96,
                    "value2": 44.65
                },
                {
                    "date": 1686135600000,
                    "value": 81.875,
                    "value2": 26.41
                },
                {
                    "date": 1686139200000,
                    "value": 78.875,
                    "value2": 37.730000000000004
                },
                {
                    "date": 1686142800000,
                    "value": 86,
                    "value2": 41.71
                },
                {
                    "date": 1686146400000,
                    "value": 93.125,
                    "value2": 36.480000000000004
                },
                {
                    "date": 1686150000000,
                    "value": 106,
                    "value2": 25.87
                },
                {
                    "date": 1686153600000,
                    "value": 113.125,
                    "value2": 7.88
                },
                {
                    "date": 1686160800000,
                    "value": 75.875,
                    "value2": 0
                },
                {
                    "date": 1686164400000,
                    "value": 67.875,
                    "value2": 0
                },
                {
                    "date": 1686168000000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1686171600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1686175200000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1686182400000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1686186000000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1686189600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1686193200000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1686196800000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1686200400000,
                    "value": 80.875,
                    "value2": 0
                },
                {
                    "date": 1686204000000,
                    "value": 100,
                    "value2": 0
                },
                {
                    "date": 1686207600000,
                    "value": 113,
                    "value2": 22.51
                },
                {
                    "date": 1686211200000,
                    "value": 119.875,
                    "value2": 50.410000000000004
                },
                {
                    "date": 1686214800000,
                    "value": 120.125,
                    "value2": 52.24
                },
                {
                    "date": 1686218400000,
                    "value": 87.875,
                    "value2": 51.45
                },
                {
                    "date": 1686222000000,
                    "value": 80,
                    "value2": 32.92
                },
                {
                    "date": 1686225600000,
                    "value": 82.125,
                    "value2": 36.32
                },
                {
                    "date": 1686229200000,
                    "value": 88.125,
                    "value2": 43.160000000000004
                },
                {
                    "date": 1686232800000,
                    "value": 90,
                    "value2": 39.72
                },
                {
                    "date": 1686236400000,
                    "value": 96,
                    "value2": 28.32
                },
                {
                    "date": 1686240000000,
                    "value": 108,
                    "value2": 7.79
                },
                {
                    "date": 1686247200000,
                    "value": 75,
                    "value2": 0.12
                },
                {
                    "date": 1686250800000,
                    "value": 66.875,
                    "value2": 0.12
                },
                {
                    "date": 1686254400000,
                    "value": 66.125,
                    "value2": 0.12
                },
                {
                    "date": 1686258000000,
                    "value": 65,
                    "value2": 0.12
                },
                {
                    "date": 1686261600000,
                    "value": 56.125,
                    "value2": 0.12
                },
                {
                    "date": 1686268800000,
                    "value": 58,
                    "value2": 0.12
                },
                {
                    "date": 1686272400000,
                    "value": 57.125,
                    "value2": 0.12
                },
                {
                    "date": 1686276000000,
                    "value": 58,
                    "value2": 0.12
                },
                {
                    "date": 1686279600000,
                    "value": 59.875,
                    "value2": 0.12
                },
                {
                    "date": 1686283200000,
                    "value": 59.875,
                    "value2": 0.12
                },
                {
                    "date": 1686286800000,
                    "value": 81.125,
                    "value2": 0.12
                },
                {
                    "date": 1686290400000,
                    "value": 101.125,
                    "value2": 0.12
                },
                {
                    "date": 1686294000000,
                    "value": 110,
                    "value2": 10.78
                },
                {
                    "date": 1686297600000,
                    "value": 114.875,
                    "value2": 16.21
                },
                {
                    "date": 1686301200000,
                    "value": 117,
                    "value2": 18.95
                },
                {
                    "date": 1686304800000,
                    "value": 90,
                    "value2": 17.990000000000002
                },
                {
                    "date": 1686308400000,
                    "value": 75.875,
                    "value2": 19.400000000000002
                },
                {
                    "date": 1686312000000,
                    "value": 77.125,
                    "value2": 26.990000000000002
                },
                {
                    "date": 1686315600000,
                    "value": 82.875,
                    "value2": 29.060000000000002
                },
                {
                    "date": 1686319200000,
                    "value": 85,
                    "value2": 23.76
                },
                {
                    "date": 1686322800000,
                    "value": 88,
                    "value2": 9.25
                },
                {
                    "date": 1686326400000,
                    "value": 90.875,
                    "value2": 0
                },
                {
                    "date": 1686333600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1686337200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1686340800000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1686344400000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1686348000000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1686391200000,
                    "value": 18.125,
                    "value2": 0.04
                },
                {
                    "date": 1686394800000,
                    "value": 5,
                    "value2": 0.04
                },
                {
                    "date": 1686398400000,
                    "value": 2.875,
                    "value2": 0.04
                },
                {
                    "date": 1686402000000,
                    "value": 7.875,
                    "value2": 0.08
                },
                {
                    "date": 1686405600000,
                    "value": 8.125,
                    "value2": 0.04
                },
                {
                    "date": 1686409200000,
                    "value": 45.875,
                    "value2": 0
                },
                {
                    "date": 1686412800000,
                    "value": 46.875,
                    "value2": 0.04
                },
                {
                    "date": 1686420000000,
                    "value": 66,
                    "value2": 0.04
                },
                {
                    "date": 1686423600000,
                    "value": 68.125,
                    "value2": 0.04
                },
                {
                    "date": 1686427200000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1686430800000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1686434400000,
                    "value": 55.875,
                    "value2": 0.04
                },
                {
                    "date": 1686441600000,
                    "value": 60.125,
                    "value2": 0.04
                },
                {
                    "date": 1686445200000,
                    "value": 60.125,
                    "value2": 0.04
                },
                {
                    "date": 1686448800000,
                    "value": 60,
                    "value2": 0.04
                },
                {
                    "date": 1686452400000,
                    "value": 61.125,
                    "value2": 0.04
                },
                {
                    "date": 1686456000000,
                    "value": 61,
                    "value2": 0.04
                },
                {
                    "date": 1686459600000,
                    "value": 61.125,
                    "value2": 0.04
                },
                {
                    "date": 1686463200000,
                    "value": 60,
                    "value2": 0.04
                },
                {
                    "date": 1686466800000,
                    "value": 54.875,
                    "value2": 0.08
                },
                {
                    "date": 1686470400000,
                    "value": 55,
                    "value2": 0.08
                },
                {
                    "date": 1686474000000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1686477600000,
                    "value": 61.125,
                    "value2": 0.08
                },
                {
                    "date": 1686481200000,
                    "value": 23,
                    "value2": 0.08
                },
                {
                    "date": 1686484800000,
                    "value": 5,
                    "value2": 0.08
                },
                {
                    "date": 1686488400000,
                    "value": 35.875,
                    "value2": 0.08
                },
                {
                    "date": 1686492000000,
                    "value": 59.875,
                    "value2": 0.17
                },
                {
                    "date": 1686495600000,
                    "value": 24.125,
                    "value2": 0.17
                },
                {
                    "date": 1686499200000,
                    "value": 50,
                    "value2": 0.17
                },
                {
                    "date": 1686506400000,
                    "value": 48,
                    "value2": 0.25
                },
                {
                    "date": 1686510000000,
                    "value": 62.125,
                    "value2": 0.25
                },
                {
                    "date": 1686513600000,
                    "value": 65.875,
                    "value2": 0.25
                },
                {
                    "date": 1686517200000,
                    "value": 65.125,
                    "value2": 0.25
                },
                {
                    "date": 1686520800000,
                    "value": 60,
                    "value2": 0.25
                },
                {
                    "date": 1686528000000,
                    "value": 87,
                    "value2": 0.25
                },
                {
                    "date": 1686531600000,
                    "value": 85,
                    "value2": 0.25
                },
                {
                    "date": 1686535200000,
                    "value": 86.125,
                    "value2": 0.25
                },
                {
                    "date": 1686538800000,
                    "value": 86.875,
                    "value2": 0.25
                },
                {
                    "date": 1686542400000,
                    "value": 87.875,
                    "value2": 0.25
                },
                {
                    "date": 1686546000000,
                    "value": 89,
                    "value2": 0.25
                },
                {
                    "date": 1686549600000,
                    "value": 105,
                    "value2": 0.25
                },
                {
                    "date": 1686553200000,
                    "value": 116,
                    "value2": 17.990000000000002
                },
                {
                    "date": 1686556800000,
                    "value": 121.125,
                    "value2": 47.72
                },
                {
                    "date": 1686560400000,
                    "value": 115,
                    "value2": 51.53
                },
                {
                    "date": 1686564000000,
                    "value": 110.125,
                    "value2": 48.22
                },
                {
                    "date": 1686567600000,
                    "value": 105,
                    "value2": 34
                },
                {
                    "date": 1686571200000,
                    "value": 115.875,
                    "value2": 36.15
                },
                {
                    "date": 1686574800000,
                    "value": 117,
                    "value2": 39.18
                },
                {
                    "date": 1686578400000,
                    "value": 115.125,
                    "value2": 33.79
                },
                {
                    "date": 1686582000000,
                    "value": 92.875,
                    "value2": 22.26
                },
                {
                    "date": 1686585600000,
                    "value": 99.875,
                    "value2": 4.3500000000000005
                },
                {
                    "date": 1686592800000,
                    "value": 76.875,
                    "value2": 0
                },
                {
                    "date": 1686596400000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1686600000000,
                    "value": 67.875,
                    "value2": 0
                },
                {
                    "date": 1686603600000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1686607200000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1686614400000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1686618000000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1686621600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1686625200000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1686628800000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1686632400000,
                    "value": 83.875,
                    "value2": 0
                },
                {
                    "date": 1686636000000,
                    "value": 107,
                    "value2": 0
                },
                {
                    "date": 1686639600000,
                    "value": 122,
                    "value2": 23.51
                },
                {
                    "date": 1686643200000,
                    "value": 128,
                    "value2": 54.64
                },
                {
                    "date": 1686646800000,
                    "value": 116,
                    "value2": 60.32
                },
                {
                    "date": 1686650400000,
                    "value": 97,
                    "value2": 60.32
                },
                {
                    "date": 1686654000000,
                    "value": 83.125,
                    "value2": 41.33
                },
                {
                    "date": 1686657600000,
                    "value": 80,
                    "value2": 49.21
                },
                {
                    "date": 1686664800000,
                    "value": 88.875,
                    "value2": 50.120000000000005
                },
                {
                    "date": 1686668400000,
                    "value": 87,
                    "value2": 35.2
                },
                {
                    "date": 1686672000000,
                    "value": 97,
                    "value2": 9.25
                },
                {
                    "date": 1686679200000,
                    "value": 82.125,
                    "value2": 0
                },
                {
                    "date": 1686682800000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1686686400000,
                    "value": 71.875,
                    "value2": 0
                },
                {
                    "date": 1686690000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1686693600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1686700800000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1686704400000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1686708000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1686711600000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1686715200000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1686718800000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1686722400000,
                    "value": 108.125,
                    "value2": 0
                },
                {
                    "date": 1686726000000,
                    "value": 119,
                    "value2": 22.89
                },
                {
                    "date": 1686729600000,
                    "value": 126,
                    "value2": 49.83
                },
                {
                    "date": 1686733200000,
                    "value": 120,
                    "value2": 54.730000000000004
                },
                {
                    "date": 1686736800000,
                    "value": 97.875,
                    "value2": 52.53
                },
                {
                    "date": 1686740400000,
                    "value": 81,
                    "value2": 35.49
                },
                {
                    "date": 1686744000000,
                    "value": 78.125,
                    "value2": 43.49
                },
                {
                    "date": 1686747600000,
                    "value": 85.875,
                    "value2": 48.47
                },
                {
                    "date": 1686751200000,
                    "value": 87.875,
                    "value2": 44.730000000000004
                },
                {
                    "date": 1686754800000,
                    "value": 87.875,
                    "value2": 31.8
                },
                {
                    "date": 1686758400000,
                    "value": 99.875,
                    "value2": 12.15
                },
                {
                    "date": 1686762000000,
                    "value": 104.875,
                    "value2": 0
                },
                {
                    "date": 1686765600000,
                    "value": 84,
                    "value2": 0
                },
                {
                    "date": 1686769200000,
                    "value": 78.125,
                    "value2": 0
                },
                {
                    "date": 1686772800000,
                    "value": 81,
                    "value2": 0
                },
                {
                    "date": 1686776400000,
                    "value": 77.875,
                    "value2": 0
                },
                {
                    "date": 1686787200000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1686790800000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1686794400000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1686798000000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1686801600000,
                    "value": 71,
                    "value2": 0
                },
                {
                    "date": 1686805200000,
                    "value": 91,
                    "value2": 0
                },
                {
                    "date": 1686808800000,
                    "value": 107,
                    "value2": 0
                },
                {
                    "date": 1686812400000,
                    "value": 118,
                    "value2": 0
                },
                {
                    "date": 1686816000000,
                    "value": 123,
                    "value2": 0
                },
                {
                    "date": 1686819600000,
                    "value": 116.125,
                    "value2": 0
                },
                {
                    "date": 1686823200000,
                    "value": 97,
                    "value2": 0
                },
                {
                    "date": 1686826800000,
                    "value": 84,
                    "value2": 0
                },
                {
                    "date": 1686830400000,
                    "value": 78.875,
                    "value2": 0
                },
                {
                    "date": 1686834000000,
                    "value": 92.875,
                    "value2": 0
                },
                {
                    "date": 1686837600000,
                    "value": 99.125,
                    "value2": 0
                },
                {
                    "date": 1686841200000,
                    "value": 103,
                    "value2": 0
                },
                {
                    "date": 1686844800000,
                    "value": 113,
                    "value2": 0
                },
                {
                    "date": 1686852000000,
                    "value": 75,
                    "value2": 0
                },
                {
                    "date": 1686859200000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1686862800000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1686866400000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1686888000000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1686891600000,
                    "value": 88.125,
                    "value2": 0
                },
                {
                    "date": 1686898800000,
                    "value": 113,
                    "value2": 9.91
                },
                {
                    "date": 1686902400000,
                    "value": 123,
                    "value2": 19.44
                },
                {
                    "date": 1686909600000,
                    "value": 97.875,
                    "value2": 16.17
                },
                {
                    "date": 1686913200000,
                    "value": 84,
                    "value2": 9.74
                },
                {
                    "date": 1686916800000,
                    "value": 79,
                    "value2": 12.69
                },
                {
                    "date": 1686920400000,
                    "value": 85,
                    "value2": 16.42
                },
                {
                    "date": 1686924000000,
                    "value": 87.875,
                    "value2": 14.05
                },
                {
                    "date": 1686931200000,
                    "value": 93,
                    "value2": 0
                },
                {
                    "date": 1686934800000,
                    "value": 86,
                    "value2": 0
                },
                {
                    "date": 1686938400000,
                    "value": 80,
                    "value2": 0
                },
                {
                    "date": 1686942000000,
                    "value": 70.875,
                    "value2": 0
                },
                {
                    "date": 1686945600000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1686949200000,
                    "value": 71.125,
                    "value2": 0
                },
                {
                    "date": 1686952800000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1686960000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1686963600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1686967200000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1686970800000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1686974400000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1686978000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1686981600000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1686985200000,
                    "value": 62,
                    "value2": 0.12
                },
                {
                    "date": 1686988800000,
                    "value": 22,
                    "value2": 0.17
                },
                {
                    "date": 1686992400000,
                    "value": 28.875,
                    "value2": 0.12
                },
                {
                    "date": 1686996000000,
                    "value": 57.875,
                    "value2": 0.12
                },
                {
                    "date": 1686999600000,
                    "value": 32,
                    "value2": 0.08
                },
                {
                    "date": 1687003200000,
                    "value": 14.125,
                    "value2": 0.04
                },
                {
                    "date": 1687006800000,
                    "value": 21,
                    "value2": 0.08
                },
                {
                    "date": 1687010400000,
                    "value": 54.125,
                    "value2": 0.17
                },
                {
                    "date": 1687014000000,
                    "value": 58,
                    "value2": 0.12
                },
                {
                    "date": 1687017600000,
                    "value": 44.125,
                    "value2": 0
                },
                {
                    "date": 1687024800000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1687028400000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1687032000000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1687035600000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1687039200000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1687046400000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1687050000000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1687053600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1687057200000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1687060800000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1687064400000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1687068000000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1687071600000,
                    "value": 55.875,
                    "value2": 0.04
                },
                {
                    "date": 1687075200000,
                    "value": 38,
                    "value2": 0.12
                },
                {
                    "date": 1687078800000,
                    "value": 49.875,
                    "value2": 0.12
                },
                {
                    "date": 1687082400000,
                    "value": 38,
                    "value2": 0.12
                },
                {
                    "date": 1687086000000,
                    "value": 17,
                    "value2": 0.12
                },
                {
                    "date": 1687089600000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1687093200000,
                    "value": 3.875,
                    "value2": 0.04
                },
                {
                    "date": 1687096800000,
                    "value": 2.875,
                    "value2": 0.04
                },
                {
                    "date": 1687100400000,
                    "value": 21.125,
                    "value2": 0.04
                },
                {
                    "date": 1687104000000,
                    "value": 51.875,
                    "value2": 0.04
                },
                {
                    "date": 1687111200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1687114800000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1687118400000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1687122000000,
                    "value": 69.875,
                    "value2": 0
                },
                {
                    "date": 1687125600000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1687132800000,
                    "value": 87,
                    "value2": 0
                },
                {
                    "date": 1687136400000,
                    "value": 86.125,
                    "value2": 0
                },
                {
                    "date": 1687140000000,
                    "value": 89,
                    "value2": 0
                },
                {
                    "date": 1687143600000,
                    "value": 89.125,
                    "value2": 0
                },
                {
                    "date": 1687147200000,
                    "value": 87.125,
                    "value2": 0
                },
                {
                    "date": 1687150800000,
                    "value": 89,
                    "value2": 0
                },
                {
                    "date": 1687154400000,
                    "value": 104.125,
                    "value2": 0
                },
                {
                    "date": 1687161600000,
                    "value": 117,
                    "value2": 49.46
                },
                {
                    "date": 1687165200000,
                    "value": 114,
                    "value2": 53.32
                },
                {
                    "date": 1687168800000,
                    "value": 99,
                    "value2": 50.83
                },
                {
                    "date": 1687172400000,
                    "value": 93.125,
                    "value2": 34.54
                },
                {
                    "date": 1687176000000,
                    "value": 94.125,
                    "value2": 37.31
                },
                {
                    "date": 1687179600000,
                    "value": 123,
                    "value2": 42.25
                },
                {
                    "date": 1687183200000,
                    "value": 128,
                    "value2": 37.69
                },
                {
                    "date": 1687186800000,
                    "value": 130.125,
                    "value2": 28.44
                },
                {
                    "date": 1687190400000,
                    "value": 124,
                    "value2": 5.76
                },
                {
                    "date": 1687197600000,
                    "value": 83,
                    "value2": 0
                },
                {
                    "date": 1687201200000,
                    "value": 74,
                    "value2": 0
                },
                {
                    "date": 1687204800000,
                    "value": 69.875,
                    "value2": 0
                },
                {
                    "date": 1687208400000,
                    "value": 71.125,
                    "value2": 0
                },
                {
                    "date": 1687212000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1687219200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1687222800000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1687226400000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1687230000000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1687233600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1687237200000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1687240800000,
                    "value": 104.125,
                    "value2": 0
                },
                {
                    "date": 1687244400000,
                    "value": 113.875,
                    "value2": 27.78
                },
                {
                    "date": 1687251600000,
                    "value": 118.125,
                    "value2": 67.33
                },
                {
                    "date": 1687258800000,
                    "value": 102,
                    "value2": 46.27
                },
                {
                    "date": 1687266000000,
                    "value": 103.125,
                    "value2": 63.06
                },
                {
                    "date": 1687269600000,
                    "value": 106,
                    "value2": 55.64
                },
                {
                    "date": 1687273200000,
                    "value": 100,
                    "value2": 38.6
                },
                {
                    "date": 1687276800000,
                    "value": 119.875,
                    "value2": 9.41
                },
                {
                    "date": 1687284000000,
                    "value": 78,
                    "value2": 0
                },
                {
                    "date": 1687287600000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1687291200000,
                    "value": 71,
                    "value2": 0
                },
                {
                    "date": 1687294800000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1687298400000,
                    "value": 54.875,
                    "value2": 0
                },
                {
                    "date": 1687305600000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1687309200000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1687312800000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1687316400000,
                    "value": 65.125,
                    "value2": 0
                },
                {
                    "date": 1687320000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1687323600000,
                    "value": 83,
                    "value2": 0
                },
                {
                    "date": 1687327200000,
                    "value": 105.125,
                    "value2": 0
                },
                {
                    "date": 1687330800000,
                    "value": 115.875,
                    "value2": 19.82
                },
                {
                    "date": 1687334400000,
                    "value": 127,
                    "value2": 42.29
                },
                {
                    "date": 1687338000000,
                    "value": 119.125,
                    "value2": 47.01
                },
                {
                    "date": 1687341600000,
                    "value": 104.125,
                    "value2": 45.65
                },
                {
                    "date": 1687345200000,
                    "value": 97.125,
                    "value2": 32.67
                },
                {
                    "date": 1687348800000,
                    "value": 96,
                    "value2": 36.15
                },
                {
                    "date": 1687352400000,
                    "value": 90.125,
                    "value2": 41.25
                },
                {
                    "date": 1687356000000,
                    "value": 93,
                    "value2": 37.19
                },
                {
                    "date": 1687359600000,
                    "value": 97.125,
                    "value2": 24.34
                },
                {
                    "date": 1687363200000,
                    "value": 125.875,
                    "value2": 7.05
                },
                {
                    "date": 1687370400000,
                    "value": 77,
                    "value2": 0.08
                },
                {
                    "date": 1687374000000,
                    "value": 75,
                    "value2": 0.08
                },
                {
                    "date": 1687377600000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1687381200000,
                    "value": 71.125,
                    "value2": 0.08
                },
                {
                    "date": 1687384800000,
                    "value": 65,
                    "value2": 0.08
                },
                {
                    "date": 1687392000000,
                    "value": 60.125,
                    "value2": 0.08
                },
                {
                    "date": 1687395600000,
                    "value": 59,
                    "value2": 0.08
                },
                {
                    "date": 1687399200000,
                    "value": 63,
                    "value2": 0.08
                },
                {
                    "date": 1687402800000,
                    "value": 65,
                    "value2": 0.08
                },
                {
                    "date": 1687406400000,
                    "value": 63,
                    "value2": 0.08
                },
                {
                    "date": 1687410000000,
                    "value": 82.875,
                    "value2": 0.08
                },
                {
                    "date": 1687413600000,
                    "value": 102.875,
                    "value2": 0.08
                },
                {
                    "date": 1687417200000,
                    "value": 116.125,
                    "value2": 24.3
                },
                {
                    "date": 1687420800000,
                    "value": 123,
                    "value2": 57.26
                },
                {
                    "date": 1687424400000,
                    "value": 123,
                    "value2": 60.660000000000004
                },
                {
                    "date": 1687428000000,
                    "value": 119.125,
                    "value2": 60.36
                },
                {
                    "date": 1687431600000,
                    "value": 99,
                    "value2": 45.85
                },
                {
                    "date": 1687435200000,
                    "value": 96,
                    "value2": 50.25
                },
                {
                    "date": 1687438800000,
                    "value": 104.125,
                    "value2": 56.14
                },
                {
                    "date": 1687442400000,
                    "value": 114,
                    "value2": 50.660000000000004
                },
                {
                    "date": 1687446000000,
                    "value": 112,
                    "value2": 39.22
                },
                {
                    "date": 1687456800000,
                    "value": 74,
                    "value2": 0
                },
                {
                    "date": 1687460400000,
                    "value": 67.875,
                    "value2": 0
                },
                {
                    "date": 1687464000000,
                    "value": 67.875,
                    "value2": 0
                },
                {
                    "date": 1687467600000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1687471200000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1687478400000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1687482000000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1687485600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1687489200000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1687492800000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1687496400000,
                    "value": 81.125,
                    "value2": 0
                },
                {
                    "date": 1687500000000,
                    "value": 103.125,
                    "value2": 0
                },
                {
                    "date": 1687503600000,
                    "value": 110.875,
                    "value2": 7.05
                },
                {
                    "date": 1687507200000,
                    "value": 118.125,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1687510800000,
                    "value": 110.875,
                    "value2": 21.1
                },
                {
                    "date": 1687514400000,
                    "value": 90,
                    "value2": 20.44
                },
                {
                    "date": 1687518000000,
                    "value": 79,
                    "value2": 16.71
                },
                {
                    "date": 1687521600000,
                    "value": 71.125,
                    "value2": 18.37
                },
                {
                    "date": 1687525200000,
                    "value": 83,
                    "value2": 17.95
                },
                {
                    "date": 1687528800000,
                    "value": 91,
                    "value2": 15.26
                },
                {
                    "date": 1687532400000,
                    "value": 81.875,
                    "value2": 7.21
                },
                {
                    "date": 1687536000000,
                    "value": 96,
                    "value2": 0.04
                },
                {
                    "date": 1687543200000,
                    "value": 66.125,
                    "value2": 0.08
                },
                {
                    "date": 1687546800000,
                    "value": 69,
                    "value2": 0.08
                },
                {
                    "date": 1687550400000,
                    "value": 70.875,
                    "value2": 0.08
                },
                {
                    "date": 1687554000000,
                    "value": 67.875,
                    "value2": 0.08
                },
                {
                    "date": 1687557600000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1687564800000,
                    "value": 61.875,
                    "value2": 0.08
                },
                {
                    "date": 1687568400000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1687572000000,
                    "value": 60.125,
                    "value2": 0.08
                },
                {
                    "date": 1687575600000,
                    "value": 60,
                    "value2": 0.08
                },
                {
                    "date": 1687579200000,
                    "value": 60.875,
                    "value2": 0.08
                },
                {
                    "date": 1687582800000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1687586400000,
                    "value": 65,
                    "value2": 0.08
                },
                {
                    "date": 1687590000000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1687593600000,
                    "value": 63,
                    "value2": 0.04
                },
                {
                    "date": 1687597200000,
                    "value": 49,
                    "value2": 0.04
                },
                {
                    "date": 1687600800000,
                    "value": 11.125,
                    "value2": 0.04
                },
                {
                    "date": 1687604400000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1687608000000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1687611600000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1687615200000,
                    "value": 0,
                    "value2": 0.12
                },
                {
                    "date": 1687618800000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1687622400000,
                    "value": 3.875,
                    "value2": 0
                },
                {
                    "date": 1687629600000,
                    "value": 30,
                    "value2": 0.04
                },
                {
                    "date": 1687633200000,
                    "value": 56.875,
                    "value2": 0.04
                },
                {
                    "date": 1687636800000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1687640400000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1687644000000,
                    "value": 59,
                    "value2": 0.04
                },
                {
                    "date": 1687651200000,
                    "value": 62,
                    "value2": 0.04
                },
                {
                    "date": 1687654800000,
                    "value": 61.875,
                    "value2": 0.04
                },
                {
                    "date": 1687658400000,
                    "value": 60.125,
                    "value2": 0.04
                },
                {
                    "date": 1687662000000,
                    "value": 59.125,
                    "value2": 0.04
                },
                {
                    "date": 1687665600000,
                    "value": 59,
                    "value2": 0.04
                },
                {
                    "date": 1687669200000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1687672800000,
                    "value": 61,
                    "value2": 0.04
                },
                {
                    "date": 1687676400000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1687680000000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1687683600000,
                    "value": 47.125,
                    "value2": 0
                },
                {
                    "date": 1687687200000,
                    "value": 0.875,
                    "value2": 0
                },
                {
                    "date": 1687690800000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1687694400000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1687698000000,
                    "value": 0,
                    "value2": 0.08
                },
                {
                    "date": 1687701600000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1687705200000,
                    "value": 0,
                    "value2": 0.04
                },
                {
                    "date": 1687708800000,
                    "value": 1.125,
                    "value2": 0.04
                },
                {
                    "date": 1687716000000,
                    "value": 32,
                    "value2": 0.12
                },
                {
                    "date": 1687719600000,
                    "value": 60,
                    "value2": 0.12
                },
                {
                    "date": 1687723200000,
                    "value": 61.875,
                    "value2": 0.12
                },
                {
                    "date": 1687726800000,
                    "value": 63,
                    "value2": 0.12
                },
                {
                    "date": 1687730400000,
                    "value": 54.875,
                    "value2": 0.12
                },
                {
                    "date": 1687737600000,
                    "value": 84,
                    "value2": 0.12
                },
                {
                    "date": 1687741200000,
                    "value": 81.875,
                    "value2": 0.12
                },
                {
                    "date": 1687744800000,
                    "value": 44.875,
                    "value2": 0.12
                },
                {
                    "date": 1687748400000,
                    "value": null,
                    "value2": 0.12
                },
                {
                    "date": 1687752000000,
                    "value": null,
                    "value2": 0.12
                },
                {
                    "date": 1687755600000,
                    "value": null,
                    "value2": 0.12
                },
                {
                    "date": 1687759200000,
                    "value": null,
                    "value2": 0.12
                },
                {
                    "date": 1687762800000,
                    "value": null,
                    "value2": 19.150000000000002
                },
                {
                    "date": 1687766400000,
                    "value": null,
                    "value2": 50.17
                },
                {
                    "date": 1687770000000,
                    "value": null,
                    "value2": 54.1
                },
                {
                    "date": 1687773600000,
                    "value": null,
                    "value2": 52.65
                },
                {
                    "date": 1687777200000,
                    "value": null,
                    "value2": 38.27
                },
                {
                    "date": 1687780800000,
                    "value": null,
                    "value2": 41.38
                },
                {
                    "date": 1687784400000,
                    "value": null,
                    "value2": 46.230000000000004
                },
                {
                    "date": 1687788000000,
                    "value": null,
                    "value2": 43.12
                },
                {
                    "date": 1687791600000,
                    "value": null,
                    "value2": 29.560000000000002
                },
                {
                    "date": 1687795200000,
                    "value": null,
                    "value2": 10.950000000000001
                },
                {
                    "date": 1687802400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687806000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687809600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687813200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687816800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687824000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687827600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687831200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687834800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687838400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687842000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687845600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687849200000,
                    "value": null,
                    "value2": 26.66
                },
                {
                    "date": 1687852800000,
                    "value": null,
                    "value2": 58.29
                },
                {
                    "date": 1687856400000,
                    "value": null,
                    "value2": 63.14
                },
                {
                    "date": 1687860000000,
                    "value": null,
                    "value2": 59.95
                },
                {
                    "date": 1687863600000,
                    "value": null,
                    "value2": 38.93
                },
                {
                    "date": 1687867200000,
                    "value": null,
                    "value2": 43.28
                },
                {
                    "date": 1687870800000,
                    "value": null,
                    "value2": 48.59
                },
                {
                    "date": 1687874400000,
                    "value": null,
                    "value2": 45.980000000000004
                },
                {
                    "date": 1687878000000,
                    "value": null,
                    "value2": 33.42
                },
                {
                    "date": 1687881600000,
                    "value": null,
                    "value2": 7.84
                },
                {
                    "date": 1687888800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687892400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687896000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687899600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687903200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687910400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687914000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687917600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687921200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687924800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687928400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687932000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687935600000,
                    "value": null,
                    "value2": 21.23
                },
                {
                    "date": 1687939200000,
                    "value": null,
                    "value2": 43.160000000000004
                },
                {
                    "date": 1687942800000,
                    "value": null,
                    "value2": 47.97
                },
                {
                    "date": 1687946400000,
                    "value": null,
                    "value2": 45.77
                },
                {
                    "date": 1687950000000,
                    "value": null,
                    "value2": 32.88
                },
                {
                    "date": 1687953600000,
                    "value": null,
                    "value2": 36.07
                },
                {
                    "date": 1687957200000,
                    "value": null,
                    "value2": 36.57
                },
                {
                    "date": 1687960800000,
                    "value": null,
                    "value2": 31.55
                },
                {
                    "date": 1687964400000,
                    "value": null,
                    "value2": 21.77
                },
                {
                    "date": 1687968000000,
                    "value": null,
                    "value2": 2.2
                },
                {
                    "date": 1687975200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687978800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687982400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687986000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687989600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1687996800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688000400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688004000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688007600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688011200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688014800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688018400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688022000000,
                    "value": null,
                    "value2": 16.87
                },
                {
                    "date": 1688025600000,
                    "value": null,
                    "value2": 42.910000000000004
                },
                {
                    "date": 1688032800000,
                    "value": null,
                    "value2": 46.1
                },
                {
                    "date": 1688040000000,
                    "value": null,
                    "value2": 38.18
                },
                {
                    "date": 1688043600000,
                    "value": null,
                    "value2": 44.400000000000006
                },
                {
                    "date": 1688047200000,
                    "value": null,
                    "value2": 40.75
                },
                {
                    "date": 1688050800000,
                    "value": null,
                    "value2": 26.95
                },
                {
                    "date": 1688054400000,
                    "value": null,
                    "value2": 1.33
                },
                {
                    "date": 1688061600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688065200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688068800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688072400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688076000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688083200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688086800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688090400000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688094000000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688097600000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688101200000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688104800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688108400000,
                    "value": null,
                    "value2": 6.18
                },
                {
                    "date": 1688112000000,
                    "value": null,
                    "value2": 15.55
                },
                {
                    "date": 1688115600000,
                    "value": null,
                    "value2": 17.54
                },
                {
                    "date": 1688119200000,
                    "value": null,
                    "value2": 16.79
                },
                {
                    "date": 1688122800000,
                    "value": null,
                    "value2": 13.52
                },
                {
                    "date": 1688126400000,
                    "value": null,
                    "value2": 15.92
                },
                {
                    "date": 1688130000000,
                    "value": null,
                    "value2": 16.17
                },
                {
                    "date": 1688133600000,
                    "value": null,
                    "value2": 11.86
                },
                {
                    "date": 1688137200000,
                    "value": null,
                    "value2": 4.44
                },
                {
                    "date": 1688140800000,
                    "value": null,
                    "value2": 0
                },
                {
                    "date": 1688148000000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688151600000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688158800000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688162400000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688169600000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688173200000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688176800000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688180400000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688184000000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688187600000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688191200000,
                    "value": null,
                    "value2": 0.08
                },
                {
                    "date": 1688194800000,
                    "value": null,
                    "value2": 0.17
                },
                {
                    "date": 1688198400000,
                    "value": null,
                    "value2": 0.21
                },
                {
                    "date": 1688202000000,
                    "value": 98,
                    "value2": 0.21
                },
                {
                    "date": 1688205600000,
                    "value": 87,
                    "value2": 0.21
                },
                {
                    "date": 1688209200000,
                    "value": 80,
                    "value2": 0.12
                },
                {
                    "date": 1688212800000,
                    "value": 71.875,
                    "value2": 0.04
                },
                {
                    "date": 1688216400000,
                    "value": 37,
                    "value2": 0.04
                },
                {
                    "date": 1688220000000,
                    "value": 31,
                    "value2": 0
                },
                {
                    "date": 1688223600000,
                    "value": 25.875,
                    "value2": 0
                },
                {
                    "date": 1688227200000,
                    "value": 42,
                    "value2": 0
                },
                {
                    "date": 1688234400000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1688238000000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1688241600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1688245200000,
                    "value": 75,
                    "value2": 0
                },
                {
                    "date": 1688248800000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1688256000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1688259600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1688263200000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1688266800000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1688270400000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1688274000000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1688277600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1688281200000,
                    "value": 54,
                    "value2": 0.04
                },
                {
                    "date": 1688284800000,
                    "value": 35.875,
                    "value2": 0.04
                },
                {
                    "date": 1688288400000,
                    "value": 32,
                    "value2": 0.04
                },
                {
                    "date": 1688292000000,
                    "value": 43.875,
                    "value2": 0.04
                },
                {
                    "date": 1688295600000,
                    "value": 39.875,
                    "value2": 0.04
                },
                {
                    "date": 1688299200000,
                    "value": 13,
                    "value2": 0.04
                },
                {
                    "date": 1688302800000,
                    "value": 6.875,
                    "value2": 0.04
                },
                {
                    "date": 1688306400000,
                    "value": 11,
                    "value2": 0.04
                },
                {
                    "date": 1688310000000,
                    "value": 17.125,
                    "value2": 0.04
                },
                {
                    "date": 1688313600000,
                    "value": 18,
                    "value2": 0.04
                },
                {
                    "date": 1688320800000,
                    "value": 51.875,
                    "value2": 0.08
                },
                {
                    "date": 1688324400000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1688328000000,
                    "value": 63.125,
                    "value2": 0.08
                },
                {
                    "date": 1688331600000,
                    "value": 65,
                    "value2": 0.08
                },
                {
                    "date": 1688335200000,
                    "value": 56.875,
                    "value2": 0.08
                },
                {
                    "date": 1688342400000,
                    "value": 86,
                    "value2": 0.08
                },
                {
                    "date": 1688346000000,
                    "value": 87.875,
                    "value2": 0.08
                },
                {
                    "date": 1688349600000,
                    "value": 83.875,
                    "value2": 0.08
                },
                {
                    "date": 1688353200000,
                    "value": 86,
                    "value2": 0.08
                },
                {
                    "date": 1688356800000,
                    "value": 87,
                    "value2": 0.08
                },
                {
                    "date": 1688360400000,
                    "value": 89.125,
                    "value2": 0.08
                },
                {
                    "date": 1688364000000,
                    "value": 105.875,
                    "value2": 0.08
                },
                {
                    "date": 1688367600000,
                    "value": 113,
                    "value2": 18.16
                },
                {
                    "date": 1688371200000,
                    "value": 119,
                    "value2": 46.06
                },
                {
                    "date": 1688374800000,
                    "value": 129,
                    "value2": 49.38
                },
                {
                    "date": 1688378400000,
                    "value": 107,
                    "value2": 49.300000000000004
                },
                {
                    "date": 1688382000000,
                    "value": 94,
                    "value2": 31.14
                },
                {
                    "date": 1688385600000,
                    "value": 76,
                    "value2": 37.11
                },
                {
                    "date": 1688389200000,
                    "value": 86.125,
                    "value2": 42.54
                },
                {
                    "date": 1688392800000,
                    "value": 89,
                    "value2": 38.89
                },
                {
                    "date": 1688396400000,
                    "value": 92,
                    "value2": 28.11
                },
                {
                    "date": 1688400000000,
                    "value": 105,
                    "value2": 10.53
                },
                {
                    "date": 1688407200000,
                    "value": 76.125,
                    "value2": 0
                },
                {
                    "date": 1688410800000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1688414400000,
                    "value": 70.125,
                    "value2": 0
                },
                {
                    "date": 1688418000000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1688428800000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1688432400000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1688436000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1688439600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1688443200000,
                    "value": 65.125,
                    "value2": 0
                },
                {
                    "date": 1688446800000,
                    "value": 83.875,
                    "value2": 0
                },
                {
                    "date": 1688450400000,
                    "value": 105,
                    "value2": 0
                },
                {
                    "date": 1688454000000,
                    "value": 112,
                    "value2": 26.82
                },
                {
                    "date": 1688457600000,
                    "value": 120.125,
                    "value2": 52.99
                },
                {
                    "date": 1688461200000,
                    "value": 115.875,
                    "value2": 60.95
                },
                {
                    "date": 1688464800000,
                    "value": 102,
                    "value2": 59.83
                },
                {
                    "date": 1688468400000,
                    "value": 86,
                    "value2": 40.13
                },
                {
                    "date": 1688472000000,
                    "value": 97.125,
                    "value2": 45.77
                },
                {
                    "date": 1688475600000,
                    "value": 125.125,
                    "value2": 54.19
                },
                {
                    "date": 1688479200000,
                    "value": 123,
                    "value2": 50.79
                },
                {
                    "date": 1688482800000,
                    "value": 111,
                    "value2": 37.230000000000004
                },
                {
                    "date": 1688486400000,
                    "value": 112,
                    "value2": 13.02
                },
                {
                    "date": 1688493600000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1688497200000,
                    "value": 73,
                    "value2": 0
                },
                {
                    "date": 1688500800000,
                    "value": 69.125,
                    "value2": 0
                },
                {
                    "date": 1688504400000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1688508000000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1688515200000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1688518800000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1688522400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1688526000000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1688529600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1688533200000,
                    "value": 82,
                    "value2": 0
                },
                {
                    "date": 1688536800000,
                    "value": 104,
                    "value2": 0
                },
                {
                    "date": 1688540400000,
                    "value": 113.875,
                    "value2": 18.37
                },
                {
                    "date": 1688544000000,
                    "value": 121.125,
                    "value2": 40.26
                },
                {
                    "date": 1688547600000,
                    "value": 113.875,
                    "value2": 45.27
                },
                {
                    "date": 1688551200000,
                    "value": 105,
                    "value2": 45.32
                },
                {
                    "date": 1688554800000,
                    "value": 104,
                    "value2": 31.43
                },
                {
                    "date": 1688558400000,
                    "value": 98.875,
                    "value2": 37.4
                },
                {
                    "date": 1688562000000,
                    "value": 112,
                    "value2": 39.88
                },
                {
                    "date": 1688565600000,
                    "value": 98.875,
                    "value2": 36.28
                },
                {
                    "date": 1688569200000,
                    "value": 103.125,
                    "value2": 27.36
                },
                {
                    "date": 1688572800000,
                    "value": 109.875,
                    "value2": 10.950000000000001
                },
                {
                    "date": 1688580000000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1688583600000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1688587200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1688590800000,
                    "value": 69.875,
                    "value2": 0
                },
                {
                    "date": 1688594400000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1688601600000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1688605200000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1688608800000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1688612400000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1688616000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1688619600000,
                    "value": 83.125,
                    "value2": 0
                },
                {
                    "date": 1688623200000,
                    "value": 103,
                    "value2": 0
                },
                {
                    "date": 1688626800000,
                    "value": 116,
                    "value2": 20.98
                },
                {
                    "date": 1688641200000,
                    "value": 88.125,
                    "value2": 30.47
                },
                {
                    "date": 1688644800000,
                    "value": 77,
                    "value2": 38.52
                },
                {
                    "date": 1688648400000,
                    "value": 86.875,
                    "value2": 44.900000000000006
                },
                {
                    "date": 1688652000000,
                    "value": 98.875,
                    "value2": 40.63
                },
                {
                    "date": 1688655600000,
                    "value": 87,
                    "value2": 30.93
                },
                {
                    "date": 1688659200000,
                    "value": 99.875,
                    "value2": 11.03
                },
                {
                    "date": 1688666400000,
                    "value": 73,
                    "value2": 0
                },
                {
                    "date": 1688670000000,
                    "value": 70.875,
                    "value2": 0
                },
                {
                    "date": 1688673600000,
                    "value": 76.125,
                    "value2": 0
                },
                {
                    "date": 1688677200000,
                    "value": 71.875,
                    "value2": 0
                },
                {
                    "date": 1688680800000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1688688000000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1688691600000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1688695200000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1688698800000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1688702400000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1688706000000,
                    "value": 88,
                    "value2": 0
                },
                {
                    "date": 1688709600000,
                    "value": 108,
                    "value2": 0
                },
                {
                    "date": 1688713200000,
                    "value": 117,
                    "value2": 9.200000000000001
                },
                {
                    "date": 1688716800000,
                    "value": 124,
                    "value2": 19.650000000000002
                },
                {
                    "date": 1688720400000,
                    "value": 118,
                    "value2": 20.19
                },
                {
                    "date": 1688724000000,
                    "value": 105,
                    "value2": 19.900000000000002
                },
                {
                    "date": 1688727600000,
                    "value": 112,
                    "value2": 15.22
                },
                {
                    "date": 1688731200000,
                    "value": 104.875,
                    "value2": 16
                },
                {
                    "date": 1688734800000,
                    "value": 94.125,
                    "value2": 16.79
                },
                {
                    "date": 1688738400000,
                    "value": 89.125,
                    "value2": 13.72
                },
                {
                    "date": 1688742000000,
                    "value": 83.875,
                    "value2": 8.370000000000001
                },
                {
                    "date": 1688745600000,
                    "value": 95,
                    "value2": 0
                },
                {
                    "date": 1688752800000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1688756400000,
                    "value": 70.125,
                    "value2": 0
                },
                {
                    "date": 1688760000000,
                    "value": 73,
                    "value2": 0
                },
                {
                    "date": 1688763600000,
                    "value": 71,
                    "value2": 0
                },
                {
                    "date": 1688767200000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1688774400000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1688778000000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1688781600000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1688785200000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1688788800000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1688792400000,
                    "value": 90.875,
                    "value2": 0
                },
                {
                    "date": 1688796000000,
                    "value": 93.875,
                    "value2": 0
                },
                {
                    "date": 1688799600000,
                    "value": 94,
                    "value2": 0
                },
                {
                    "date": 1688803200000,
                    "value": 99.125,
                    "value2": 0
                },
                {
                    "date": 1688806800000,
                    "value": 90.125,
                    "value2": 0.04
                },
                {
                    "date": 1688810400000,
                    "value": 73.875,
                    "value2": 0.04
                },
                {
                    "date": 1688814000000,
                    "value": 54,
                    "value2": 0.04
                },
                {
                    "date": 1688817600000,
                    "value": 36,
                    "value2": 0.04
                },
                {
                    "date": 1688821200000,
                    "value": 2.875,
                    "value2": 0.04
                },
                {
                    "date": 1688824800000,
                    "value": 9.125,
                    "value2": 0.04
                },
                {
                    "date": 1688828400000,
                    "value": 21,
                    "value2": 0.04
                },
                {
                    "date": 1688832000000,
                    "value": 24.875,
                    "value2": 0.04
                },
                {
                    "date": 1688839200000,
                    "value": 52,
                    "value2": 0.04
                },
                {
                    "date": 1688842800000,
                    "value": 60,
                    "value2": 0.04
                },
                {
                    "date": 1688846400000,
                    "value": 67.125,
                    "value2": 0.04
                },
                {
                    "date": 1688850000000,
                    "value": 65,
                    "value2": 0.04
                },
                {
                    "date": 1688853600000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1688860800000,
                    "value": 63.125,
                    "value2": 0.04
                },
                {
                    "date": 1688864400000,
                    "value": 60.875,
                    "value2": 0.04
                },
                {
                    "date": 1688868000000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1688871600000,
                    "value": 62,
                    "value2": 0.04
                },
                {
                    "date": 1688875200000,
                    "value": 61.875,
                    "value2": 0.04
                },
                {
                    "date": 1688878800000,
                    "value": 61,
                    "value2": 0.04
                },
                {
                    "date": 1688882400000,
                    "value": 60,
                    "value2": 0.04
                },
                {
                    "date": 1688886000000,
                    "value": 55.875,
                    "value2": 0.04
                },
                {
                    "date": 1688889600000,
                    "value": 49,
                    "value2": 0
                },
                {
                    "date": 1688893200000,
                    "value": 55.125,
                    "value2": 0.04
                },
                {
                    "date": 1688896800000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1688900400000,
                    "value": 35.125,
                    "value2": 0.04
                },
                {
                    "date": 1688904000000,
                    "value": 2.125,
                    "value2": 0
                },
                {
                    "date": 1688907600000,
                    "value": 1.875,
                    "value2": 0
                },
                {
                    "date": 1688911200000,
                    "value": 5.125,
                    "value2": 0.04
                },
                {
                    "date": 1688914800000,
                    "value": 45,
                    "value2": 0.04
                },
                {
                    "date": 1688918400000,
                    "value": 54,
                    "value2": 0.04
                },
                {
                    "date": 1688925600000,
                    "value": 62,
                    "value2": 0.12
                },
                {
                    "date": 1688929200000,
                    "value": 65.875,
                    "value2": 0.12
                },
                {
                    "date": 1688932800000,
                    "value": 61.875,
                    "value2": 0.12
                },
                {
                    "date": 1688936400000,
                    "value": 61.125,
                    "value2": 0.12
                },
                {
                    "date": 1688940000000,
                    "value": 54.875,
                    "value2": 0.12
                },
                {
                    "date": 1688947200000,
                    "value": 86.125,
                    "value2": 0.12
                },
                {
                    "date": 1688950800000,
                    "value": 87,
                    "value2": 0.12
                },
                {
                    "date": 1688954400000,
                    "value": 86.125,
                    "value2": 0.12
                },
                {
                    "date": 1688958000000,
                    "value": 86.875,
                    "value2": 0.12
                },
                {
                    "date": 1688961600000,
                    "value": 87,
                    "value2": 0.12
                },
                {
                    "date": 1688965200000,
                    "value": 88,
                    "value2": 0.12
                },
                {
                    "date": 1688968800000,
                    "value": 104.875,
                    "value2": 0.12
                },
                {
                    "date": 1688972400000,
                    "value": 118,
                    "value2": 17.95
                },
                {
                    "date": 1688976000000,
                    "value": 123,
                    "value2": 43.45
                },
                {
                    "date": 1688979600000,
                    "value": 77.875,
                    "value2": 47.800000000000004
                },
                {
                    "date": 1688983200000,
                    "value": 100,
                    "value2": 46.1
                },
                {
                    "date": 1688986800000,
                    "value": 88.875,
                    "value2": 32.01
                },
                {
                    "date": 1688990400000,
                    "value": 88,
                    "value2": 36.57
                },
                {
                    "date": 1688994000000,
                    "value": 93.875,
                    "value2": 40.88
                },
                {
                    "date": 1688997600000,
                    "value": 96,
                    "value2": 37.35
                },
                {
                    "date": 1689001200000,
                    "value": 88.875,
                    "value2": 28.73
                },
                {
                    "date": 1689004800000,
                    "value": 99,
                    "value2": 11.65
                },
                {
                    "date": 1689012000000,
                    "value": 72.125,
                    "value2": 0
                },
                {
                    "date": 1689015600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1689019200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1689022800000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1689026400000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1689033600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1689037200000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1689040800000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1689044400000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1689048000000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1689051600000,
                    "value": 83.875,
                    "value2": 0
                },
                {
                    "date": 1689055200000,
                    "value": 108.875,
                    "value2": 0
                },
                {
                    "date": 1689058800000,
                    "value": 121.125,
                    "value2": 24.34
                },
                {
                    "date": 1689062400000,
                    "value": 129.125,
                    "value2": 54.85
                },
                {
                    "date": 1689066000000,
                    "value": 123,
                    "value2": 60.82
                },
                {
                    "date": 1689069600000,
                    "value": 97.875,
                    "value2": 60.28
                },
                {
                    "date": 1689073200000,
                    "value": 83,
                    "value2": 41.58
                },
                {
                    "date": 1689076800000,
                    "value": 79,
                    "value2": 48.34
                },
                {
                    "date": 1689080400000,
                    "value": 89.125,
                    "value2": 53.400000000000006
                },
                {
                    "date": 1689084000000,
                    "value": 94.125,
                    "value2": 50.5
                },
                {
                    "date": 1689087600000,
                    "value": 95,
                    "value2": 37.77
                },
                {
                    "date": 1689091200000,
                    "value": 101,
                    "value2": 11.24
                },
                {
                    "date": 1689098400000,
                    "value": 78,
                    "value2": 0
                },
                {
                    "date": 1689102000000,
                    "value": 74,
                    "value2": 0
                },
                {
                    "date": 1689105600000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1689109200000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1689112800000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1689120000000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1689123600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1689127200000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1689130800000,
                    "value": 65.125,
                    "value2": 0
                },
                {
                    "date": 1689134400000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1689138000000,
                    "value": 82.125,
                    "value2": 0
                },
                {
                    "date": 1689141600000,
                    "value": 102,
                    "value2": 0
                },
                {
                    "date": 1689145200000,
                    "value": 111,
                    "value2": 17.45
                },
                {
                    "date": 1689148800000,
                    "value": 119.125,
                    "value2": 37.44
                },
                {
                    "date": 1689152400000,
                    "value": 114.875,
                    "value2": 40.63
                },
                {
                    "date": 1689156000000,
                    "value": 104.125,
                    "value2": 39.72
                },
                {
                    "date": 1689159600000,
                    "value": 90.125,
                    "value2": 28.73
                },
                {
                    "date": 1689163200000,
                    "value": 83.125,
                    "value2": 35.12
                },
                {
                    "date": 1689166800000,
                    "value": 101,
                    "value2": 38.85
                },
                {
                    "date": 1689170400000,
                    "value": 100,
                    "value2": 34.62
                },
                {
                    "date": 1689174000000,
                    "value": 98.875,
                    "value2": 26.16
                },
                {
                    "date": 1689177600000,
                    "value": 95,
                    "value2": 10.99
                },
                {
                    "date": 1689184800000,
                    "value": 74,
                    "value2": 0
                },
                {
                    "date": 1689188400000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1689192000000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1689195600000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1689199200000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1689206400000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1689210000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1689213600000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1689217200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1689220800000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1689224400000,
                    "value": 83,
                    "value2": 0
                },
                {
                    "date": 1689228000000,
                    "value": 101,
                    "value2": 0
                },
                {
                    "date": 1689231600000,
                    "value": 107,
                    "value2": 14.100000000000001
                },
                {
                    "date": 1689235200000,
                    "value": 113,
                    "value2": 34.160000000000004
                },
                {
                    "date": 1689238800000,
                    "value": 106,
                    "value2": 38.02
                },
                {
                    "date": 1689242400000,
                    "value": 109,
                    "value2": 36.980000000000004
                },
                {
                    "date": 1689246000000,
                    "value": 111,
                    "value2": 20.02
                },
                {
                    "date": 1689249600000,
                    "value": 96,
                    "value2": 25.21
                },
                {
                    "date": 1689253200000,
                    "value": 102.875,
                    "value2": 30.560000000000002
                },
                {
                    "date": 1689256800000,
                    "value": 92,
                    "value2": 27.990000000000002
                },
                {
                    "date": 1689260400000,
                    "value": 103.875,
                    "value2": 18.45
                },
                {
                    "date": 1689264000000,
                    "value": 110.125,
                    "value2": 1.29
                },
                {
                    "date": 1689271200000,
                    "value": 75,
                    "value2": 0.04
                },
                {
                    "date": 1689274800000,
                    "value": 60.125,
                    "value2": 0.04
                },
                {
                    "date": 1689278400000,
                    "value": 74,
                    "value2": 0.04
                },
                {
                    "date": 1689282000000,
                    "value": 66.875,
                    "value2": 0.04
                },
                {
                    "date": 1689285600000,
                    "value": 61,
                    "value2": 0.04
                },
                {
                    "date": 1689292800000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1689296400000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1689300000000,
                    "value": 64.875,
                    "value2": 0.04
                },
                {
                    "date": 1689303600000,
                    "value": 67.125,
                    "value2": 0.04
                },
                {
                    "date": 1689307200000,
                    "value": 65.875,
                    "value2": 0.04
                },
                {
                    "date": 1689310800000,
                    "value": 82.875,
                    "value2": 0.04
                },
                {
                    "date": 1689314400000,
                    "value": 97,
                    "value2": 0.04
                },
                {
                    "date": 1689318000000,
                    "value": 96,
                    "value2": 0.17
                },
                {
                    "date": 1689321600000,
                    "value": 85,
                    "value2": 0.9500000000000001
                },
                {
                    "date": 1689325200000,
                    "value": 80,
                    "value2": 0.91
                },
                {
                    "date": 1689328800000,
                    "value": 67,
                    "value2": 0.91
                },
                {
                    "date": 1689332400000,
                    "value": 59,
                    "value2": 0.33
                },
                {
                    "date": 1689336000000,
                    "value": 54,
                    "value2": 0.37
                },
                {
                    "date": 1689339600000,
                    "value": 57,
                    "value2": 1.16
                },
                {
                    "date": 1689343200000,
                    "value": 62,
                    "value2": 1.16
                },
                {
                    "date": 1689346800000,
                    "value": 59.125,
                    "value2": 1.16
                },
                {
                    "date": 1689350400000,
                    "value": 77,
                    "value2": 1.08
                },
                {
                    "date": 1689357600000,
                    "value": 60.125,
                    "value2": 0.29
                },
                {
                    "date": 1689361200000,
                    "value": 66.875,
                    "value2": 0.29
                },
                {
                    "date": 1689364800000,
                    "value": 67.875,
                    "value2": 0.29
                },
                {
                    "date": 1689368400000,
                    "value": 67,
                    "value2": 0.29
                },
                {
                    "date": 1689372000000,
                    "value": 59,
                    "value2": 0.29
                },
                {
                    "date": 1689379200000,
                    "value": 67,
                    "value2": 0.29
                },
                {
                    "date": 1689382800000,
                    "value": 65,
                    "value2": 0.29
                },
                {
                    "date": 1689386400000,
                    "value": 64,
                    "value2": 0.29
                },
                {
                    "date": 1689390000000,
                    "value": 63,
                    "value2": 0.29
                },
                {
                    "date": 1689393600000,
                    "value": 62.875,
                    "value2": 0.29
                },
                {
                    "date": 1689397200000,
                    "value": 88.125,
                    "value2": 0.29
                },
                {
                    "date": 1689400800000,
                    "value": 91,
                    "value2": 0.29
                },
                {
                    "date": 1689404400000,
                    "value": 91,
                    "value2": 0
                },
                {
                    "date": 1689408000000,
                    "value": 87.875,
                    "value2": 0.33
                },
                {
                    "date": 1689411600000,
                    "value": 83.875,
                    "value2": 0.29
                },
                {
                    "date": 1689415200000,
                    "value": 74,
                    "value2": 0.25
                },
                {
                    "date": 1689418800000,
                    "value": 56,
                    "value2": 0.04
                },
                {
                    "date": 1689422400000,
                    "value": 52.125,
                    "value2": 0.41000000000000003
                },
                {
                    "date": 1689426000000,
                    "value": 43,
                    "value2": 0.41000000000000003
                },
                {
                    "date": 1689429600000,
                    "value": 19,
                    "value2": 0.29
                },
                {
                    "date": 1689433200000,
                    "value": 32,
                    "value2": 0.29
                },
                {
                    "date": 1689436800000,
                    "value": 33,
                    "value2": 0.12
                },
                {
                    "date": 1689444000000,
                    "value": 34.875,
                    "value2": 0.08
                },
                {
                    "date": 1689447600000,
                    "value": 59.875,
                    "value2": 0.08
                },
                {
                    "date": 1689451200000,
                    "value": 62.125,
                    "value2": 0.08
                },
                {
                    "date": 1689454800000,
                    "value": 60,
                    "value2": 0.08
                },
                {
                    "date": 1689458400000,
                    "value": 54,
                    "value2": 0.08
                },
                {
                    "date": 1689465600000,
                    "value": 58.125,
                    "value2": 0.08
                },
                {
                    "date": 1689469200000,
                    "value": 59,
                    "value2": 0.08
                },
                {
                    "date": 1689472800000,
                    "value": 58.125,
                    "value2": 0.08
                },
                {
                    "date": 1689476400000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1689480000000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1689483600000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1689487200000,
                    "value": 56.875,
                    "value2": 0.08
                },
                {
                    "date": 1689490800000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1689494400000,
                    "value": 54.875,
                    "value2": 0
                },
                {
                    "date": 1689498000000,
                    "value": 36,
                    "value2": 0
                },
                {
                    "date": 1689501600000,
                    "value": 9.125,
                    "value2": 0
                },
                {
                    "date": 1689505200000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1689508800000,
                    "value": 13,
                    "value2": 0
                },
                {
                    "date": 1689512400000,
                    "value": 11.875,
                    "value2": 0
                },
                {
                    "date": 1689516000000,
                    "value": 16,
                    "value2": 0.04
                },
                {
                    "date": 1689519600000,
                    "value": 2.125,
                    "value2": 0.04
                },
                {
                    "date": 1689523200000,
                    "value": 20.125,
                    "value2": 0.04
                },
                {
                    "date": 1689530400000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1689534000000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1689537600000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1689541200000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1689544800000,
                    "value": 54,
                    "value2": 0
                },
                {
                    "date": 1689552000000,
                    "value": 82.125,
                    "value2": 0
                },
                {
                    "date": 1689555600000,
                    "value": 81.875,
                    "value2": 0
                },
                {
                    "date": 1689559200000,
                    "value": 82,
                    "value2": 0
                },
                {
                    "date": 1689562800000,
                    "value": 83.125,
                    "value2": 0
                },
                {
                    "date": 1689566400000,
                    "value": 83.875,
                    "value2": 0
                },
                {
                    "date": 1689570000000,
                    "value": 86,
                    "value2": 0
                },
                {
                    "date": 1689573600000,
                    "value": 101,
                    "value2": 0
                },
                {
                    "date": 1689577200000,
                    "value": 113,
                    "value2": 15.75
                },
                {
                    "date": 1689580800000,
                    "value": 117,
                    "value2": 35.03
                },
                {
                    "date": 1689584400000,
                    "value": 110.125,
                    "value2": 37.52
                },
                {
                    "date": 1689588000000,
                    "value": 95,
                    "value2": 36.980000000000004
                },
                {
                    "date": 1689591600000,
                    "value": 74.875,
                    "value2": 29.85
                },
                {
                    "date": 1689595200000,
                    "value": 78.125,
                    "value2": 32.79
                },
                {
                    "date": 1689598800000,
                    "value": 91,
                    "value2": 35.660000000000004
                },
                {
                    "date": 1689602400000,
                    "value": 90,
                    "value2": 32.46
                },
                {
                    "date": 1689606000000,
                    "value": 91,
                    "value2": 23.3
                },
                {
                    "date": 1689609600000,
                    "value": 97.125,
                    "value2": 9.41
                },
                {
                    "date": 1689616800000,
                    "value": 77.125,
                    "value2": 0
                },
                {
                    "date": 1689620400000,
                    "value": 76,
                    "value2": 0
                },
                {
                    "date": 1689624000000,
                    "value": 69.875,
                    "value2": 0
                },
                {
                    "date": 1689627600000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1689631200000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1689638400000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1689642000000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1689645600000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1689649200000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1689652800000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1689656400000,
                    "value": 83,
                    "value2": 0
                },
                {
                    "date": 1689660000000,
                    "value": 100,
                    "value2": 0
                },
                {
                    "date": 1689663600000,
                    "value": 109.875,
                    "value2": 20.56
                },
                {
                    "date": 1689667200000,
                    "value": 118,
                    "value2": 48.51
                },
                {
                    "date": 1689670800000,
                    "value": 118,
                    "value2": 53.900000000000006
                },
                {
                    "date": 1689674400000,
                    "value": 98.125,
                    "value2": 53.65
                },
                {
                    "date": 1689678000000,
                    "value": 82.125,
                    "value2": 38.1
                },
                {
                    "date": 1689681600000,
                    "value": 80,
                    "value2": 42.21
                },
                {
                    "date": 1689685200000,
                    "value": 88.125,
                    "value2": 45.81
                },
                {
                    "date": 1689688800000,
                    "value": 91,
                    "value2": 42.25
                },
                {
                    "date": 1689692400000,
                    "value": 101.875,
                    "value2": 31.88
                },
                {
                    "date": 1689696000000,
                    "value": 110.125,
                    "value2": 12.48
                },
                {
                    "date": 1689699600000,
                    "value": 97,
                    "value2": 0
                },
                {
                    "date": 1689703200000,
                    "value": 76,
                    "value2": 0
                },
                {
                    "date": 1689706800000,
                    "value": 70.875,
                    "value2": 0
                },
                {
                    "date": 1689710400000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1689714000000,
                    "value": 70.875,
                    "value2": 0
                },
                {
                    "date": 1689717600000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1689724800000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1689728400000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1689732000000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1689735600000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1689739200000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1689742800000,
                    "value": 80,
                    "value2": 0
                },
                {
                    "date": 1689746400000,
                    "value": 100,
                    "value2": 0
                },
                {
                    "date": 1689750000000,
                    "value": 113.125,
                    "value2": 15.26
                },
                {
                    "date": 1689753600000,
                    "value": 118,
                    "value2": 38.31
                },
                {
                    "date": 1689757200000,
                    "value": 107,
                    "value2": 42
                },
                {
                    "date": 1689760800000,
                    "value": 104,
                    "value2": 38.76
                },
                {
                    "date": 1689764400000,
                    "value": 92.875,
                    "value2": 26.330000000000002
                },
                {
                    "date": 1689768000000,
                    "value": 89,
                    "value2": 32.17
                },
                {
                    "date": 1689771600000,
                    "value": 99.875,
                    "value2": 36.77
                },
                {
                    "date": 1689775200000,
                    "value": 108.875,
                    "value2": 33.29
                },
                {
                    "date": 1689778800000,
                    "value": 110.125,
                    "value2": 23.26
                },
                {
                    "date": 1689782400000,
                    "value": 106,
                    "value2": 7.5
                },
                {
                    "date": 1689789600000,
                    "value": 73,
                    "value2": 0
                },
                {
                    "date": 1689793200000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1689796800000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1689800400000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1689804000000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1689811200000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1689814800000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1689818400000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1689822000000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1689825600000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1689829200000,
                    "value": 81.875,
                    "value2": 0
                },
                {
                    "date": 1689832800000,
                    "value": 99.875,
                    "value2": 0
                },
                {
                    "date": 1689836400000,
                    "value": 110.125,
                    "value2": 18.91
                },
                {
                    "date": 1689840000000,
                    "value": 118,
                    "value2": 43.78
                },
                {
                    "date": 1689843600000,
                    "value": 112,
                    "value2": 47.93
                },
                {
                    "date": 1689847200000,
                    "value": 91,
                    "value2": 45.44
                },
                {
                    "date": 1689850800000,
                    "value": 81.875,
                    "value2": 29.68
                },
                {
                    "date": 1689854400000,
                    "value": 76.875,
                    "value2": 39.39
                },
                {
                    "date": 1689858000000,
                    "value": 98,
                    "value2": 42.5
                },
                {
                    "date": 1689861600000,
                    "value": 96.875,
                    "value2": 39.34
                },
                {
                    "date": 1689865200000,
                    "value": 95,
                    "value2": 30.6
                },
                {
                    "date": 1689868800000,
                    "value": 115.875,
                    "value2": 14.01
                },
                {
                    "date": 1689876000000,
                    "value": 92,
                    "value2": 0
                },
                {
                    "date": 1689879600000,
                    "value": 74,
                    "value2": 0
                },
                {
                    "date": 1689883200000,
                    "value": 71,
                    "value2": 0
                },
                {
                    "date": 1689886800000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1689890400000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1689897600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1689901200000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1689904800000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1689908400000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1689912000000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1689915600000,
                    "value": 79,
                    "value2": 0
                },
                {
                    "date": 1689919200000,
                    "value": 83,
                    "value2": 0
                },
                {
                    "date": 1689922800000,
                    "value": 86,
                    "value2": 5.800000000000001
                },
                {
                    "date": 1689926400000,
                    "value": 97.125,
                    "value2": 13.52
                },
                {
                    "date": 1689930000000,
                    "value": 97.125,
                    "value2": 15.96
                },
                {
                    "date": 1689933600000,
                    "value": 81,
                    "value2": 15.71
                },
                {
                    "date": 1689937200000,
                    "value": 78,
                    "value2": 10.36
                },
                {
                    "date": 1689940800000,
                    "value": 77.125,
                    "value2": 12.85
                },
                {
                    "date": 1689944400000,
                    "value": 84.125,
                    "value2": 13.39
                },
                {
                    "date": 1689948000000,
                    "value": 95.125,
                    "value2": 11.11
                },
                {
                    "date": 1689951600000,
                    "value": 86.875,
                    "value2": 4.6000000000000005
                },
                {
                    "date": 1689955200000,
                    "value": 102,
                    "value2": 0
                },
                {
                    "date": 1689962400000,
                    "value": 77.125,
                    "value2": 0
                },
                {
                    "date": 1689966000000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1689969600000,
                    "value": 75.875,
                    "value2": 0
                },
                {
                    "date": 1689973200000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1689976800000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1689984000000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1689987600000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1689991200000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1689994800000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1689998400000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1690002000000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1690005600000,
                    "value": 88.125,
                    "value2": 0
                },
                {
                    "date": 1690009200000,
                    "value": 85.125,
                    "value2": 0
                },
                {
                    "date": 1690012800000,
                    "value": 83,
                    "value2": 0.17
                },
                {
                    "date": 1690016400000,
                    "value": 78.875,
                    "value2": 0.17
                },
                {
                    "date": 1690020000000,
                    "value": 61.875,
                    "value2": 0.17
                },
                {
                    "date": 1690023600000,
                    "value": 59,
                    "value2": 0.17
                },
                {
                    "date": 1690027200000,
                    "value": 42.875,
                    "value2": 0.17
                },
                {
                    "date": 1690030800000,
                    "value": 9.125,
                    "value2": 0.12
                },
                {
                    "date": 1690034400000,
                    "value": 6,
                    "value2": 0.08
                },
                {
                    "date": 1690038000000,
                    "value": 9.125,
                    "value2": 0.08
                },
                {
                    "date": 1690041600000,
                    "value": 5,
                    "value2": 0.08
                },
                {
                    "date": 1690048800000,
                    "value": 45.875,
                    "value2": 0.04
                },
                {
                    "date": 1690052400000,
                    "value": 59.875,
                    "value2": 0.04
                },
                {
                    "date": 1690056000000,
                    "value": 65,
                    "value2": 0.04
                },
                {
                    "date": 1690059600000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1690063200000,
                    "value": 63,
                    "value2": 0.04
                },
                {
                    "date": 1690070400000,
                    "value": 61,
                    "value2": 0.04
                },
                {
                    "date": 1690074000000,
                    "value": 60.875,
                    "value2": 0.04
                },
                {
                    "date": 1690077600000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1690081200000,
                    "value": 62,
                    "value2": 0.04
                },
                {
                    "date": 1690084800000,
                    "value": 61,
                    "value2": 0.04
                },
                {
                    "date": 1690088400000,
                    "value": 61,
                    "value2": 0.04
                },
                {
                    "date": 1690092000000,
                    "value": 60,
                    "value2": 0.04
                },
                {
                    "date": 1690095600000,
                    "value": 60.875,
                    "value2": 0.04
                },
                {
                    "date": 1690099200000,
                    "value": 52.125,
                    "value2": 0.04
                },
                {
                    "date": 1690102800000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1690106400000,
                    "value": 51.875,
                    "value2": 0.04
                },
                {
                    "date": 1690110000000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1690113600000,
                    "value": 50,
                    "value2": 0.04
                },
                {
                    "date": 1690117200000,
                    "value": 48,
                    "value2": 0.04
                },
                {
                    "date": 1690120800000,
                    "value": 26,
                    "value2": 0.04
                },
                {
                    "date": 1690124400000,
                    "value": 37,
                    "value2": 0.04
                },
                {
                    "date": 1690128000000,
                    "value": 29.125,
                    "value2": 0.04
                },
                {
                    "date": 1690131600000,
                    "value": 52,
                    "value2": 0.04
                },
                {
                    "date": 1690135200000,
                    "value": 60,
                    "value2": 0.04
                },
                {
                    "date": 1690138800000,
                    "value": 63,
                    "value2": 0.04
                },
                {
                    "date": 1690142400000,
                    "value": 65,
                    "value2": 0.04
                },
                {
                    "date": 1690146000000,
                    "value": 64.875,
                    "value2": 0.04
                },
                {
                    "date": 1690149600000,
                    "value": 55.125,
                    "value2": 0.04
                },
                {
                    "date": 1690156800000,
                    "value": 81,
                    "value2": 0.04
                },
                {
                    "date": 1690160400000,
                    "value": 81.875,
                    "value2": 0.04
                },
                {
                    "date": 1690164000000,
                    "value": 82.875,
                    "value2": 0.04
                },
                {
                    "date": 1690167600000,
                    "value": 84,
                    "value2": 0.04
                },
                {
                    "date": 1690171200000,
                    "value": 85.125,
                    "value2": 0.04
                },
                {
                    "date": 1690174800000,
                    "value": 88.125,
                    "value2": 0.04
                },
                {
                    "date": 1690178400000,
                    "value": 101,
                    "value2": 0.04
                },
                {
                    "date": 1690182000000,
                    "value": 110,
                    "value2": 14.93
                },
                {
                    "date": 1690185600000,
                    "value": 114,
                    "value2": 37.56
                },
                {
                    "date": 1690189200000,
                    "value": 117,
                    "value2": 41.87
                },
                {
                    "date": 1690192800000,
                    "value": 75,
                    "value2": 41
                },
                {
                    "date": 1690196400000,
                    "value": 106,
                    "value2": 28.98
                },
                {
                    "date": 1690200000000,
                    "value": 93.875,
                    "value2": 34.29
                },
                {
                    "date": 1690203600000,
                    "value": 103.875,
                    "value2": 37.56
                },
                {
                    "date": 1690207200000,
                    "value": 110.125,
                    "value2": 34.78
                },
                {
                    "date": 1690210800000,
                    "value": 97,
                    "value2": 27.07
                },
                {
                    "date": 1690214400000,
                    "value": 138,
                    "value2": 9.08
                },
                {
                    "date": 1690221600000,
                    "value": 82,
                    "value2": 0
                },
                {
                    "date": 1690225200000,
                    "value": 72,
                    "value2": 0
                },
                {
                    "date": 1690228800000,
                    "value": 72.125,
                    "value2": 0
                },
                {
                    "date": 1690232400000,
                    "value": 76.875,
                    "value2": 0
                },
                {
                    "date": 1690236000000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1690243200000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1690246800000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1690250400000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1690254000000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1690257600000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1690261200000,
                    "value": 81.875,
                    "value2": 0
                },
                {
                    "date": 1690264800000,
                    "value": 102.875,
                    "value2": 0
                },
                {
                    "date": 1690268400000,
                    "value": 112,
                    "value2": 18.86
                },
                {
                    "date": 1690272000000,
                    "value": 120.125,
                    "value2": 48.71
                },
                {
                    "date": 1690275600000,
                    "value": 113.875,
                    "value2": 54.06
                },
                {
                    "date": 1690279200000,
                    "value": 101.875,
                    "value2": 52.78
                },
                {
                    "date": 1690282800000,
                    "value": 89.125,
                    "value2": 38.35
                },
                {
                    "date": 1690286400000,
                    "value": 92.875,
                    "value2": 44.49
                },
                {
                    "date": 1690290000000,
                    "value": 116.875,
                    "value2": 47.68
                },
                {
                    "date": 1690293600000,
                    "value": 90.125,
                    "value2": 43.03
                },
                {
                    "date": 1690297200000,
                    "value": 105,
                    "value2": 33.21
                },
                {
                    "date": 1690300800000,
                    "value": 112,
                    "value2": 12.19
                },
                {
                    "date": 1690308000000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1690311600000,
                    "value": 70.125,
                    "value2": 0
                },
                {
                    "date": 1690315200000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1690318800000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1690322400000,
                    "value": 54,
                    "value2": 0
                },
                {
                    "date": 1690329600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1690333200000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1690336800000,
                    "value": 58.125,
                    "value2": 0
                },
                {
                    "date": 1690340400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1690344000000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1690347600000,
                    "value": 81,
                    "value2": 0
                },
                {
                    "date": 1690351200000,
                    "value": 98.875,
                    "value2": 0
                },
                {
                    "date": 1690354800000,
                    "value": 106,
                    "value2": 12.06
                },
                {
                    "date": 1690358400000,
                    "value": 118.875,
                    "value2": 32.300000000000004
                },
                {
                    "date": 1690362000000,
                    "value": 109.125,
                    "value2": 36.82
                },
                {
                    "date": 1690365600000,
                    "value": 88,
                    "value2": 37.11
                },
                {
                    "date": 1690369200000,
                    "value": 80,
                    "value2": 22.43
                },
                {
                    "date": 1690372800000,
                    "value": 71,
                    "value2": 30.1
                },
                {
                    "date": 1690376400000,
                    "value": 88.125,
                    "value2": 35.2
                },
                {
                    "date": 1690380000000,
                    "value": 92.125,
                    "value2": 32.92
                },
                {
                    "date": 1690383600000,
                    "value": 100.125,
                    "value2": 24.3
                },
                {
                    "date": 1690387200000,
                    "value": 103.125,
                    "value2": 8.13
                },
                {
                    "date": 1690390800000,
                    "value": 87.125,
                    "value2": 0
                },
                {
                    "date": 1690394400000,
                    "value": 71,
                    "value2": 0
                },
                {
                    "date": 1690398000000,
                    "value": 71.125,
                    "value2": 0
                },
                {
                    "date": 1690401600000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1690405200000,
                    "value": 70.875,
                    "value2": 0
                },
                {
                    "date": 1690408800000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1690416000000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1690419600000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1690423200000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1690426800000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1690430400000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1690434000000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1690437600000,
                    "value": 103.125,
                    "value2": 0
                },
                {
                    "date": 1690441200000,
                    "value": 109.875,
                    "value2": 14.47
                },
                {
                    "date": 1690444800000,
                    "value": 112,
                    "value2": 36.19
                },
                {
                    "date": 1690448400000,
                    "value": 111,
                    "value2": 40.800000000000004
                },
                {
                    "date": 1690452000000,
                    "value": 105,
                    "value2": 39.550000000000004
                },
                {
                    "date": 1690455600000,
                    "value": 105,
                    "value2": 24.71
                },
                {
                    "date": 1690459200000,
                    "value": 102.125,
                    "value2": 30.93
                },
                {
                    "date": 1690462800000,
                    "value": 108.125,
                    "value2": 35.36
                },
                {
                    "date": 1690466400000,
                    "value": 120.875,
                    "value2": 31.88
                },
                {
                    "date": 1690502400000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1690506000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1690509600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1690513200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1690516800000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1690520400000,
                    "value": 84,
                    "value2": 0
                },
                {
                    "date": 1690524000000,
                    "value": 103,
                    "value2": 0
                },
                {
                    "date": 1690527600000,
                    "value": 108.875,
                    "value2": 4.44
                },
                {
                    "date": 1690531200000,
                    "value": 116,
                    "value2": 10.24
                },
                {
                    "date": 1690534800000,
                    "value": 110.125,
                    "value2": 11.61
                },
                {
                    "date": 1690538400000,
                    "value": 111,
                    "value2": 11.57
                },
                {
                    "date": 1690542000000,
                    "value": 93.125,
                    "value2": 9.58
                },
                {
                    "date": 1690545600000,
                    "value": 93,
                    "value2": 9.99
                },
                {
                    "date": 1690549200000,
                    "value": 94.875,
                    "value2": 10.49
                },
                {
                    "date": 1690552800000,
                    "value": 88,
                    "value2": 8.25
                },
                {
                    "date": 1690578000000,
                    "value": 70.875,
                    "value2": 0.08
                },
                {
                    "date": 1690581600000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1690588800000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1690592400000,
                    "value": 64.875,
                    "value2": 0.08
                },
                {
                    "date": 1690596000000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1690599600000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1690603200000,
                    "value": 65,
                    "value2": 0.08
                },
                {
                    "date": 1690606800000,
                    "value": 87.875,
                    "value2": 0.08
                },
                {
                    "date": 1690610400000,
                    "value": 94,
                    "value2": 0.08
                },
                {
                    "date": 1690614000000,
                    "value": 94.125,
                    "value2": 0.08
                },
                {
                    "date": 1690617600000,
                    "value": 87.125,
                    "value2": 0.21
                },
                {
                    "date": 1690621200000,
                    "value": 80,
                    "value2": 0.21
                },
                {
                    "date": 1690624800000,
                    "value": 72.125,
                    "value2": 0.21
                },
                {
                    "date": 1690628400000,
                    "value": 81,
                    "value2": 0.12
                },
                {
                    "date": 1690632000000,
                    "value": 57.125,
                    "value2": 0.12
                },
                {
                    "date": 1690635600000,
                    "value": 22.875,
                    "value2": 0.08
                },
                {
                    "date": 1690639200000,
                    "value": 8.125,
                    "value2": 0.08
                },
                {
                    "date": 1690642800000,
                    "value": 35.125,
                    "value2": 0.08
                },
                {
                    "date": 1690646400000,
                    "value": 27,
                    "value2": 0.08
                },
                {
                    "date": 1690653600000,
                    "value": 57.125,
                    "value2": 0.08
                },
                {
                    "date": 1690657200000,
                    "value": 60,
                    "value2": 0.08
                },
                {
                    "date": 1690660800000,
                    "value": 64.875,
                    "value2": 0.08
                },
                {
                    "date": 1690664400000,
                    "value": 59.875,
                    "value2": 0.08
                },
                {
                    "date": 1690668000000,
                    "value": 55.125,
                    "value2": 0.08
                },
                {
                    "date": 1690675200000,
                    "value": 58.875,
                    "value2": 0.08
                },
                {
                    "date": 1690678800000,
                    "value": 57.125,
                    "value2": 0.08
                },
                {
                    "date": 1690682400000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1690686000000,
                    "value": 56.875,
                    "value2": 0.08
                },
                {
                    "date": 1690689600000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1690693200000,
                    "value": 58,
                    "value2": 0.08
                },
                {
                    "date": 1690696800000,
                    "value": 58.125,
                    "value2": 0.08
                },
                {
                    "date": 1690700400000,
                    "value": 54.875,
                    "value2": 0.04
                },
                {
                    "date": 1690704000000,
                    "value": 52,
                    "value2": 0.04
                },
                {
                    "date": 1690707600000,
                    "value": 35.125,
                    "value2": 0.04
                },
                {
                    "date": 1690711200000,
                    "value": 25.125,
                    "value2": 0.04
                },
                {
                    "date": 1690714800000,
                    "value": 17.875,
                    "value2": 0.04
                },
                {
                    "date": 1690718400000,
                    "value": 9.125,
                    "value2": 0.04
                },
                {
                    "date": 1690722000000,
                    "value": 11,
                    "value2": 0
                },
                {
                    "date": 1690725600000,
                    "value": 15,
                    "value2": 0
                },
                {
                    "date": 1690729200000,
                    "value": 13.875,
                    "value2": 0
                },
                {
                    "date": 1690732800000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1690740000000,
                    "value": 56.125,
                    "value2": 0
                },
                {
                    "date": 1690743600000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1690747200000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1690750800000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1690754400000,
                    "value": 55.125,
                    "value2": 0
                },
                {
                    "date": 1690761600000,
                    "value": 84,
                    "value2": 0
                },
                {
                    "date": 1690765200000,
                    "value": 84.125,
                    "value2": 0
                },
                {
                    "date": 1690768800000,
                    "value": 86,
                    "value2": 0
                },
                {
                    "date": 1690772400000,
                    "value": 85.125,
                    "value2": 0
                },
                {
                    "date": 1690776000000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1690779600000,
                    "value": 86.875,
                    "value2": 0
                },
                {
                    "date": 1690783200000,
                    "value": 98.875,
                    "value2": 0
                },
                {
                    "date": 1690786800000,
                    "value": 108,
                    "value2": 11.07
                },
                {
                    "date": 1690790400000,
                    "value": 111,
                    "value2": 30.02
                },
                {
                    "date": 1690794000000,
                    "value": 107,
                    "value2": 32.63
                },
                {
                    "date": 1690797600000,
                    "value": 108,
                    "value2": 32.84
                },
                {
                    "date": 1690801200000,
                    "value": 108.875,
                    "value2": 24.59
                },
                {
                    "date": 1690804800000,
                    "value": 110,
                    "value2": 26.37
                },
                {
                    "date": 1690808400000,
                    "value": 119.875,
                    "value2": 27.36
                },
                {
                    "date": 1690812000000,
                    "value": 123,
                    "value2": 25.330000000000002
                },
                {
                    "date": 1690815600000,
                    "value": 118,
                    "value2": 16.29
                },
                {
                    "date": 1690819200000,
                    "value": 123,
                    "value2": 0
                },
                {
                    "date": 1690826400000,
                    "value": 72,
                    "value2": 0
                },
                {
                    "date": 1690830000000,
                    "value": 76,
                    "value2": 0
                },
                {
                    "date": 1690833600000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1690837200000,
                    "value": 73,
                    "value2": 0
                },
                {
                    "date": 1690840800000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1690848000000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1690851600000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1690855200000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1690858800000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1690862400000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1690866000000,
                    "value": 82.125,
                    "value2": 0
                },
                {
                    "date": 1690869600000,
                    "value": 100.125,
                    "value2": 0
                },
                {
                    "date": 1690873200000,
                    "value": 109,
                    "value2": 16.54
                },
                {
                    "date": 1690876800000,
                    "value": 112.875,
                    "value2": 39.34
                },
                {
                    "date": 1690880400000,
                    "value": 106,
                    "value2": 44.980000000000004
                },
                {
                    "date": 1690884000000,
                    "value": 95,
                    "value2": 43.62
                },
                {
                    "date": 1690887600000,
                    "value": 100.875,
                    "value2": 28.77
                },
                {
                    "date": 1690891200000,
                    "value": 88.125,
                    "value2": 35.160000000000004
                },
                {
                    "date": 1690894800000,
                    "value": 93.875,
                    "value2": 39.39
                },
                {
                    "date": 1690898400000,
                    "value": 92,
                    "value2": 35.78
                },
                {
                    "date": 1690902000000,
                    "value": 106,
                    "value2": 25.04
                },
                {
                    "date": 1690905600000,
                    "value": 115,
                    "value2": 4.44
                },
                {
                    "date": 1690912800000,
                    "value": 83.125,
                    "value2": 0.08
                },
                {
                    "date": 1690916400000,
                    "value": 68.125,
                    "value2": 0.08
                },
                {
                    "date": 1690920000000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1690923600000,
                    "value": 61.875,
                    "value2": 0.08
                },
                {
                    "date": 1690927200000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1690934400000,
                    "value": 62.125,
                    "value2": 0.08
                },
                {
                    "date": 1690938000000,
                    "value": 60,
                    "value2": 0.08
                },
                {
                    "date": 1690941600000,
                    "value": 59.875,
                    "value2": 0.08
                },
                {
                    "date": 1690945200000,
                    "value": 63.125,
                    "value2": 0.08
                },
                {
                    "date": 1690948800000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1690952400000,
                    "value": 80.875,
                    "value2": 0.08
                },
                {
                    "date": 1690956000000,
                    "value": 103,
                    "value2": 0.08
                },
                {
                    "date": 1690959600000,
                    "value": 108.875,
                    "value2": 10.700000000000001
                },
                {
                    "date": 1690963200000,
                    "value": 114.125,
                    "value2": 25.95
                },
                {
                    "date": 1690966800000,
                    "value": 106,
                    "value2": 31.3
                },
                {
                    "date": 1690970400000,
                    "value": 93.125,
                    "value2": 29.68
                },
                {
                    "date": 1690974000000,
                    "value": 76,
                    "value2": 20.36
                },
                {
                    "date": 1690977600000,
                    "value": 72,
                    "value2": 27.11
                },
                {
                    "date": 1690981200000,
                    "value": 86,
                    "value2": 28.61
                },
                {
                    "date": 1690984800000,
                    "value": 100,
                    "value2": 25.46
                },
                {
                    "date": 1690988400000,
                    "value": 109.125,
                    "value2": 16.54
                },
                {
                    "date": 1690992000000,
                    "value": 99.875,
                    "value2": 1.16
                },
                {
                    "date": 1690995600000,
                    "value": 95,
                    "value2": 0
                },
                {
                    "date": 1690999200000,
                    "value": 76.125,
                    "value2": 0
                },
                {
                    "date": 1691002800000,
                    "value": 70.875,
                    "value2": 0
                },
                {
                    "date": 1691010000000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1691013600000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1691020800000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1691024400000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1691028000000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1691031600000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691035200000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1691038800000,
                    "value": 81.125,
                    "value2": 0
                },
                {
                    "date": 1691042400000,
                    "value": 100,
                    "value2": 0
                },
                {
                    "date": 1691046000000,
                    "value": 111,
                    "value2": 11.48
                },
                {
                    "date": 1691049600000,
                    "value": 118,
                    "value2": 26.45
                },
                {
                    "date": 1691053200000,
                    "value": 114.125,
                    "value2": 29.27
                },
                {
                    "date": 1691056800000,
                    "value": 103,
                    "value2": 28.19
                },
                {
                    "date": 1691060400000,
                    "value": 104.125,
                    "value2": 20.23
                },
                {
                    "date": 1691064000000,
                    "value": 101,
                    "value2": 23.34
                },
                {
                    "date": 1691067600000,
                    "value": 101,
                    "value2": 24.46
                },
                {
                    "date": 1691071200000,
                    "value": 120.125,
                    "value2": 21.56
                },
                {
                    "date": 1691074800000,
                    "value": 107,
                    "value2": 12.85
                },
                {
                    "date": 1691078400000,
                    "value": 117,
                    "value2": 0
                },
                {
                    "date": 1691085600000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1691089200000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1691092800000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1691096400000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1691100000000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1691107200000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1691110800000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691114400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1691118000000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1691121600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1691125200000,
                    "value": 83.875,
                    "value2": 0
                },
                {
                    "date": 1691128800000,
                    "value": 101,
                    "value2": 0
                },
                {
                    "date": 1691132400000,
                    "value": 105.875,
                    "value2": 4.3500000000000005
                },
                {
                    "date": 1691136000000,
                    "value": 107,
                    "value2": 9.950000000000001
                },
                {
                    "date": 1691139600000,
                    "value": 102.125,
                    "value2": 11.44
                },
                {
                    "date": 1691143200000,
                    "value": 85,
                    "value2": 10.99
                },
                {
                    "date": 1691146800000,
                    "value": 85,
                    "value2": 9.290000000000001
                },
                {
                    "date": 1691150400000,
                    "value": 101,
                    "value2": 9.66
                },
                {
                    "date": 1691154000000,
                    "value": 75,
                    "value2": 9.040000000000001
                },
                {
                    "date": 1691157600000,
                    "value": 77.125,
                    "value2": 6.97
                },
                {
                    "date": 1691161200000,
                    "value": 80,
                    "value2": 2.0300000000000002
                },
                {
                    "date": 1691164800000,
                    "value": 103,
                    "value2": 0
                },
                {
                    "date": 1691168400000,
                    "value": 91,
                    "value2": 0
                },
                {
                    "date": 1691172000000,
                    "value": 68,
                    "value2": 0
                },
                {
                    "date": 1691175600000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1691179200000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1691182800000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1691186400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1691193600000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1691197200000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1691200800000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691204400000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1691208000000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1691211600000,
                    "value": 88.125,
                    "value2": 0
                },
                {
                    "date": 1691215200000,
                    "value": 94.125,
                    "value2": 0
                },
                {
                    "date": 1691218800000,
                    "value": 92,
                    "value2": 0.04
                },
                {
                    "date": 1691222400000,
                    "value": 90,
                    "value2": 0.17
                },
                {
                    "date": 1691226000000,
                    "value": 91,
                    "value2": 0.33
                },
                {
                    "date": 1691229600000,
                    "value": 85,
                    "value2": 0.29
                },
                {
                    "date": 1691233200000,
                    "value": 75,
                    "value2": 0.17
                },
                {
                    "date": 1691236800000,
                    "value": 78,
                    "value2": 0.17
                },
                {
                    "date": 1691240400000,
                    "value": 35.875,
                    "value2": 0.12
                },
                {
                    "date": 1691244000000,
                    "value": 33,
                    "value2": 0.08
                },
                {
                    "date": 1691247600000,
                    "value": 8.125,
                    "value2": 0.04
                },
                {
                    "date": 1691251200000,
                    "value": 31.125,
                    "value2": 0.08
                },
                {
                    "date": 1691254800000,
                    "value": 43,
                    "value2": 0
                },
                {
                    "date": 1691258400000,
                    "value": 54.125,
                    "value2": 0
                },
                {
                    "date": 1691262000000,
                    "value": 59.125,
                    "value2": 0
                },
                {
                    "date": 1691265600000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1691269200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1691272800000,
                    "value": 52,
                    "value2": 0
                },
                {
                    "date": 1691280000000,
                    "value": 57,
                    "value2": 0
                },
                {
                    "date": 1691283600000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1691287200000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1691290800000,
                    "value": 58.125,
                    "value2": 0
                },
                {
                    "date": 1691294400000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1691298000000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1691301600000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1691305200000,
                    "value": 55.125,
                    "value2": 0.08
                },
                {
                    "date": 1691308800000,
                    "value": 60,
                    "value2": 0.08
                },
                {
                    "date": 1691312400000,
                    "value": 27,
                    "value2": 0
                },
                {
                    "date": 1691316000000,
                    "value": 10,
                    "value2": 0
                },
                {
                    "date": 1691319600000,
                    "value": 8.125,
                    "value2": 0
                },
                {
                    "date": 1691323200000,
                    "value": 1.875,
                    "value2": 0
                },
                {
                    "date": 1691326800000,
                    "value": 18.875,
                    "value2": 0.08
                },
                {
                    "date": 1691330400000,
                    "value": 16,
                    "value2": 0.08
                },
                {
                    "date": 1691334000000,
                    "value": 14.125,
                    "value2": 0
                },
                {
                    "date": 1691337600000,
                    "value": 39.875,
                    "value2": 0.04
                },
                {
                    "date": 1691341200000,
                    "value": 46.125,
                    "value2": 0
                },
                {
                    "date": 1691344800000,
                    "value": 48,
                    "value2": 0
                },
                {
                    "date": 1691348400000,
                    "value": 56.875,
                    "value2": 0
                },
                {
                    "date": 1691352000000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1691355600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1691359200000,
                    "value": 57.875,
                    "value2": 0
                },
                {
                    "date": 1691366400000,
                    "value": 82.125,
                    "value2": 0
                },
                {
                    "date": 1691370000000,
                    "value": 81.875,
                    "value2": 0
                },
                {
                    "date": 1691373600000,
                    "value": 82.875,
                    "value2": 0
                },
                {
                    "date": 1691377200000,
                    "value": 86,
                    "value2": 0
                },
                {
                    "date": 1691380800000,
                    "value": 84,
                    "value2": 0
                },
                {
                    "date": 1691384400000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1691388000000,
                    "value": 98.875,
                    "value2": 0
                },
                {
                    "date": 1691391600000,
                    "value": 108.125,
                    "value2": 10.41
                },
                {
                    "date": 1691395200000,
                    "value": 118.125,
                    "value2": 23.26
                },
                {
                    "date": 1691398800000,
                    "value": 100,
                    "value2": 25.29
                },
                {
                    "date": 1691402400000,
                    "value": 87.875,
                    "value2": 23.26
                },
                {
                    "date": 1691406000000,
                    "value": 70,
                    "value2": 16.580000000000002
                },
                {
                    "date": 1691409600000,
                    "value": 65,
                    "value2": 19.61
                },
                {
                    "date": 1691413200000,
                    "value": 70,
                    "value2": 21.97
                },
                {
                    "date": 1691416800000,
                    "value": 84,
                    "value2": 18.82
                },
                {
                    "date": 1691420400000,
                    "value": 90,
                    "value2": 11.32
                },
                {
                    "date": 1691424000000,
                    "value": 90,
                    "value2": 0
                },
                {
                    "date": 1691427600000,
                    "value": 80.875,
                    "value2": 0
                },
                {
                    "date": 1691431200000,
                    "value": 75,
                    "value2": 0
                },
                {
                    "date": 1691434800000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1691438400000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1691442000000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1691445600000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1691452800000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691456400000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1691460000000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691463600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1691467200000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1691470800000,
                    "value": 83.125,
                    "value2": 0
                },
                {
                    "date": 1691474400000,
                    "value": 100.125,
                    "value2": 0
                },
                {
                    "date": 1691478000000,
                    "value": 108.875,
                    "value2": 12.65
                },
                {
                    "date": 1691481600000,
                    "value": 112.875,
                    "value2": 29.52
                },
                {
                    "date": 1691485200000,
                    "value": 101.875,
                    "value2": 32.92
                },
                {
                    "date": 1691488800000,
                    "value": 86,
                    "value2": 30.72
                },
                {
                    "date": 1691492400000,
                    "value": 76.125,
                    "value2": 24.17
                },
                {
                    "date": 1691496000000,
                    "value": 86,
                    "value2": 24.59
                },
                {
                    "date": 1691499600000,
                    "value": 81.875,
                    "value2": 28.57
                },
                {
                    "date": 1691503200000,
                    "value": 81,
                    "value2": 26.490000000000002
                },
                {
                    "date": 1691506800000,
                    "value": 94.125,
                    "value2": 16.75
                },
                {
                    "date": 1691510400000,
                    "value": 106,
                    "value2": 0
                },
                {
                    "date": 1691514000000,
                    "value": 99.125,
                    "value2": 0.04
                },
                {
                    "date": 1691517600000,
                    "value": 76.125,
                    "value2": 0
                },
                {
                    "date": 1691521200000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1691524800000,
                    "value": 58,
                    "value2": 0
                },
                {
                    "date": 1691528400000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1691532000000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691539200000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1691542800000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691546400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1691550000000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1691553600000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1691557200000,
                    "value": 81,
                    "value2": 0
                },
                {
                    "date": 1691560800000,
                    "value": 101,
                    "value2": 0
                },
                {
                    "date": 1691564400000,
                    "value": 107,
                    "value2": 9.370000000000001
                },
                {
                    "date": 1691568000000,
                    "value": 108.875,
                    "value2": 24.05
                },
                {
                    "date": 1691571600000,
                    "value": 96.875,
                    "value2": 26.87
                },
                {
                    "date": 1691575200000,
                    "value": 94,
                    "value2": 25.62
                },
                {
                    "date": 1691578800000,
                    "value": 96,
                    "value2": 17.87
                },
                {
                    "date": 1691582400000,
                    "value": 92,
                    "value2": 23.05
                },
                {
                    "date": 1691586000000,
                    "value": 79,
                    "value2": 24.05
                },
                {
                    "date": 1691589600000,
                    "value": 114.125,
                    "value2": 20.400000000000002
                },
                {
                    "date": 1691593200000,
                    "value": 90,
                    "value2": 11.86
                },
                {
                    "date": 1691596800000,
                    "value": 107,
                    "value2": 0.9500000000000001
                },
                {
                    "date": 1691600400000,
                    "value": 84,
                    "value2": 0
                },
                {
                    "date": 1691604000000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1691607600000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1691611200000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1691614800000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1691618400000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691625600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1691629200000,
                    "value": 60.125,
                    "value2": 0
                },
                {
                    "date": 1691632800000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1691636400000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1691640000000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1691643600000,
                    "value": 80,
                    "value2": 0
                },
                {
                    "date": 1691647200000,
                    "value": 99.875,
                    "value2": 0
                },
                {
                    "date": 1691650800000,
                    "value": 105,
                    "value2": 10.82
                },
                {
                    "date": 1691654400000,
                    "value": 109,
                    "value2": 23.63
                },
                {
                    "date": 1691658000000,
                    "value": 97,
                    "value2": 26.78
                },
                {
                    "date": 1691661600000,
                    "value": 85,
                    "value2": 25.54
                },
                {
                    "date": 1691665200000,
                    "value": 86.875,
                    "value2": 18.490000000000002
                },
                {
                    "date": 1691668800000,
                    "value": 76.875,
                    "value2": 23.13
                },
                {
                    "date": 1691672400000,
                    "value": 100.875,
                    "value2": 24.96
                },
                {
                    "date": 1691676000000,
                    "value": 83.125,
                    "value2": 22.68
                },
                {
                    "date": 1691679600000,
                    "value": 77.125,
                    "value2": 14.76
                },
                {
                    "date": 1691683200000,
                    "value": 97,
                    "value2": 3.48
                },
                {
                    "date": 1691686800000,
                    "value": 76.875,
                    "value2": 0
                },
                {
                    "date": 1691690400000,
                    "value": 73.125,
                    "value2": 0
                },
                {
                    "date": 1691694000000,
                    "value": 71.125,
                    "value2": 0
                },
                {
                    "date": 1691697600000,
                    "value": 67,
                    "value2": 0
                },
                {
                    "date": 1691701200000,
                    "value": 67.875,
                    "value2": 0
                },
                {
                    "date": 1691704800000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1691712000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1691715600000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1691719200000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1691722800000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1691726400000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1691730000000,
                    "value": 81.875,
                    "value2": 0
                },
                {
                    "date": 1691733600000,
                    "value": 100,
                    "value2": 0
                },
                {
                    "date": 1691737200000,
                    "value": 103.125,
                    "value2": 3.19
                },
                {
                    "date": 1691740800000,
                    "value": 107.125,
                    "value2": 7.05
                },
                {
                    "date": 1691744400000,
                    "value": 93.125,
                    "value2": 7.75
                },
                {
                    "date": 1691748000000,
                    "value": 78,
                    "value2": 7.75
                },
                {
                    "date": 1691751600000,
                    "value": 73,
                    "value2": 7.46
                },
                {
                    "date": 1691755200000,
                    "value": 81.875,
                    "value2": 7.55
                },
                {
                    "date": 1691758800000,
                    "value": 97,
                    "value2": 6.43
                },
                {
                    "date": 1691762400000,
                    "value": 102.875,
                    "value2": 5.76
                },
                {
                    "date": 1691766000000,
                    "value": 100.125,
                    "value2": 1.62
                },
                {
                    "date": 1691769600000,
                    "value": 117,
                    "value2": 0.21
                },
                {
                    "date": 1691773200000,
                    "value": 99.875,
                    "value2": 0
                },
                {
                    "date": 1691776800000,
                    "value": 83.125,
                    "value2": 0
                },
                {
                    "date": 1691780400000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1691784000000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1691787600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1691791200000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1691798400000,
                    "value": 60.875,
                    "value2": 0
                },
                {
                    "date": 1691802000000,
                    "value": 61.125,
                    "value2": 0
                },
                {
                    "date": 1691805600000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1691809200000,
                    "value": 59.875,
                    "value2": 0
                },
                {
                    "date": 1691812800000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1691816400000,
                    "value": 87,
                    "value2": 0
                },
                {
                    "date": 1691820000000,
                    "value": 90,
                    "value2": 0
                },
                {
                    "date": 1691823600000,
                    "value": 70,
                    "value2": 0.12
                },
                {
                    "date": 1691827200000,
                    "value": 55.875,
                    "value2": 0.12
                },
                {
                    "date": 1691830800000,
                    "value": 80,
                    "value2": 0.12
                },
                {
                    "date": 1691834400000,
                    "value": 74,
                    "value2": 0.12
                },
                {
                    "date": 1691838000000,
                    "value": 53.875,
                    "value2": 0.08
                },
                {
                    "date": 1691841600000,
                    "value": 28,
                    "value2": 0.08
                },
                {
                    "date": 1691845200000,
                    "value": 11,
                    "value2": 0.08
                },
                {
                    "date": 1691848800000,
                    "value": 15,
                    "value2": 0
                },
                {
                    "date": 1691852400000,
                    "value": 14.125,
                    "value2": 0.04
                },
                {
                    "date": 1691856000000,
                    "value": 22.875,
                    "value2": 0
                },
                {
                    "date": 1691859600000,
                    "value": 42,
                    "value2": 0
                },
                {
                    "date": 1691863200000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1691866800000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1691870400000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1691874000000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1691877600000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1691884800000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1691888400000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1691892000000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1691895600000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1691899200000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1691902800000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1691906400000,
                    "value": 60,
                    "value2": 0
                },
                {
                    "date": 1691910000000,
                    "value": 58,
                    "value2": 0.04
                },
                {
                    "date": 1691913600000,
                    "value": 53,
                    "value2": 0.04
                },
                {
                    "date": 1691917200000,
                    "value": 41,
                    "value2": 0.04
                },
                {
                    "date": 1691920800000,
                    "value": 15.875,
                    "value2": 0.04
                },
                {
                    "date": 1691924400000,
                    "value": 11.875,
                    "value2": 0.08
                },
                {
                    "date": 1691928000000,
                    "value": 19.125,
                    "value2": 0.08
                },
                {
                    "date": 1691931600000,
                    "value": 38.875,
                    "value2": 0.08
                },
                {
                    "date": 1691935200000,
                    "value": 13.125,
                    "value2": 0
                },
                {
                    "date": 1691938800000,
                    "value": 20,
                    "value2": 0
                },
                {
                    "date": 1691942400000,
                    "value": 32,
                    "value2": 0
                },
                {
                    "date": 1691946000000,
                    "value": 27,
                    "value2": 0.08
                },
                {
                    "date": 1691949600000,
                    "value": 61.875,
                    "value2": 0.08
                },
                {
                    "date": 1691953200000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1691956800000,
                    "value": 66.125,
                    "value2": 0.08
                },
                {
                    "date": 1691960400000,
                    "value": 68,
                    "value2": 0.08
                },
                {
                    "date": 1691964000000,
                    "value": 61.875,
                    "value2": 0.08
                },
                {
                    "date": 1691971200000,
                    "value": 86,
                    "value2": 0.08
                },
                {
                    "date": 1691974800000,
                    "value": 85,
                    "value2": 0.08
                },
                {
                    "date": 1691978400000,
                    "value": 85,
                    "value2": 0.08
                },
                {
                    "date": 1691982000000,
                    "value": 86,
                    "value2": 0.08
                },
                {
                    "date": 1691985600000,
                    "value": 86,
                    "value2": 0.08
                },
                {
                    "date": 1691989200000,
                    "value": 87,
                    "value2": 0.08
                },
                {
                    "date": 1691992800000,
                    "value": 101,
                    "value2": 0.08
                },
                {
                    "date": 1691996400000,
                    "value": 103,
                    "value2": 2.4000000000000004
                },
                {
                    "date": 1692000000000,
                    "value": 101,
                    "value2": 5.89
                },
                {
                    "date": 1692003600000,
                    "value": 86.125,
                    "value2": 6.55
                },
                {
                    "date": 1692007200000,
                    "value": 71.875,
                    "value2": 6.22
                },
                {
                    "date": 1692010800000,
                    "value": 67.875,
                    "value2": 3.98
                },
                {
                    "date": 1692014400000,
                    "value": 62.125,
                    "value2": 4.6000000000000005
                },
                {
                    "date": 1692018000000,
                    "value": 61.125,
                    "value2": 4.7700000000000005
                },
                {
                    "date": 1692021600000,
                    "value": 82.875,
                    "value2": 2.9000000000000004
                },
                {
                    "date": 1692025200000,
                    "value": 93,
                    "value2": 0.46
                },
                {
                    "date": 1692028800000,
                    "value": 94,
                    "value2": 0
                },
                {
                    "date": 1692032400000,
                    "value": 88,
                    "value2": 0
                },
                {
                    "date": 1692036000000,
                    "value": 75,
                    "value2": 0
                },
                {
                    "date": 1692039600000,
                    "value": 71.875,
                    "value2": 0
                },
                {
                    "date": 1692043200000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1692046800000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1692050400000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1692057600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1692061200000,
                    "value": 61,
                    "value2": 0
                },
                {
                    "date": 1692064800000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1692068400000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1692072000000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1692075600000,
                    "value": 81.875,
                    "value2": 0
                },
                {
                    "date": 1692079200000,
                    "value": 96,
                    "value2": 0
                },
                {
                    "date": 1692082800000,
                    "value": 96,
                    "value2": 0
                },
                {
                    "date": 1692086400000,
                    "value": 91,
                    "value2": 0
                },
                {
                    "date": 1692090000000,
                    "value": 80,
                    "value2": 0
                },
                {
                    "date": 1692093600000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1692097200000,
                    "value": 52,
                    "value2": 0
                },
                {
                    "date": 1692100800000,
                    "value": 75,
                    "value2": 0
                },
                {
                    "date": 1692104400000,
                    "value": 81,
                    "value2": 0
                },
                {
                    "date": 1692108000000,
                    "value": 80,
                    "value2": 0
                },
                {
                    "date": 1692111600000,
                    "value": 84.125,
                    "value2": 0.04
                },
                {
                    "date": 1692115200000,
                    "value": 85,
                    "value2": 0.04
                },
                {
                    "date": 1692118800000,
                    "value": 71.875,
                    "value2": 0.04
                },
                {
                    "date": 1692122400000,
                    "value": 65,
                    "value2": 0.04
                },
                {
                    "date": 1692126000000,
                    "value": 70,
                    "value2": 0.04
                },
                {
                    "date": 1692129600000,
                    "value": 66,
                    "value2": 0.04
                },
                {
                    "date": 1692133200000,
                    "value": 64.875,
                    "value2": 0.04
                },
                {
                    "date": 1692136800000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1692144000000,
                    "value": 60.875,
                    "value2": 0.04
                },
                {
                    "date": 1692147600000,
                    "value": 62.125,
                    "value2": 0.04
                },
                {
                    "date": 1692151200000,
                    "value": 64,
                    "value2": 0.04
                },
                {
                    "date": 1692154800000,
                    "value": 61.875,
                    "value2": 0.04
                },
                {
                    "date": 1692158400000,
                    "value": 62.875,
                    "value2": 0.04
                },
                {
                    "date": 1692162000000,
                    "value": 82.125,
                    "value2": 0.04
                },
                {
                    "date": 1692165600000,
                    "value": 92.125,
                    "value2": 0.04
                },
                {
                    "date": 1692169200000,
                    "value": 85,
                    "value2": 10.03
                },
                {
                    "date": 1692172800000,
                    "value": 95.125,
                    "value2": 20.85
                },
                {
                    "date": 1692176400000,
                    "value": 96.875,
                    "value2": 23.22
                },
                {
                    "date": 1692180000000,
                    "value": 91,
                    "value2": 22.76
                },
                {
                    "date": 1692183600000,
                    "value": 83.125,
                    "value2": 16.63
                },
                {
                    "date": 1692187200000,
                    "value": 83.125,
                    "value2": 19.240000000000002
                },
                {
                    "date": 1692190800000,
                    "value": 91,
                    "value2": 20.94
                },
                {
                    "date": 1692194400000,
                    "value": 89.125,
                    "value2": 18.86
                },
                {
                    "date": 1692198000000,
                    "value": 89,
                    "value2": 11.07
                },
                {
                    "date": 1692201600000,
                    "value": 96,
                    "value2": 0.41000000000000003
                },
                {
                    "date": 1692205200000,
                    "value": 97.125,
                    "value2": 0
                },
                {
                    "date": 1692208800000,
                    "value": 75,
                    "value2": 0
                },
                {
                    "date": 1692212400000,
                    "value": 70,
                    "value2": 0
                },
                {
                    "date": 1692216000000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1692219600000,
                    "value": 72.125,
                    "value2": 0
                },
                {
                    "date": 1692223200000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1692230400000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1692234000000,
                    "value": 61.875,
                    "value2": 0
                },
                {
                    "date": 1692237600000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1692241200000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1692244800000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1692248400000,
                    "value": 81.125,
                    "value2": 0
                },
                {
                    "date": 1692252000000,
                    "value": 81.875,
                    "value2": 0
                },
                {
                    "date": 1692255600000,
                    "value": 88,
                    "value2": 10.07
                },
                {
                    "date": 1692259200000,
                    "value": 109.875,
                    "value2": 23.18
                },
                {
                    "date": 1692262800000,
                    "value": 95.125,
                    "value2": 25.080000000000002
                },
                {
                    "date": 1692266400000,
                    "value": 81,
                    "value2": 23.67
                },
                {
                    "date": 1692270000000,
                    "value": 81.875,
                    "value2": 17.580000000000002
                },
                {
                    "date": 1692273600000,
                    "value": 70,
                    "value2": 21.14
                },
                {
                    "date": 1692277200000,
                    "value": 76,
                    "value2": 23.51
                },
                {
                    "date": 1692280800000,
                    "value": 71.125,
                    "value2": 20.650000000000002
                },
                {
                    "date": 1692284400000,
                    "value": 88,
                    "value2": 14.26
                },
                {
                    "date": 1692288000000,
                    "value": 91,
                    "value2": 1.78
                },
                {
                    "date": 1692291600000,
                    "value": 82.875,
                    "value2": 0
                },
                {
                    "date": 1692295200000,
                    "value": 73.125,
                    "value2": 0
                },
                {
                    "date": 1692298800000,
                    "value": 72,
                    "value2": 0
                },
                {
                    "date": 1692302400000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1692306000000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1692309600000,
                    "value": 65.875,
                    "value2": 0
                },
                {
                    "date": 1692316800000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1692320400000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1692324000000,
                    "value": 63.125,
                    "value2": 0
                },
                {
                    "date": 1692327600000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1692331200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1692334800000,
                    "value": 85,
                    "value2": 0
                },
                {
                    "date": 1692338400000,
                    "value": 100,
                    "value2": 0
                },
                {
                    "date": 1692342000000,
                    "value": 103.875,
                    "value2": 4.44
                },
                {
                    "date": 1692345600000,
                    "value": 107,
                    "value2": 8.370000000000001
                },
                {
                    "date": 1692349200000,
                    "value": 93.875,
                    "value2": 9.540000000000001
                },
                {
                    "date": 1692352800000,
                    "value": 83.125,
                    "value2": 8.96
                },
                {
                    "date": 1692356400000,
                    "value": 87.125,
                    "value2": 8.040000000000001
                },
                {
                    "date": 1692360000000,
                    "value": 98.875,
                    "value2": 8.21
                },
                {
                    "date": 1692363600000,
                    "value": 96,
                    "value2": 7.75
                },
                {
                    "date": 1692367200000,
                    "value": 103,
                    "value2": 5.97
                },
                {
                    "date": 1692370800000,
                    "value": 87,
                    "value2": 1.9100000000000001
                },
                {
                    "date": 1692374400000,
                    "value": 83.125,
                    "value2": 0
                },
                {
                    "date": 1692378000000,
                    "value": 72.875,
                    "value2": 0
                },
                {
                    "date": 1692381600000,
                    "value": 72.875,
                    "value2": 0
                },
                {
                    "date": 1692385200000,
                    "value": 66.875,
                    "value2": 0
                },
                {
                    "date": 1692388800000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1692392400000,
                    "value": 69,
                    "value2": 0
                },
                {
                    "date": 1692403200000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1692406800000,
                    "value": 62,
                    "value2": 0
                },
                {
                    "date": 1692410400000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1692414000000,
                    "value": 62.875,
                    "value2": 0
                },
                {
                    "date": 1692417600000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1692421200000,
                    "value": 94.125,
                    "value2": 0
                },
                {
                    "date": 1692424800000,
                    "value": 98,
                    "value2": 0
                },
                {
                    "date": 1692428400000,
                    "value": 96,
                    "value2": 0
                },
                {
                    "date": 1692432000000,
                    "value": 95,
                    "value2": 0
                },
                {
                    "date": 1692435600000,
                    "value": 93.875,
                    "value2": 0
                },
                {
                    "date": 1692439200000,
                    "value": 102.875,
                    "value2": 0
                },
                {
                    "date": 1692442800000,
                    "value": 66.125,
                    "value2": 0
                },
                {
                    "date": 1692446400000,
                    "value": 49,
                    "value2": 0
                },
                {
                    "date": 1692450000000,
                    "value": 11.875,
                    "value2": 0
                },
                {
                    "date": 1692453600000,
                    "value": 1,
                    "value2": 0
                },
                {
                    "date": 1692457200000,
                    "value": 1.125,
                    "value2": 0
                },
                {
                    "date": 1692460800000,
                    "value": 11,
                    "value2": 0
                },
                {
                    "date": 1692464400000,
                    "value": 24.125,
                    "value2": 0
                },
                {
                    "date": 1692468000000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1692471600000,
                    "value": 57.125,
                    "value2": 0
                },
                {
                    "date": 1692475200000,
                    "value": 75,
                    "value2": 0
                },
                {
                    "date": 1692478800000,
                    "value": 70.875,
                    "value2": 0
                },
                {
                    "date": 1692482400000,
                    "value": 65.125,
                    "value2": 0
                },
                {
                    "date": 1692489600000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1692493200000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1692496800000,
                    "value": 67.125,
                    "value2": 0
                },
                {
                    "date": 1692500400000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1692504000000,
                    "value": 64.875,
                    "value2": 0
                },
                {
                    "date": 1692507600000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1692511200000,
                    "value": 65,
                    "value2": 0
                },
                {
                    "date": 1692514800000,
                    "value": 66,
                    "value2": 0
                },
                {
                    "date": 1692518400000,
                    "value": 63,
                    "value2": 0
                },
                {
                    "date": 1692522000000,
                    "value": 26,
                    "value2": 0
                },
                {
                    "date": 1692525600000,
                    "value": 6.875,
                    "value2": 0
                },
                {
                    "date": 1692529200000,
                    "value": 0,
                    "value2": 0
                },
                {
                    "date": 1692532800000,
                    "value": 18,
                    "value2": 0
                },
                {
                    "date": 1692536400000,
                    "value": 16,
                    "value2": 0
                },
                {
                    "date": 1692540000000,
                    "value": 16,
                    "value2": 0
                },
                {
                    "date": 1692543600000,
                    "value": 14,
                    "value2": 0
                },
                {
                    "date": 1692547200000,
                    "value": 27,
                    "value2": 0
                },
                {
                    "date": 1692550800000,
                    "value": 28.875,
                    "value2": 0
                },
                {
                    "date": 1692554400000,
                    "value": 55,
                    "value2": 0
                },
                {
                    "date": 1692558000000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1692561600000,
                    "value": 62.125,
                    "value2": 0
                },
                {
                    "date": 1692565200000,
                    "value": 59,
                    "value2": 0
                },
                {
                    "date": 1692568800000,
                    "value": 64,
                    "value2": 0
                },
                {
                    "date": 1692576000000,
                    "value": 86,
                    "value2": 0
                },
                {
                    "date": 1692579600000,
                    "value": 88.125,
                    "value2": 0
                },
                {
                    "date": 1692583200000,
                    "value": 88.125,
                    "value2": 0
                },
                {
                    "date": 1692586800000,
                    "value": 92.125,
                    "value2": 0
                },
                {
                    "date": 1692590400000,
                    "value": 90.125,
                    "value2": 0
                },
                {
                    "date": 1692594000000,
                    "value": 93.875,
                    "value2": 0
                },
                {
                    "date": 1692597600000,
                    "value": 106,
                    "value2": 0
                },
                {
                    "date": 1692601200000,
                    "value": 114.875,
                    "value2": 10.28
                },
                {
                    "date": 1692604800000,
                    "value": 120.125,
                    "value2": 24.59
                },
                {
                    "date": 1692608400000,
                    "value": 103,
                    "value2": 26.200000000000003
                },
                {
                    "date": 1692612000000,
                    "value": 80,
                    "value2": 26.37
                },
                {
                    "date": 1692615600000,
                    "value": 79.875,
                    "value2": 20.85
                },
                {
                    "date": 1692619200000,
                    "value": 77.125,
                    "value2": 23.63
                },
                {
                    "date": 1692622800000,
                    "value": 83.125,
                    "value2": 25.080000000000002
                },
                {
                    "date": 1692626400000,
                    "value": 84,
                    "value2": 21.72
                },
                {
                    "date": 1692630000000,
                    "value": 90,
                    "value2": 15.09
                },
                {
                    "date": 1692633600000,
                    "value": 87.125,
                    "value2": 2.36
                },
                {
                    "date": 1692637200000,
                    "value": 81.125,
                    "value2": 0.08
                },
                {
                    "date": 1692640800000,
                    "value": 74,
                    "value2": 0.08
                },
                {
                    "date": 1692644400000,
                    "value": 72.125,
                    "value2": 0.08
                },
                {
                    "date": 1692648000000,
                    "value": 70,
                    "value2": 0.08
                },
                {
                    "date": 1692651600000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1692655200000,
                    "value": 66.875,
                    "value2": 0.08
                },
                {
                    "date": 1692662400000,
                    "value": 61.875,
                    "value2": 0.08
                },
                {
                    "date": 1692666000000,
                    "value": 63,
                    "value2": 0.08
                },
                {
                    "date": 1692669600000,
                    "value": 63,
                    "value2": 0.08
                },
                {
                    "date": 1692673200000,
                    "value": 67.125,
                    "value2": 0.08
                },
                {
                    "date": 1692676800000,
                    "value": 64,
                    "value2": 0.08
                },
                {
                    "date": 1692680400000,
                    "value": 82,
                    "value2": 0.08
                },
                {
                    "date": 1692684000000,
                    "value": 105.125,
                    "value2": 0.08
                },
                {
                    "date": 1692687600000,
                    "value": 111,
                    "value2": 14.47
                },
                {
                    "date": 1692691200000,
                    "value": 118,
                    "value2": 29.35
                },
                {
                    "date": 1692694800000,
                    "value": 103.875,
                    "value2": 32.17
                },
                {
                    "date": 1692698400000,
                    "value": 91,
                    "value2": 32.300000000000004
                },
                {
                    "date": 1692702000000,
                    "value": 88.125,
                    "value2": 26.95
                },
                {
                    "date": 1692705600000,
                    "value": 78,
                    "value2": 28.52
                },
                {
                    "date": 1692709200000,
                    "value": 91,
                    "value2": 30.43
                },
                {
                    "date": 1692712800000,
                    "value": 88.125,
                    "value2": 26.87
                },
                {
                    "date": 1692716400000,
                    "value": 94.125,
                    "value2": 17.25
                }
            ]
            const values1 = data.map(d => d.value2);
            const values2 = data.map(d => d.value);

            const datasets = values1.map((value1, index) => {
                return {
                    label: `Point ${index + 1}`,
                    data: [
                        {
                            x: Math.max(0, value1), // Si négatif, devient 0
                            y: Math.max(0, values2[index]), // Si négatif, devient 0
                            r: 10 // Vous pouvez ajuster le rayon comme vous le souhaitez
                        }
                    ],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)', // Bleu
                    borderColor: 'rgba(54, 162, 235, 1)', // Bleu
                    borderWidth: 1,
                };
            });

            return {
                datasets: datasets
            };

        },
        generateBubbleData2(data1, data2) {
            const datasets = data1.map((value, index) => {
                return {
                    label: `Point ${index + 1}`,
                    data: [
                        {
                            x: Math.max(0, data2[index]), // Si négatif, devient 0
                            y: Math.max(0, value),       // Si négatif, devient 0
                            r: 10 // Vous pouvez ajuster le rayon comme vous le souhaitez
                        }
                    ],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)', // Bleu
                    borderColor: 'rgba(54, 162, 235, 1)', // Bleu
                    borderWidth: 1,
                };
            });

            return {
                datasets: datasets
            };
        },
        toto() {
            console.log('data1', this.data1[0].data);
            console.log('data2', this.data2[0].data);


            let maxValueY = Math.max(...this.data2[0].data);
            let maxValueX = Math.max(...this.data1[0].data);

            console.log(maxValueY, maxValueX);
        }
    },

    computed: {
        bubbleChartData() {
            return this.generateBubbleData(this.data1[0].data, this.data2[0].data);
        },

        // bubbleChartData() {
        //     return {
        //         datasets: this.datasets.concat(this.lineDatasets), // Assurez-vous que les datasets contiennent des données de type { x: value, y: value, r: radius }
        //     };
        // },

        bubbleChartOptions() {
            return {
                maintainAspectRatio: false,
                scales: {
                    x: {

                        // type: 'logarithmic', 
                        beginAtZero: true,
                        // max: Math.max(...this.data1[0].data),
                        ticks: {

                            font: {
                                family: "Charlevoix Pro",
                                size: 11,
                            },
                            color: "#214353",
                        },
                        grid: {
                            display: false,
                        },
                    },
                    y: {
                        // Définissez les propriétés spécifiques pour l'axe y de votre graphique à bulles
                        // max: Math.max(...this.data2[0].data),
                        // type: 'logarithmic',
                        ticks: {
                            font: {
                                family: "Charlevoix Pro",
                                size: 11,
                            },
                            color: "#214353",
                        },
                        grid: {
                            color: "#f9f9f9",
                            lineWidth: 2,
                        },
                    },
                },
                plugins: {
                    legend: {
                        display: false,
                        align: "start",
                        labels: {
                            color: "#214353",
                            font: {
                                family: "Charlevoix Pro",
                                size: 14,
                                letterSpacing: 0.7,
                            },
                            useBorderRadius: true,
                            borderRadius: 5,
                            boxWidth: 9,
                            boxHeight: 21,
                        },
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                return `${context.label}: (${context.raw.x}, ${context.raw.y}, ${context.raw.r})`;
                            },
                        },
                    },
                },
                interaction: {
                    mode: "nearest",
                    axis: "xy",
                    intersect: false,
                },
            };
        }

    },

    created() {
        const radius = 4;
        const borderRadius = {
            topLeft: radius,
            topRight: radius,
            bottomLeft: radius,
            bottomRight: radius,
        };
        const colors =
            this.datasets.length + this.lineDatasets.length <= 3
                ? defaultColor(3)
                : gradiant(this.datasets.length + this.lineDatasets.length).map(
                    (color) => {
                        const col = HSVtoRGB(color / 100, 1, 1);
                        return RGBtoHexa(col.r, col.g, col.b);
                    }
                );
        this.datasets.forEach((set) => {
            if (!set.backgroundColor) set.backgroundColor = colors.shift();
            set.type = "bar";
            set.order = 2;
            set.borderSkipped = false;
            set.borderRadius = borderRadius;
            set.borderWidth = 1;
            set.borderColor = "rgba(0,0,0,0)";
        });
        this.lineDatasets.forEach((set) => {
            set.type = "line";
            set.pointStyle = this.linePoint;
            set.tension = 0.3;
            set.order = 1;
            set.yAxisID = "y2";
            set.borderColor = set.borderColor || colors.shift();
            set.pointBackgroundColor = set.borderColor;
            const { r, g, b } = hexaToRGB(set.borderColor);
            set.backgroundColor = set.backgroundColor || `rgba(${r},${g},${b},0.3)`;
        });
    },

    watch: {
        datasets() {
            const radius = 4;
            const borderRadius = {
                topLeft: radius,
                topRight: radius,
                bottomLeft: radius,
                bottomRight: radius,
            };
            const colors =
                this.datasets.length + this.lineDatasets.length <= 3
                    ? defaultColor(3)
                    : gradiant(this.datasets.length + this.lineDatasets.length).map(
                        (color) => {
                            const col = HSVtoRGB(color / 100, 1, 1);
                            return RGBtoHexa(col.r, col.g, col.b);
                        }
                    );
            this.datasets.forEach((set) => {
                if (!set.backgroundColor) set.backgroundColor = colors.shift();
                set.type = "bar";
                set.order = 2;
                set.borderSkipped = false;
                set.borderRadius = borderRadius;
                set.borderWidth = 1;
                set.borderColor = "rgba(0,0,0,0)";
            });
            this.lineDatasets.forEach((set) => {
                set.type = "line";
                set.pointStyle = this.linePoint;
                set.tension = 0.3;
                set.order = 1;
                set.yAxisID = "y2";
                set.borderColor = set.borderColor || colors.shift();
                set.pointBackgroundColor = set.borderColor;
                const { r, g, b } = hexaToRGB(set.borderColor);
                set.backgroundColor = set.backgroundColor || `rgba(${r},${g},${b},0.3)`;
            });
        },
    },
};
</script>
<style>
html {
    overflow-y: auto !important;
}

.v-application {
    font-family: "Charlevoix Pro";
}
</style>
<style scoped>
.bar-card {
    background-color: #f9f9f9;
    font-family: "Charlevoix Pro";
    font-size: 14px;
}

.card-title {
    letter-spacing: 1.1px;
    color: #214353;
    opacity: 1;
    font-size: 11px/13px;
}
</style>