# Questions

### <b style="color: #d9af45"> Comment calculer la somme des pourcentages </b>
### <b style="color: #d9af45"> Comment basculer entre les % et les valeurs </b>

# Features
### <b>Road map</b>
|Etat|Date de debut|Date de fin|Description|
|----|----|----|----|
|[Réalisé]|11/07/2023 | 12/07/2023 |Ajouter et positionner les composants dans le dashboard|
|[Réalisé]|12/07/2023 | 19/07/2023 |Terminer le fichier config|
|[Réalisé]|13/07/2023 | 13/07/2023 |Calculer le maximum|
|[Réalisé]|13/07/2023 | 13/07/2023 |Calculer le minimum|
|[Réalisé]|13/07/2023 | 19/07/2023 |Basculer entre Taux d'occupation et Nombre de personnes|
|[Réalisé]|13/07/2023 | 13/07/2023 |Calculer la somme|
|[Réalisé]|17/07/2023 | 19/07/2023 |Appels API pour chaque espaces, et chaque temporalite|
|[Réalisé]| 19/07/2023 | 19/07/2023 |Calculer la moyenne|
|[Réalisé]|19/07/2023 | 20/07/2023 |Bouton telechargement|
|[Réalisé]|20/07/2023 | 20/07/2023 |Ajouter que les methodes de calculs dans le fichier config|
|[Réalisé]|24/07/2023 | 25/07/2023 |Aouter un interval de temps|
|[Réalisé]| 20/07/2023 | 24/07/2023 |Mettre les valeurs dans la longue bande (bilan par mois)|
|[En cours]| 25/07/2023 | - |Week heatmap|
