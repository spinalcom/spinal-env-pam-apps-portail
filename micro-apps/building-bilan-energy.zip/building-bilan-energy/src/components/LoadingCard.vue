<template>
  <v-card class="d-flex align-center justify-center rounded-lg" elevation="5" outlined style="background: #f9f9f9">
      <v-progress-circular
        :size="50"
        color="#14202c"
        indeterminate
        />
  </v-card>
</template>

<script>
export default {
  
}
// test
</script>

<style scoped>

</style>