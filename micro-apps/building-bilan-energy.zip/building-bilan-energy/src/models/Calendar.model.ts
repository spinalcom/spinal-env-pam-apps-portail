export interface CalendarModel {
  n: string,
  y: string,
  d: [],
}