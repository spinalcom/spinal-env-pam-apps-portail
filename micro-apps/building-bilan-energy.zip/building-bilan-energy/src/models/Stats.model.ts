export interface StatsModel {
    todaysTickets: number
    onGoingTickets: number
    selectedTempoTickets: number
    selectedTempoTicketsText: string
}