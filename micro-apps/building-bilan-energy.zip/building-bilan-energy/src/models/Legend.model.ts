export interface LegendModel {
    name: string,
    color: string,
  }