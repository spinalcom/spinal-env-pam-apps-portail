export default {
    config: {
      title: 'Consommation d\'eau sanitaire',
      label: 'Consommation',
      labelIndicators:"consommé",
      apiUrl: 'Eau globale',
      unit:'L',
    },
    // exemple: {
    //   title: 'Consommation d\'eau sanitaire',
    //   label: 'Consommation',
    //   labelIndicators:"consommé",
    //   apiUrl: 'Eau globale',
    //   unit:'L',
    // },
  }