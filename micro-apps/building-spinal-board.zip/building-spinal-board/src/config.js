export default {
    config: {
      title: 'Consommation Eau sanitaire',
      label: 'Consommation',
      labelIndicators:"consommés",
      buildingApiUrl: "Eau sanitaire",
      floorApiUrl: "Eau sanitaire",
      unit:'L',
      color:'#14202c',
    },
    // exemple: {
    //   title: 'Consommation d\'eau sanitaire',
    //   label: 'Consommation',
    //   labelIndicators:"consommé",
    //   apiUrl: 'Eau globale',
    //   unit:'L',
    // },
  }