// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"hhjkK":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./HomeView.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./HomeView.vue").render;
    script.staticRenderFns = require("template:./HomeView.vue").staticRenderFns;
    script._scopeId = "data-v-2c2dae";
    script.__cssModules = require("style:./HomeView.vue").default;
    require("custom:./HomeView.vue").default(script);
    script.__scopeId = "data-v-2c2dae";
    script.__file = "HomeView.vue";
};
initialize();
exports.default = script;

},{"script:./HomeView.vue":"8neyR","template:./HomeView.vue":"6sanV","style:./HomeView.vue":"84ISk","custom:./HomeView.vue":"3aLym","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"8neyR":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
// import { groups, categories } from "./data";
var _gridComponentVue = require("../components/gridComponent.vue");
var _gridComponentVueDefault = parcelHelpers.interopDefault(_gridComponentVue);
var _lodash = require("lodash");
var _vuex = require("vuex");
var _appDataStore = require("../store/appDataStore");
var scriptExports = (0, _vueDefault.default).extend({
    name: "Home",
    components: {
        GridComponent: (0, _gridComponentVueDefault.default)
    },
    props: {
        isMobile: {}
    },
    data () {
        this.defaultCategory = {
            name: "Toutes les categories",
            value: ""
        };
        return {
            filtersData: {
                category: this.defaultCategory,
                search: ""
            },
            groups: [],
            categories: [],
            categoriesDisplayed: [],
            selects: []
        };
    },
    created () {
        this.debounceFilter = _lodash.debounce(this.filterCategories, 400);
    },
    async mounted () {
        if (this.groups.length === 0) this.formatData(this.appsFormatted);
        this.$store.commit(`appDataStore/${(0, _appDataStore.SET_SELECTED_APP)}`, undefined);
    },
    methods: {
        ...(0, _vuex.mapActions)("appDataStore", [
            "addToFavoriteApps",
            "deleteFavoriteApps"
        ]),
        formatData (info) {
            if (!info) return;
            const { groups , data  } = info;
            this.groups = groups;
            this.categories = data;
            this.filterCategories();
            this.selects = [
                this.defaultCategory,
                ...data.map((el)=>{
                    el.name = el.name || el.name;
                    el.value = el.id || el.name;
                    return el;
                }), 
            ];
        },
        filterCategories () {
            this.categoriesDisplayed = this.categories.reduce((liste, item)=>{
                const categoryName = this.filtersData.category.value;
                if (categoryName && categoryName !== item.value) return liste;
                const searchData = this.filtersData.search.toLowerCase();
                let appsItem = !searchData ? item : this.filterApps(searchData, item);
                liste.push(appsItem);
                return liste;
            }, []);
        },
        filterApps (searchText, item) {
            let obj = {};
            for(const key in item)if (Object.hasOwnProperty.call(item, key)) {
                const value = item[key];
                obj[key] = typeof value === "string" ? value : value.filter((el)=>el.name.toLowerCase().includes(searchText.toLowerCase()) || el.tags.find((tag)=>tag.toLowerCase().includes(searchText.toLowerCase())));
            }
            return obj;
        },
        goToApp ({ item , event  }) {
            if (item.isExternalApp) {
                window.open(item.link, "_blank");
                return;
            }
            if (event.ctrlKey) {
                let routeData = this.$router.resolve({
                    name: "App",
                    query: {
                        app: item.name
                    }
                });
                window.open(routeData.href, "_blank");
            } else this.$router.push({
                name: "App",
                query: {
                    app: item.name
                }
            });
        },
        exploreApp (item) {},
        addAppToFavoris ({ item , isFavorite  }) {
            const ids = [
                item.id
            ];
            if (isFavorite) return this.deleteFavoriteApps(ids);
            this.addToFavoriteApps(ids);
        }
    },
    computed: {
        ...(0, _vuex.mapState)("appDataStore", [
            "appsFormatted",
            "favoriteApps"
        ])
    },
    watch: {
        // favoriteApps() {
        //   this.favoriteApps.forEach((el) => {
        //     this.favoriteAppsObj[el.id] = el;
        //   });
        // },
        appsFormatted ({ data , groups  }) {
            this.formatData({
                data,
                groups
            });
        },
        "filtersData.category": function() {
            this.filterCategories();
        },
        "filtersData.search": function() {
            this.debounceFilter();
        }
    }
});
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"vue":"kjivF","../components/gridComponent.vue":"cjIFa","lodash":"cZS9U","vuex":"ccMRg","../store/appDataStore":"6b0bJ","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"cjIFa":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./gridComponent.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./gridComponent.vue").render;
    script.staticRenderFns = require("template:./gridComponent.vue").staticRenderFns;
    script._scopeId = "data-v-b1743d";
    script.__cssModules = require("style:./gridComponent.vue").default;
    require("custom:./gridComponent.vue").default(script);
    script.__scopeId = "data-v-b1743d";
    script.__file = "gridComponent.vue";
};
initialize();
exports.default = script;

},{"script:./gridComponent.vue":"erzd1","template:./gridComponent.vue":"55f0y","style:./gridComponent.vue":"i04xN","custom:./gridComponent.vue":"eiFZL","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"erzd1":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _applicationCardVue = require("./applicationCard.vue");
var _applicationCardVueDefault = parcelHelpers.interopDefault(_applicationCardVue);
var scriptExports = {
    name: "GridComponent",
    components: {
        ApplicationCard: (0, _applicationCardVueDefault.default)
    },
    props: {
        groups: {
            default: ()=>[]
        },
        categories: {
            default: ()=>[]
        },
        isMobile: {
            type: Boolean,
            default: false
        },
        favoriteApps: {
            default: ()=>[]
        }
    },
    data () {
        return {
            headers: [],
            mobileHeaders: [],
            favoriteObj: {}
        };
    },
    mounted () {
        this.headers = this.formatHeaders(this.groups);
    },
    methods: {
        displayRow (item) {
            if ((item.value === "favoris" || item.id === "favoris") && (!item.Applications || item.Applications.length === 0)) return false;
            return true;
        },
        formatHeaders (headers) {
            if (this.isMobile) {
                this.mobileHeaders = headers.map((el)=>el.id || el.value || el.name);
                return [
                    {
                        text: "",
                        value: "name",
                        sortable: false
                    },
                    {
                        text: "",
                        value: "apps",
                        sortable: false
                    }, 
                ];
            }
            return [
                {
                    text: "",
                    value: "name"
                },
                ...headers
            ].map((el, index)=>({
                    text: el.text || el.name,
                    value: el.id || el.value || el.name,
                    sortable: false
                }));
        },
        exploreApp (item) {
            this.$emit("exploreApp", item);
        },
        addAppToFavoris (data) {
            this.$emit("addAppToFavoris", data);
        },
        goToApp (data) {
            this.$emit("goToApp", data);
        },
        isFavorite (applicationData) {
            return this.favoriteObj[applicationData.id] ? true : false;
        }
    },
    computed: {
        getWidth () {
            const headerLength = this.groups.length + 1;
            return {
                width: "100%"
            };
        },
        cardStyle () {
            const headerLength = this.groups.length;
            const width = headerLength < 2 && !this.isMobile ? 32 : 100;
            return {
                width: `${width}%`,
                "margin-right": "10px"
            };
        }
    },
    watch: {
        favoriteApps () {
            const obj = {};
            this.favoriteApps.forEach((el)=>{
                obj[el.id] = el;
            });
            this.favoriteObj = obj;
        },
        isMobile () {
            this.headers = this.formatHeaders(this.groups);
        },
        groups () {
            this.headers = this.formatHeaders(this.groups);
        }
    }
};
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"./applicationCard.vue":"hNoSO","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"hNoSO":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./applicationCard.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./applicationCard.vue").render;
    script.staticRenderFns = require("template:./applicationCard.vue").staticRenderFns;
    script._scopeId = "data-v-87d361";
    script.__cssModules = require("style:./applicationCard.vue").default;
    require("custom:./applicationCard.vue").default(script);
    script.__scopeId = "data-v-87d361";
    script.__file = "applicationCard.vue";
};
initialize();
exports.default = script;

},{"script:./applicationCard.vue":"7SIYK","template:./applicationCard.vue":"k0Qdn","style:./applicationCard.vue":"lp9aL","custom:./applicationCard.vue":"91t6w","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"7SIYK":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "applicationCard",
    props: {
        data: {},
        isFavorite: {
            type: Boolean,
            default: ()=>false
        }
    },
    data () {
        return {
            show: false
        };
    },
    methods: {
        goToApplication (event) {
            this.$emit("goToApp", {
                event,
                item: this.data
            });
        },
        exploreApp () {
            this.$emit("exploreApp", this.data);
        },
        addAppToFavoris () {
            this.$emit("addAppToFavoris", {
                item: this.data,
                isFavorite: this.isFavorite
            });
        },
        goToDocumentation () {
            if (this.data.documentationLink) return window.open(this.data.documentationLink, "_blank");
        }
    },
    computed: {
        getTagsTitle () {
            return this.data.tags.join(", ");
        }
    }
};
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"k0Qdn":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("v-card", {
        staticClass: "appCardContainer",
        on: {
            "click": _vm.goToApplication
        }
    }, [
        _c("div", {
            staticClass: "cardContent"
        }, [
            _c("div", {
                staticClass: "left"
            }, [
                _c("v-card", {
                    staticClass: "iconDiv"
                }, [
                    _c("v-icon", {
                        attrs: {
                            "color": "#000000"
                        }
                    }, [
                        _vm._v(_vm._s(_vm.data.icon))
                    ])
                ], 1)
            ], 1),
            _vm._v(" "),
            _c("div", {
                staticClass: "right"
            }, [
                _c("div", {
                    staticClass: "name",
                    attrs: {
                        "title": _vm.data.name
                    }
                }, [
                    _vm._v("\n        " + _vm._s(_vm.data.name) + "\n      ")
                ]),
                _vm._v(" "),
                _c("div", {
                    staticClass: "description",
                    attrs: {
                        "title": _vm.data.description
                    }
                }, [
                    _vm._v("\n        " + _vm._s(_vm.data.description) + "\n      ")
                ]),
                _vm._v(" "),
                _c("div", {
                    staticClass: "tags",
                    attrs: {
                        "title": _vm.getTagsTitle
                    }
                }, _vm._l(_vm.data.tags, function(tag, index) {
                    return _c("v-chip", {
                        key: index,
                        staticClass: "chip",
                        attrs: {
                            "label": "",
                            "color": "#6699cc",
                            "small": ""
                        }
                    }, [
                        _c("v-icon", {
                            attrs: {
                                "left": "",
                                "color": "#ffffff"
                            }
                        }, [
                            _vm._v(" mdi-circle-small ")
                        ]),
                        _vm._v("\n          " + _vm._s(tag.toUpperCase()) + "\n        ")
                    ], 1);
                }), 1),
                _vm._v(" "),
                _c("div", {
                    staticClass: "actions"
                }, [
                    _c("div", [
                        _c("v-btn", {
                            staticClass: "favorisBtn",
                            class: {
                                "isFavorite": _vm.isFavorite
                            },
                            attrs: {
                                "icon": "",
                                "outlined": "",
                                "title": "ajouter aux favoris"
                            },
                            on: {
                                "click": function($event) {
                                    $event.stopPropagation();
                                    return _vm.addAppToFavoris.apply(null, arguments);
                                }
                            }
                        }, [
                            _c("v-icon", [
                                _vm._v("mdi-star")
                            ])
                        ], 1),
                        _vm._v(" "),
                        _vm.data.documentationLink ? _c("v-btn", {
                            staticClass: "favorisBtn",
                            attrs: {
                                "icon": "",
                                "outlined": "",
                                "title": "Aller \xe0 la documentation"
                            },
                            on: {
                                "click": function($event) {
                                    $event.stopPropagation();
                                    return _vm.goToDocumentation.apply(null, arguments);
                                }
                            }
                        }, [
                            _c("v-icon", [
                                _vm._v("mdi-information-variant")
                            ])
                        ], 1) : _vm._e(),
                        _vm._v(" "),
                        _c("v-btn", {
                            attrs: {
                                "icon": ""
                            },
                            on: {
                                "click": function($event) {
                                    $event.stopPropagation();
                                    _vm.show = !_vm.show;
                                }
                            }
                        }, [
                            _c("v-icon", [
                                _vm._v(_vm._s(_vm.show ? "mdi-chevron-up" : "mdi-chevron-down") + "\n            ")
                            ])
                        ], 1)
                    ], 1)
                ])
            ])
        ]),
        _vm._v(" "),
        _c("v-expand-transition", [
            _c("div", {
                directives: [
                    {
                        name: "show",
                        rawName: "v-show",
                        value: _vm.show,
                        expression: "show"
                    }
                ]
            }, [
                _c("v-divider"),
                _vm._v(" "),
                _c("v-card-text", [
                    _vm._v("\n        " + _vm._s(_vm.data.description) + "\n      ")
                ])
            ], 1)
        ])
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"lp9aL":[function() {},{}],"91t6w":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"55f0y":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _vm.categories && _vm.categories.length > 0 ? _c("v-data-table", {
        staticClass: "dataTable",
        style: _vm.getWidth,
        attrs: {
            "fixed-header": "",
            "dense": "",
            "disable-pagination": "",
            "hide-default-footer": "",
            "headers": _vm.headers,
            "items": _vm.categories,
            "height": "100%"
        },
        scopedSlots: _vm._u([
            {
                key: "body",
                fn: function(ref) {
                    var items = ref.items;
                    return [
                        _vm._l(items, function(item, index) {
                            return _c("tr", {
                                directives: [
                                    {
                                        name: "show",
                                        rawName: "v-show",
                                        value: !_vm.isMobile && _vm.displayRow(item),
                                        expression: "!isMobile && displayRow(item)"
                                    }
                                ],
                                key: item.id + "_" + index,
                                staticClass: "categoriesRows"
                            }, _vm._l(_vm.headers, function(header, index2) {
                                return _c("td", {
                                    key: header.value + "_" + index2
                                }, [
                                    header.value === "name" ? _c("div", {
                                        staticClass: "categoryName"
                                    }, [
                                        _vm._v("\n          " + _vm._s(item[header.value]) + "\n        ")
                                    ]) : _vm._l(item[header.value], function(applicationData, index3) {
                                        return _c("div", {
                                            key: applicationData.id,
                                            staticClass: "card",
                                            style: _vm.cardStyle
                                        }, [
                                            _c("ApplicationCard", {
                                                attrs: {
                                                    "data": applicationData,
                                                    "isFavorite": _vm.isFavorite(applicationData)
                                                },
                                                on: {
                                                    "goToApp": _vm.goToApp,
                                                    "exploreApp": _vm.exploreApp,
                                                    "addAppToFavoris": _vm.addAppToFavoris
                                                }
                                            })
                                        ], 1);
                                    })
                                ], 2);
                            }), 0);
                        }),
                        _vm._v(" "),
                        _vm._l(items, function(item, index) {
                            return _c("tr", {
                                directives: [
                                    {
                                        name: "show",
                                        rawName: "v-show",
                                        value: _vm.isMobile && _vm.displayRow(item),
                                        expression: "isMobile && displayRow(item)"
                                    }
                                ],
                                key: index + "_" + item.id,
                                staticClass: "categoriesRows"
                            }, [
                                _c("td", [
                                    _c("div", {
                                        staticClass: "categoryName"
                                    }, [
                                        _vm._v("\n          " + _vm._s(item.name) + "\n        ")
                                    ])
                                ]),
                                _vm._v(" "),
                                _c("td", {
                                    staticClass: "mobile-td"
                                }, _vm._l(_vm.mobileHeaders, function(group, index2) {
                                    return item[group] ? _c("div", {
                                        key: index2 + "_" + group,
                                        staticClass: "card"
                                    }, [
                                        _c("div", {
                                            staticClass: "group_name"
                                        }, [
                                            _vm._v(_vm._s(group))
                                        ]),
                                        _vm._v(" "),
                                        _vm._l(item[group], function(applicationData, index3) {
                                            return _c("div", {
                                                key: index3,
                                                style: _vm.cardStyle
                                            }, [
                                                _c("ApplicationCard", {
                                                    attrs: {
                                                        "data": applicationData,
                                                        "isFavorite": _vm.isFavorite(applicationData)
                                                    },
                                                    on: {
                                                        "goToApp": _vm.goToApp,
                                                        "exploreApp": _vm.exploreApp,
                                                        "addAppToFavoris": _vm.addAppToFavoris
                                                    }
                                                })
                                            ], 1);
                                        })
                                    ], 2) : _vm._e();
                                }), 0)
                            ]);
                        })
                    ];
                }
            }
        ], null, false, 4202429504)
    }) : !_vm.categories || _vm.categories.length === 0 ? _c("div", {
        staticClass: "emptyApplication"
    }, [
        _c("v-alert", {
            attrs: {
                "border": "bottom",
                "colored-border": "",
                "type": "warning",
                "elevation": "2"
            }
        }, [
            _vm._v("\n    Aucune application \xe0 afficher\n  ")
        ])
    ], 1) : _vm._e();
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"i04xN":[function() {},{}],"eiFZL":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"6sanV":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("v-container", {
        staticClass: "appContainer",
        attrs: {
            "fluid": ""
        }
    }, [
        _c("div", {
            staticClass: "my_header"
        }, [
            _c("div", {
                staticClass: "description"
            }, [
                _c("p", [
                    _vm._v("Consultez toutes les donn\xe9es de vos b\xe2timents connect\xe9s.")
                ]),
                _vm._v(" "),
                _c("p", [
                    _vm._v("\n        Vous pouvez garder en favoris une visualisation en cliquant sur\n        "),
                    _c("v-btn", {
                        staticClass: "favorisBtn",
                        attrs: {
                            "outlined": "",
                            "small": "",
                            "disabled": ""
                        }
                    }, [
                        _c("v-icon", [
                            _vm._v("mdi-star")
                        ])
                    ], 1)
                ], 1)
            ]),
            _vm._v(" "),
            _c("v-row", {
                staticClass: "search"
            }, [
                _c("v-col", {
                    staticClass: "searchCol",
                    attrs: {
                        "cols": "8"
                    }
                }, [
                    _c("v-text-field", {
                        attrs: {
                            "solo": "",
                            "flat": "",
                            "placeholder": "rechercher",
                            "prepend-inner-icon": "mdi-magnify"
                        },
                        model: {
                            value: _vm.filtersData.search,
                            callback: function($$v) {
                                _vm.$set(_vm.filtersData, "search", $$v);
                            },
                            expression: "filtersData.search"
                        }
                    })
                ], 1),
                _vm._v(" "),
                _c("v-col", {
                    attrs: {
                        "cols": "4"
                    }
                }, [
                    _c("v-select", {
                        attrs: {
                            "solo": "",
                            "flat": "",
                            "append-icon": "",
                            "prepend-inner-icon": "mdi-chevron-down",
                            "items": _vm.selects,
                            "item-text": "name",
                            "item-value": "value",
                            "label": "Select",
                            "persistent-hint": "",
                            "return-object": "",
                            "single-line": ""
                        },
                        model: {
                            value: _vm.filtersData.category,
                            callback: function($$v) {
                                _vm.$set(_vm.filtersData, "category", $$v);
                            },
                            expression: "filtersData.category"
                        }
                    })
                ], 1)
            ], 1)
        ], 1),
        _vm._v(" "),
        _c("v-layout", {
            staticClass: "apps-container"
        }, [
            _c("v-flex", {
                staticStyle: {
                    "overflow": "auto"
                }
            }, [
                _c("GridComponent", {
                    attrs: {
                        "groups": _vm.groups,
                        "categories": _vm.categoriesDisplayed,
                        "isMobile": _vm.isMobile,
                        "favoriteApps": _vm.favoriteApps
                    },
                    on: {
                        "goToApp": _vm.goToApp,
                        "exploreApp": _vm.exploreApp,
                        "addAppToFavoris": _vm.addAppToFavoris
                    }
                })
            ], 1)
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"84ISk":[function() {},{}],"3aLym":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}]},[], null, "parcelRequire2d5a")

//# sourceMappingURL=HomeView.65a1982b.js.map
