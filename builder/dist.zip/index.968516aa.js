// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"2drtI":[function(require,module,exports) {
require("./helpers/bundle-manifest").register(JSON.parse('{"4wOkc":"index.968516aa.js","dpak1":"logo.50a77451.jpg","elXhd":"ApplicationView.e97e052c.js","5ixwV":"index.41ce7eea.css","53ivn":"ApplicationView.831b4601.css","jXCzs":"HomeView.65a1982b.js","3kKuF":"HomeView.10ae621c.css","9s27O":"HomeView.49dd41d8.js","f1AkW":"index.d2413810.js"}'));

},{"./helpers/bundle-manifest":"8Y9me"}],"8Y9me":[function(require,module,exports) {
"use strict";
var mapping = {};
function register(pairs) {
    var keys = Object.keys(pairs);
    for(var i = 0; i < keys.length; i++)mapping[keys[i]] = pairs[keys[i]];
}
function resolve(id) {
    var resolved = mapping[id];
    if (resolved == null) throw new Error("Could not resolve bundle with id " + id);
    return resolved;
}
module.exports.register = register;
module.exports.resolve = resolve;

},{}],"6qBNO":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ //API VIEWER APP
var _esTypedArraySetJs = require("core-js/modules/es.typed-array.set.js");
var _webImmediateJs = require("core-js/modules/web.immediate.js");
var _spinalAPI = require("global-components/requests/SpinalAPI");
var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
var _vuetify = require("./plugins/vuetify");
var _router = require("./router");
var _store = require("./store");
var _storeDefault = parcelHelpers.interopDefault(_store);
var _requests = require("./requests");
var _vueCookie = require("vue-cookie");
var _vueCookieDefault = parcelHelpers.interopDefault(_vueCookie);
var _appVue = require("./App.vue");
var _appVueDefault = parcelHelpers.interopDefault(_appVue);
var _iframeEventBus = require("./events/iframeEventBus");
var _resetCss = require("../assets/css/basic/reset.css");
var _mainLess = require("../assets/css/basic/main.less");
var _navPickerAppCss = require("../assets/css/component/navPickerApp.css");
var _materialDesignIconsIconfont = require("material-design-icons-iconfont");
(0, _spinalAPI.SpinalAPI).setHook(window);
const api = (0, _spinalAPI.SpinalAPI).getInstance("http://localhost:8065");
const apiMode = "PAM_APP";
if (apiMode === "BOS_APP" || apiMode === "PAM_APP") api.setApiMode((0, _spinalAPI.API_MODE)[apiMode]);
else {
    console.warn(`Invalid MODE in .env: ${apiMode}. Defaulting to PAM_APP.`);
    api.setApiMode((0, _spinalAPI.API_MODE).PAM_APP);
}
(0, _vuetify.vuetifyInit)((0, _vueDefault.default));
(0, _router.routerInit)((0, _vueDefault.default));
(0, _requests.initAxios)();
(0, _vueDefault.default).config.productionTip = false;
(0, _vueDefault.default).use((0, _vueCookieDefault.default));
new (0, _vueDefault.default)({
    router: (0, _router.router),
    vuetify: (0, _vuetify.vuetify),
    store: (0, _storeDefault.default),
    render: (h)=>h((0, _appVueDefault.default))
}).$mount("#app");

},{"core-js/modules/es.typed-array.set.js":"gDONS","core-js/modules/web.immediate.js":"Mtge7","global-components/requests/SpinalAPI":"ewILu","vue":"kjivF","./plugins/vuetify":"9mill","./router":"6uyOv","./store":"xP4vH","./requests":"8Ir1L","vue-cookie":"hYzMD","./App.vue":"ccoPX","./events/iframeEventBus":"2bdJo","../assets/css/basic/reset.css":"3R6lQ","../assets/css/basic/main.less":"7UmA6","../assets/css/component/navPickerApp.css":"8aAZ7","material-design-icons-iconfont":"eXINW","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"gDONS":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var call = require("../internals/function-call");
var ArrayBufferViewCore = require("../internals/array-buffer-view-core");
var lengthOfArrayLike = require("../internals/length-of-array-like");
var toOffset = require("../internals/to-offset");
var toIndexedObject = require("../internals/to-object");
var fails = require("../internals/fails");
var RangeError = globalThis.RangeError;
var Int8Array = globalThis.Int8Array;
var Int8ArrayPrototype = Int8Array && Int8Array.prototype;
var $set = Int8ArrayPrototype && Int8ArrayPrototype.set;
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS = !fails(function() {
    // eslint-disable-next-line es/no-typed-arrays -- required for testing
    var array = new Uint8ClampedArray(2);
    call($set, array, {
        length: 1,
        0: 3
    }, 1);
    return array[1] !== 3;
});
// https://bugs.chromium.org/p/v8/issues/detail?id=11294 and other
var TO_OBJECT_BUG = WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS && ArrayBufferViewCore.NATIVE_ARRAY_BUFFER_VIEWS && fails(function() {
    var array = new Int8Array(2);
    array.set(1);
    array.set("2", 1);
    return array[0] !== 0 || array[1] !== 2;
});
// `%TypedArray%.prototype.set` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.set
exportTypedArrayMethod("set", function set(arrayLike /* , offset */ ) {
    aTypedArray(this);
    var offset = toOffset(arguments.length > 1 ? arguments[1] : undefined, 1);
    var src = toIndexedObject(arrayLike);
    if (WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS) return call($set, this, src, offset);
    var length = this.length;
    var len = lengthOfArrayLike(src);
    var index = 0;
    if (len + offset > length) throw new RangeError("Wrong length");
    while(index < len)this[offset + index] = src[index++];
}, !WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS || TO_OBJECT_BUG);

},{"../internals/global-this":"7pHu3","../internals/function-call":"LSGTG","../internals/array-buffer-view-core":"8xM6L","../internals/length-of-array-like":"1Li6S","../internals/to-offset":"8fkuK","../internals/to-object":"bs0Bh","../internals/fails":"enAJz"}],"7pHu3":[function(require,module,exports) {
"use strict";
var global = arguments[3];
var check = function(it) {
    return it && it.Math === Math && it;
};
// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
module.exports = // eslint-disable-next-line es/no-global-this -- safe
check(typeof globalThis == "object" && globalThis) || check(typeof window == "object" && window) || // eslint-disable-next-line no-restricted-globals -- safe
check(typeof self == "object" && self) || check(typeof global == "object" && global) || check(typeof this == "object" && this) || // eslint-disable-next-line no-new-func -- fallback
function() {
    return this;
}() || Function("return this")();

},{}],"LSGTG":[function(require,module,exports) {
"use strict";
var NATIVE_BIND = require("../internals/function-bind-native");
var call = Function.prototype.call;
module.exports = NATIVE_BIND ? call.bind(call) : function() {
    return call.apply(call, arguments);
};

},{"../internals/function-bind-native":"1KPaH"}],"1KPaH":[function(require,module,exports) {
"use strict";
var fails = require("../internals/fails");
module.exports = !fails(function() {
    // eslint-disable-next-line es/no-function-prototype-bind -- safe
    var test = (function() {}).bind();
    // eslint-disable-next-line no-prototype-builtins -- safe
    return typeof test != "function" || test.hasOwnProperty("prototype");
});

},{"../internals/fails":"enAJz"}],"enAJz":[function(require,module,exports) {
"use strict";
module.exports = function(exec) {
    try {
        return !!exec();
    } catch (error) {
        return true;
    }
};

},{}],"8xM6L":[function(require,module,exports) {
"use strict";
var NATIVE_ARRAY_BUFFER = require("../internals/array-buffer-basic-detection");
var DESCRIPTORS = require("../internals/descriptors");
var globalThis = require("../internals/global-this");
var isCallable = require("../internals/is-callable");
var isObject = require("../internals/is-object");
var hasOwn = require("../internals/has-own-property");
var classof = require("../internals/classof");
var tryToString = require("../internals/try-to-string");
var createNonEnumerableProperty = require("../internals/create-non-enumerable-property");
var defineBuiltIn = require("../internals/define-built-in");
var defineBuiltInAccessor = require("../internals/define-built-in-accessor");
var isPrototypeOf = require("../internals/object-is-prototype-of");
var getPrototypeOf = require("../internals/object-get-prototype-of");
var setPrototypeOf = require("../internals/object-set-prototype-of");
var wellKnownSymbol = require("../internals/well-known-symbol");
var uid = require("../internals/uid");
var InternalStateModule = require("../internals/internal-state");
var enforceInternalState = InternalStateModule.enforce;
var getInternalState = InternalStateModule.get;
var Int8Array = globalThis.Int8Array;
var Int8ArrayPrototype = Int8Array && Int8Array.prototype;
var Uint8ClampedArray = globalThis.Uint8ClampedArray;
var Uint8ClampedArrayPrototype = Uint8ClampedArray && Uint8ClampedArray.prototype;
var TypedArray = Int8Array && getPrototypeOf(Int8Array);
var TypedArrayPrototype = Int8ArrayPrototype && getPrototypeOf(Int8ArrayPrototype);
var ObjectPrototype = Object.prototype;
var TypeError = globalThis.TypeError;
var TO_STRING_TAG = wellKnownSymbol("toStringTag");
var TYPED_ARRAY_TAG = uid("TYPED_ARRAY_TAG");
var TYPED_ARRAY_CONSTRUCTOR = "TypedArrayConstructor";
// Fixing native typed arrays in Opera Presto crashes the browser, see #595
var NATIVE_ARRAY_BUFFER_VIEWS = NATIVE_ARRAY_BUFFER && !!setPrototypeOf && classof(globalThis.opera) !== "Opera";
var TYPED_ARRAY_TAG_REQUIRED = false;
var NAME, Constructor, Prototype;
var TypedArrayConstructorsList = {
    Int8Array: 1,
    Uint8Array: 1,
    Uint8ClampedArray: 1,
    Int16Array: 2,
    Uint16Array: 2,
    Int32Array: 4,
    Uint32Array: 4,
    Float32Array: 4,
    Float64Array: 8
};
var BigIntArrayConstructorsList = {
    BigInt64Array: 8,
    BigUint64Array: 8
};
var isView = function isView(it) {
    if (!isObject(it)) return false;
    var klass = classof(it);
    return klass === "DataView" || hasOwn(TypedArrayConstructorsList, klass) || hasOwn(BigIntArrayConstructorsList, klass);
};
var getTypedArrayConstructor = function(it) {
    var proto = getPrototypeOf(it);
    if (!isObject(proto)) return;
    var state = getInternalState(proto);
    return state && hasOwn(state, TYPED_ARRAY_CONSTRUCTOR) ? state[TYPED_ARRAY_CONSTRUCTOR] : getTypedArrayConstructor(proto);
};
var isTypedArray = function(it) {
    if (!isObject(it)) return false;
    var klass = classof(it);
    return hasOwn(TypedArrayConstructorsList, klass) || hasOwn(BigIntArrayConstructorsList, klass);
};
var aTypedArray = function(it) {
    if (isTypedArray(it)) return it;
    throw new TypeError("Target is not a typed array");
};
var aTypedArrayConstructor = function(C) {
    if (isCallable(C) && (!setPrototypeOf || isPrototypeOf(TypedArray, C))) return C;
    throw new TypeError(tryToString(C) + " is not a typed array constructor");
};
var exportTypedArrayMethod = function(KEY, property, forced, options) {
    if (!DESCRIPTORS) return;
    if (forced) for(var ARRAY in TypedArrayConstructorsList){
        var TypedArrayConstructor = globalThis[ARRAY];
        if (TypedArrayConstructor && hasOwn(TypedArrayConstructor.prototype, KEY)) try {
            delete TypedArrayConstructor.prototype[KEY];
        } catch (error) {
            // old WebKit bug - some methods are non-configurable
            try {
                TypedArrayConstructor.prototype[KEY] = property;
            } catch (error2) {}
        }
    }
    if (!TypedArrayPrototype[KEY] || forced) defineBuiltIn(TypedArrayPrototype, KEY, forced ? property : NATIVE_ARRAY_BUFFER_VIEWS && Int8ArrayPrototype[KEY] || property, options);
};
var exportTypedArrayStaticMethod = function(KEY, property, forced) {
    var ARRAY, TypedArrayConstructor;
    if (!DESCRIPTORS) return;
    if (setPrototypeOf) {
        if (forced) for(ARRAY in TypedArrayConstructorsList){
            TypedArrayConstructor = globalThis[ARRAY];
            if (TypedArrayConstructor && hasOwn(TypedArrayConstructor, KEY)) try {
                delete TypedArrayConstructor[KEY];
            } catch (error) {}
        }
        if (!TypedArray[KEY] || forced) // V8 ~ Chrome 49-50 `%TypedArray%` methods are non-writable non-configurable
        try {
            return defineBuiltIn(TypedArray, KEY, forced ? property : NATIVE_ARRAY_BUFFER_VIEWS && TypedArray[KEY] || property);
        } catch (error1) {}
        else return;
    }
    for(ARRAY in TypedArrayConstructorsList){
        TypedArrayConstructor = globalThis[ARRAY];
        if (TypedArrayConstructor && (!TypedArrayConstructor[KEY] || forced)) defineBuiltIn(TypedArrayConstructor, KEY, property);
    }
};
for(NAME in TypedArrayConstructorsList){
    Constructor = globalThis[NAME];
    Prototype = Constructor && Constructor.prototype;
    if (Prototype) enforceInternalState(Prototype)[TYPED_ARRAY_CONSTRUCTOR] = Constructor;
    else NATIVE_ARRAY_BUFFER_VIEWS = false;
}
for(NAME in BigIntArrayConstructorsList){
    Constructor = globalThis[NAME];
    Prototype = Constructor && Constructor.prototype;
    if (Prototype) enforceInternalState(Prototype)[TYPED_ARRAY_CONSTRUCTOR] = Constructor;
}
// WebKit bug - typed arrays constructors prototype is Object.prototype
if (!NATIVE_ARRAY_BUFFER_VIEWS || !isCallable(TypedArray) || TypedArray === Function.prototype) {
    // eslint-disable-next-line no-shadow -- safe
    TypedArray = function TypedArray() {
        throw new TypeError("Incorrect invocation");
    };
    if (NATIVE_ARRAY_BUFFER_VIEWS) {
        for(NAME in TypedArrayConstructorsList)if (globalThis[NAME]) setPrototypeOf(globalThis[NAME], TypedArray);
    }
}
if (!NATIVE_ARRAY_BUFFER_VIEWS || !TypedArrayPrototype || TypedArrayPrototype === ObjectPrototype) {
    TypedArrayPrototype = TypedArray.prototype;
    if (NATIVE_ARRAY_BUFFER_VIEWS) {
        for(NAME in TypedArrayConstructorsList)if (globalThis[NAME]) setPrototypeOf(globalThis[NAME].prototype, TypedArrayPrototype);
    }
}
// WebKit bug - one more object in Uint8ClampedArray prototype chain
if (NATIVE_ARRAY_BUFFER_VIEWS && getPrototypeOf(Uint8ClampedArrayPrototype) !== TypedArrayPrototype) setPrototypeOf(Uint8ClampedArrayPrototype, TypedArrayPrototype);
if (DESCRIPTORS && !hasOwn(TypedArrayPrototype, TO_STRING_TAG)) {
    TYPED_ARRAY_TAG_REQUIRED = true;
    defineBuiltInAccessor(TypedArrayPrototype, TO_STRING_TAG, {
        configurable: true,
        get: function() {
            return isObject(this) ? this[TYPED_ARRAY_TAG] : undefined;
        }
    });
    for(NAME in TypedArrayConstructorsList)if (globalThis[NAME]) createNonEnumerableProperty(globalThis[NAME], TYPED_ARRAY_TAG, NAME);
}
module.exports = {
    NATIVE_ARRAY_BUFFER_VIEWS: NATIVE_ARRAY_BUFFER_VIEWS,
    TYPED_ARRAY_TAG: TYPED_ARRAY_TAG_REQUIRED && TYPED_ARRAY_TAG,
    aTypedArray: aTypedArray,
    aTypedArrayConstructor: aTypedArrayConstructor,
    exportTypedArrayMethod: exportTypedArrayMethod,
    exportTypedArrayStaticMethod: exportTypedArrayStaticMethod,
    getTypedArrayConstructor: getTypedArrayConstructor,
    isView: isView,
    isTypedArray: isTypedArray,
    TypedArray: TypedArray,
    TypedArrayPrototype: TypedArrayPrototype
};

},{"../internals/array-buffer-basic-detection":"gdbBx","../internals/descriptors":"5sGjX","../internals/global-this":"7pHu3","../internals/is-callable":"4eoFc","../internals/is-object":"56u2g","../internals/has-own-property":"k8LoH","../internals/classof":"epU3j","../internals/try-to-string":"hCkh0","../internals/create-non-enumerable-property":"jcucH","../internals/define-built-in":"96dlH","../internals/define-built-in-accessor":"6atWd","../internals/object-is-prototype-of":"h0BNG","../internals/object-get-prototype-of":"kG1y9","../internals/object-set-prototype-of":"3pXN4","../internals/well-known-symbol":"gRZy4","../internals/uid":"7S6zE","../internals/internal-state":"k6xzl"}],"gdbBx":[function(require,module,exports) {
"use strict";
// eslint-disable-next-line es/no-typed-arrays -- safe
module.exports = typeof ArrayBuffer != "undefined" && typeof DataView != "undefined";

},{}],"5sGjX":[function(require,module,exports) {
"use strict";
var fails = require("../internals/fails");
// Detect IE8's incomplete defineProperty implementation
module.exports = !fails(function() {
    // eslint-disable-next-line es/no-object-defineproperty -- required for testing
    return Object.defineProperty({}, 1, {
        get: function() {
            return 7;
        }
    })[1] !== 7;
});

},{"../internals/fails":"enAJz"}],"4eoFc":[function(require,module,exports) {
"use strict";
// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot
var documentAll = typeof document == "object" && document.all;
// `IsCallable` abstract operation
// https://tc39.es/ecma262/#sec-iscallable
// eslint-disable-next-line unicorn/no-typeof-undefined -- required for testing
module.exports = typeof documentAll == "undefined" && documentAll !== undefined ? function(argument) {
    return typeof argument == "function" || argument === documentAll;
} : function(argument) {
    return typeof argument == "function";
};

},{}],"56u2g":[function(require,module,exports) {
"use strict";
var isCallable = require("../internals/is-callable");
module.exports = function(it) {
    return typeof it == "object" ? it !== null : isCallable(it);
};

},{"../internals/is-callable":"4eoFc"}],"k8LoH":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
var toObject = require("../internals/to-object");
var hasOwnProperty = uncurryThis({}.hasOwnProperty);
// `HasOwnProperty` abstract operation
// https://tc39.es/ecma262/#sec-hasownproperty
// eslint-disable-next-line es/no-object-hasown -- safe
module.exports = Object.hasOwn || function hasOwn(it, key) {
    return hasOwnProperty(toObject(it), key);
};

},{"../internals/function-uncurry-this":"ciO8u","../internals/to-object":"bs0Bh"}],"ciO8u":[function(require,module,exports) {
"use strict";
var NATIVE_BIND = require("../internals/function-bind-native");
var FunctionPrototype = Function.prototype;
var call = FunctionPrototype.call;
var uncurryThisWithBind = NATIVE_BIND && FunctionPrototype.bind.bind(call, call);
module.exports = NATIVE_BIND ? uncurryThisWithBind : function(fn) {
    return function() {
        return call.apply(fn, arguments);
    };
};

},{"../internals/function-bind-native":"1KPaH"}],"bs0Bh":[function(require,module,exports) {
"use strict";
var requireObjectCoercible = require("../internals/require-object-coercible");
var $Object = Object;
// `ToObject` abstract operation
// https://tc39.es/ecma262/#sec-toobject
module.exports = function(argument) {
    return $Object(requireObjectCoercible(argument));
};

},{"../internals/require-object-coercible":"fHjbZ"}],"fHjbZ":[function(require,module,exports) {
"use strict";
var isNullOrUndefined = require("../internals/is-null-or-undefined");
var $TypeError = TypeError;
// `RequireObjectCoercible` abstract operation
// https://tc39.es/ecma262/#sec-requireobjectcoercible
module.exports = function(it) {
    if (isNullOrUndefined(it)) throw new $TypeError("Can't call method on " + it);
    return it;
};

},{"../internals/is-null-or-undefined":"6AGhF"}],"6AGhF":[function(require,module,exports) {
"use strict";
// we can't use just `it == null` since of `document.all` special case
// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot-aec
module.exports = function(it) {
    return it === null || it === undefined;
};

},{}],"epU3j":[function(require,module,exports) {
"use strict";
var TO_STRING_TAG_SUPPORT = require("../internals/to-string-tag-support");
var isCallable = require("../internals/is-callable");
var classofRaw = require("../internals/classof-raw");
var wellKnownSymbol = require("../internals/well-known-symbol");
var TO_STRING_TAG = wellKnownSymbol("toStringTag");
var $Object = Object;
// ES3 wrong here
var CORRECT_ARGUMENTS = classofRaw(function() {
    return arguments;
}()) === "Arguments";
// fallback for IE11 Script Access Denied error
var tryGet = function(it, key) {
    try {
        return it[key];
    } catch (error) {}
};
// getting tag from ES6+ `Object.prototype.toString`
module.exports = TO_STRING_TAG_SUPPORT ? classofRaw : function(it) {
    var O, tag, result;
    return it === undefined ? "Undefined" : it === null ? "Null" : typeof (tag = tryGet(O = $Object(it), TO_STRING_TAG)) == "string" ? tag : CORRECT_ARGUMENTS ? classofRaw(O) : (result = classofRaw(O)) === "Object" && isCallable(O.callee) ? "Arguments" : result;
};

},{"../internals/to-string-tag-support":"vT4ps","../internals/is-callable":"4eoFc","../internals/classof-raw":"kxgZU","../internals/well-known-symbol":"gRZy4"}],"vT4ps":[function(require,module,exports) {
"use strict";
var wellKnownSymbol = require("../internals/well-known-symbol");
var TO_STRING_TAG = wellKnownSymbol("toStringTag");
var test = {};
test[TO_STRING_TAG] = "z";
module.exports = String(test) === "[object z]";

},{"../internals/well-known-symbol":"gRZy4"}],"gRZy4":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var shared = require("../internals/shared");
var hasOwn = require("../internals/has-own-property");
var uid = require("../internals/uid");
var NATIVE_SYMBOL = require("../internals/symbol-constructor-detection");
var USE_SYMBOL_AS_UID = require("../internals/use-symbol-as-uid");
var Symbol = globalThis.Symbol;
var WellKnownSymbolsStore = shared("wks");
var createWellKnownSymbol = USE_SYMBOL_AS_UID ? Symbol["for"] || Symbol : Symbol && Symbol.withoutSetter || uid;
module.exports = function(name) {
    if (!hasOwn(WellKnownSymbolsStore, name)) WellKnownSymbolsStore[name] = NATIVE_SYMBOL && hasOwn(Symbol, name) ? Symbol[name] : createWellKnownSymbol("Symbol." + name);
    return WellKnownSymbolsStore[name];
};

},{"../internals/global-this":"7pHu3","../internals/shared":"eJJkk","../internals/has-own-property":"k8LoH","../internals/uid":"7S6zE","../internals/symbol-constructor-detection":"11eBn","../internals/use-symbol-as-uid":"4Szng"}],"eJJkk":[function(require,module,exports) {
"use strict";
var store = require("../internals/shared-store");
module.exports = function(key, value) {
    return store[key] || (store[key] = value || {});
};

},{"../internals/shared-store":"1jrjr"}],"1jrjr":[function(require,module,exports) {
"use strict";
var IS_PURE = require("../internals/is-pure");
var globalThis = require("../internals/global-this");
var defineGlobalProperty = require("../internals/define-global-property");
var SHARED = "__core-js_shared__";
var store = module.exports = globalThis[SHARED] || defineGlobalProperty(SHARED, {});
(store.versions || (store.versions = [])).push({
    version: "3.39.0",
    mode: IS_PURE ? "pure" : "global",
    copyright: "\xa9 2014-2024 Denis Pushkarev (zloirock.ru)",
    license: "https://github.com/zloirock/core-js/blob/v3.39.0/LICENSE",
    source: "https://github.com/zloirock/core-js"
});

},{"../internals/is-pure":"eInfd","../internals/global-this":"7pHu3","../internals/define-global-property":"2bbQC"}],"eInfd":[function(require,module,exports) {
"use strict";
module.exports = false;

},{}],"2bbQC":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
module.exports = function(key, value) {
    try {
        defineProperty(globalThis, key, {
            value: value,
            configurable: true,
            writable: true
        });
    } catch (error) {
        globalThis[key] = value;
    }
    return value;
};

},{"../internals/global-this":"7pHu3"}],"7S6zE":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
var id = 0;
var postfix = Math.random();
var toString = uncurryThis(1.0.toString);
module.exports = function(key) {
    return "Symbol(" + (key === undefined ? "" : key) + ")_" + toString(++id + postfix, 36);
};

},{"../internals/function-uncurry-this":"ciO8u"}],"11eBn":[function(require,module,exports) {
"use strict";
/* eslint-disable es/no-symbol -- required for testing */ var V8_VERSION = require("../internals/environment-v8-version");
var fails = require("../internals/fails");
var globalThis = require("../internals/global-this");
var $String = globalThis.String;
// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
module.exports = !!Object.getOwnPropertySymbols && !fails(function() {
    var symbol = Symbol("symbol detection");
    // Chrome 38 Symbol has incorrect toString conversion
    // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
    // nb: Do not call `String` directly to avoid this being optimized out to `symbol+''` which will,
    // of course, fail.
    return !$String(symbol) || !(Object(symbol) instanceof Symbol) || // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
    !Symbol.sham && V8_VERSION && V8_VERSION < 41;
});

},{"../internals/environment-v8-version":"d8TY2","../internals/fails":"enAJz","../internals/global-this":"7pHu3"}],"d8TY2":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var userAgent = require("../internals/environment-user-agent");
var process = globalThis.process;
var Deno = globalThis.Deno;
var versions = process && process.versions || Deno && Deno.version;
var v8 = versions && versions.v8;
var match, version;
if (v8) {
    match = v8.split(".");
    // in old Chrome, versions of V8 isn't V8 = Chrome / 10
    // but their correct versions are not interesting for us
    version = match[0] > 0 && match[0] < 4 ? 1 : +(match[0] + match[1]);
}
// BrowserFS NodeJS `process` polyfill incorrectly set `.v8` to `0.0`
// so check `userAgent` even if `.v8` exists, but 0
if (!version && userAgent) {
    match = userAgent.match(/Edge\/(\d+)/);
    if (!match || match[1] >= 74) {
        match = userAgent.match(/Chrome\/(\d+)/);
        if (match) version = +match[1];
    }
}
module.exports = version;

},{"../internals/global-this":"7pHu3","../internals/environment-user-agent":"aZ8AQ"}],"aZ8AQ":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var navigator = globalThis.navigator;
var userAgent = navigator && navigator.userAgent;
module.exports = userAgent ? String(userAgent) : "";

},{"../internals/global-this":"7pHu3"}],"4Szng":[function(require,module,exports) {
"use strict";
/* eslint-disable es/no-symbol -- required for testing */ var NATIVE_SYMBOL = require("../internals/symbol-constructor-detection");
module.exports = NATIVE_SYMBOL && !Symbol.sham && typeof Symbol.iterator == "symbol";

},{"../internals/symbol-constructor-detection":"11eBn"}],"kxgZU":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
var toString = uncurryThis({}.toString);
var stringSlice = uncurryThis("".slice);
module.exports = function(it) {
    return stringSlice(toString(it), 8, -1);
};

},{"../internals/function-uncurry-this":"ciO8u"}],"hCkh0":[function(require,module,exports) {
"use strict";
var $String = String;
module.exports = function(argument) {
    try {
        return $String(argument);
    } catch (error) {
        return "Object";
    }
};

},{}],"jcucH":[function(require,module,exports) {
"use strict";
var DESCRIPTORS = require("../internals/descriptors");
var definePropertyModule = require("../internals/object-define-property");
var createPropertyDescriptor = require("../internals/create-property-descriptor");
module.exports = DESCRIPTORS ? function(object, key, value) {
    return definePropertyModule.f(object, key, createPropertyDescriptor(1, value));
} : function(object, key, value) {
    object[key] = value;
    return object;
};

},{"../internals/descriptors":"5sGjX","../internals/object-define-property":"eyQwQ","../internals/create-property-descriptor":"dIkwH"}],"eyQwQ":[function(require,module,exports) {
"use strict";
var DESCRIPTORS = require("../internals/descriptors");
var IE8_DOM_DEFINE = require("../internals/ie8-dom-define");
var V8_PROTOTYPE_DEFINE_BUG = require("../internals/v8-prototype-define-bug");
var anObject = require("../internals/an-object");
var toPropertyKey = require("../internals/to-property-key");
var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var $defineProperty = Object.defineProperty;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var ENUMERABLE = "enumerable";
var CONFIGURABLE = "configurable";
var WRITABLE = "writable";
// `Object.defineProperty` method
// https://tc39.es/ecma262/#sec-object.defineproperty
exports.f = DESCRIPTORS ? V8_PROTOTYPE_DEFINE_BUG ? function defineProperty(O, P, Attributes) {
    anObject(O);
    P = toPropertyKey(P);
    anObject(Attributes);
    if (typeof O === "function" && P === "prototype" && "value" in Attributes && WRITABLE in Attributes && !Attributes[WRITABLE]) {
        var current = $getOwnPropertyDescriptor(O, P);
        if (current && current[WRITABLE]) {
            O[P] = Attributes.value;
            Attributes = {
                configurable: CONFIGURABLE in Attributes ? Attributes[CONFIGURABLE] : current[CONFIGURABLE],
                enumerable: ENUMERABLE in Attributes ? Attributes[ENUMERABLE] : current[ENUMERABLE],
                writable: false
            };
        }
    }
    return $defineProperty(O, P, Attributes);
} : $defineProperty : function defineProperty(O, P, Attributes) {
    anObject(O);
    P = toPropertyKey(P);
    anObject(Attributes);
    if (IE8_DOM_DEFINE) try {
        return $defineProperty(O, P, Attributes);
    } catch (error) {}
    if ("get" in Attributes || "set" in Attributes) throw new $TypeError("Accessors not supported");
    if ("value" in Attributes) O[P] = Attributes.value;
    return O;
};

},{"../internals/descriptors":"5sGjX","../internals/ie8-dom-define":"bVSCL","../internals/v8-prototype-define-bug":"kystm","../internals/an-object":"hp0ZV","../internals/to-property-key":"cpMtP"}],"bVSCL":[function(require,module,exports) {
"use strict";
var DESCRIPTORS = require("../internals/descriptors");
var fails = require("../internals/fails");
var createElement = require("../internals/document-create-element");
// Thanks to IE8 for its funny defineProperty
module.exports = !DESCRIPTORS && !fails(function() {
    // eslint-disable-next-line es/no-object-defineproperty -- required for testing
    return Object.defineProperty(createElement("div"), "a", {
        get: function() {
            return 7;
        }
    }).a !== 7;
});

},{"../internals/descriptors":"5sGjX","../internals/fails":"enAJz","../internals/document-create-element":"fyV4i"}],"fyV4i":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var isObject = require("../internals/is-object");
var document = globalThis.document;
// typeof document.createElement is 'object' in old IE
var EXISTS = isObject(document) && isObject(document.createElement);
module.exports = function(it) {
    return EXISTS ? document.createElement(it) : {};
};

},{"../internals/global-this":"7pHu3","../internals/is-object":"56u2g"}],"kystm":[function(require,module,exports) {
"use strict";
var DESCRIPTORS = require("../internals/descriptors");
var fails = require("../internals/fails");
// V8 ~ Chrome 36-
// https://bugs.chromium.org/p/v8/issues/detail?id=3334
module.exports = DESCRIPTORS && fails(function() {
    // eslint-disable-next-line es/no-object-defineproperty -- required for testing
    return Object.defineProperty(function() {}, "prototype", {
        value: 42,
        writable: false
    }).prototype !== 42;
});

},{"../internals/descriptors":"5sGjX","../internals/fails":"enAJz"}],"hp0ZV":[function(require,module,exports) {
"use strict";
var isObject = require("../internals/is-object");
var $String = String;
var $TypeError = TypeError;
// `Assert: Type(argument) is Object`
module.exports = function(argument) {
    if (isObject(argument)) return argument;
    throw new $TypeError($String(argument) + " is not an object");
};

},{"../internals/is-object":"56u2g"}],"cpMtP":[function(require,module,exports) {
"use strict";
var toPrimitive = require("../internals/to-primitive");
var isSymbol = require("../internals/is-symbol");
// `ToPropertyKey` abstract operation
// https://tc39.es/ecma262/#sec-topropertykey
module.exports = function(argument) {
    var key = toPrimitive(argument, "string");
    return isSymbol(key) ? key : key + "";
};

},{"../internals/to-primitive":"g8Hwh","../internals/is-symbol":"3sP2p"}],"g8Hwh":[function(require,module,exports) {
"use strict";
var call = require("../internals/function-call");
var isObject = require("../internals/is-object");
var isSymbol = require("../internals/is-symbol");
var getMethod = require("../internals/get-method");
var ordinaryToPrimitive = require("../internals/ordinary-to-primitive");
var wellKnownSymbol = require("../internals/well-known-symbol");
var $TypeError = TypeError;
var TO_PRIMITIVE = wellKnownSymbol("toPrimitive");
// `ToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-toprimitive
module.exports = function(input, pref) {
    if (!isObject(input) || isSymbol(input)) return input;
    var exoticToPrim = getMethod(input, TO_PRIMITIVE);
    var result;
    if (exoticToPrim) {
        if (pref === undefined) pref = "default";
        result = call(exoticToPrim, input, pref);
        if (!isObject(result) || isSymbol(result)) return result;
        throw new $TypeError("Can't convert object to primitive value");
    }
    if (pref === undefined) pref = "number";
    return ordinaryToPrimitive(input, pref);
};

},{"../internals/function-call":"LSGTG","../internals/is-object":"56u2g","../internals/is-symbol":"3sP2p","../internals/get-method":"hYo0A","../internals/ordinary-to-primitive":"a9hsA","../internals/well-known-symbol":"gRZy4"}],"3sP2p":[function(require,module,exports) {
"use strict";
var getBuiltIn = require("../internals/get-built-in");
var isCallable = require("../internals/is-callable");
var isPrototypeOf = require("../internals/object-is-prototype-of");
var USE_SYMBOL_AS_UID = require("../internals/use-symbol-as-uid");
var $Object = Object;
module.exports = USE_SYMBOL_AS_UID ? function(it) {
    return typeof it == "symbol";
} : function(it) {
    var $Symbol = getBuiltIn("Symbol");
    return isCallable($Symbol) && isPrototypeOf($Symbol.prototype, $Object(it));
};

},{"../internals/get-built-in":"axbVd","../internals/is-callable":"4eoFc","../internals/object-is-prototype-of":"h0BNG","../internals/use-symbol-as-uid":"4Szng"}],"axbVd":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var isCallable = require("../internals/is-callable");
var aFunction = function(argument) {
    return isCallable(argument) ? argument : undefined;
};
module.exports = function(namespace, method) {
    return arguments.length < 2 ? aFunction(globalThis[namespace]) : globalThis[namespace] && globalThis[namespace][method];
};

},{"../internals/global-this":"7pHu3","../internals/is-callable":"4eoFc"}],"h0BNG":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
module.exports = uncurryThis({}.isPrototypeOf);

},{"../internals/function-uncurry-this":"ciO8u"}],"hYo0A":[function(require,module,exports) {
"use strict";
var aCallable = require("../internals/a-callable");
var isNullOrUndefined = require("../internals/is-null-or-undefined");
// `GetMethod` abstract operation
// https://tc39.es/ecma262/#sec-getmethod
module.exports = function(V, P) {
    var func = V[P];
    return isNullOrUndefined(func) ? undefined : aCallable(func);
};

},{"../internals/a-callable":"gaASH","../internals/is-null-or-undefined":"6AGhF"}],"gaASH":[function(require,module,exports) {
"use strict";
var isCallable = require("../internals/is-callable");
var tryToString = require("../internals/try-to-string");
var $TypeError = TypeError;
// `Assert: IsCallable(argument) is true`
module.exports = function(argument) {
    if (isCallable(argument)) return argument;
    throw new $TypeError(tryToString(argument) + " is not a function");
};

},{"../internals/is-callable":"4eoFc","../internals/try-to-string":"hCkh0"}],"a9hsA":[function(require,module,exports) {
"use strict";
var call = require("../internals/function-call");
var isCallable = require("../internals/is-callable");
var isObject = require("../internals/is-object");
var $TypeError = TypeError;
// `OrdinaryToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-ordinarytoprimitive
module.exports = function(input, pref) {
    var fn, val;
    if (pref === "string" && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
    if (isCallable(fn = input.valueOf) && !isObject(val = call(fn, input))) return val;
    if (pref !== "string" && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
    throw new $TypeError("Can't convert object to primitive value");
};

},{"../internals/function-call":"LSGTG","../internals/is-callable":"4eoFc","../internals/is-object":"56u2g"}],"dIkwH":[function(require,module,exports) {
"use strict";
module.exports = function(bitmap, value) {
    return {
        enumerable: !(bitmap & 1),
        configurable: !(bitmap & 2),
        writable: !(bitmap & 4),
        value: value
    };
};

},{}],"96dlH":[function(require,module,exports) {
"use strict";
var isCallable = require("../internals/is-callable");
var definePropertyModule = require("../internals/object-define-property");
var makeBuiltIn = require("../internals/make-built-in");
var defineGlobalProperty = require("../internals/define-global-property");
module.exports = function(O, key, value, options) {
    if (!options) options = {};
    var simple = options.enumerable;
    var name = options.name !== undefined ? options.name : key;
    if (isCallable(value)) makeBuiltIn(value, name, options);
    if (options.global) {
        if (simple) O[key] = value;
        else defineGlobalProperty(key, value);
    } else {
        try {
            if (!options.unsafe) delete O[key];
            else if (O[key]) simple = true;
        } catch (error) {}
        if (simple) O[key] = value;
        else definePropertyModule.f(O, key, {
            value: value,
            enumerable: false,
            configurable: !options.nonConfigurable,
            writable: !options.nonWritable
        });
    }
    return O;
};

},{"../internals/is-callable":"4eoFc","../internals/object-define-property":"eyQwQ","../internals/make-built-in":"5X396","../internals/define-global-property":"2bbQC"}],"5X396":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
var fails = require("../internals/fails");
var isCallable = require("../internals/is-callable");
var hasOwn = require("../internals/has-own-property");
var DESCRIPTORS = require("../internals/descriptors");
var CONFIGURABLE_FUNCTION_NAME = require("../internals/function-name").CONFIGURABLE;
var inspectSource = require("../internals/inspect-source");
var InternalStateModule = require("../internals/internal-state");
var enforceInternalState = InternalStateModule.enforce;
var getInternalState = InternalStateModule.get;
var $String = String;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
var stringSlice = uncurryThis("".slice);
var replace = uncurryThis("".replace);
var join = uncurryThis([].join);
var CONFIGURABLE_LENGTH = DESCRIPTORS && !fails(function() {
    return defineProperty(function() {}, "length", {
        value: 8
    }).length !== 8;
});
var TEMPLATE = String(String).split("String");
var makeBuiltIn = module.exports = function(value, name, options) {
    if (stringSlice($String(name), 0, 7) === "Symbol(") name = "[" + replace($String(name), /^Symbol\(([^)]*)\).*$/, "$1") + "]";
    if (options && options.getter) name = "get " + name;
    if (options && options.setter) name = "set " + name;
    if (!hasOwn(value, "name") || CONFIGURABLE_FUNCTION_NAME && value.name !== name) {
        if (DESCRIPTORS) defineProperty(value, "name", {
            value: name,
            configurable: true
        });
        else value.name = name;
    }
    if (CONFIGURABLE_LENGTH && options && hasOwn(options, "arity") && value.length !== options.arity) defineProperty(value, "length", {
        value: options.arity
    });
    try {
        if (options && hasOwn(options, "constructor") && options.constructor) {
            if (DESCRIPTORS) defineProperty(value, "prototype", {
                writable: false
            });
        } else if (value.prototype) value.prototype = undefined;
    } catch (error) {}
    var state = enforceInternalState(value);
    if (!hasOwn(state, "source")) state.source = join(TEMPLATE, typeof name == "string" ? name : "");
    return value;
};
// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
// eslint-disable-next-line no-extend-native -- required
Function.prototype.toString = makeBuiltIn(function toString() {
    return isCallable(this) && getInternalState(this).source || inspectSource(this);
}, "toString");

},{"../internals/function-uncurry-this":"ciO8u","../internals/fails":"enAJz","../internals/is-callable":"4eoFc","../internals/has-own-property":"k8LoH","../internals/descriptors":"5sGjX","../internals/function-name":"9FRBi","../internals/inspect-source":"1Ofur","../internals/internal-state":"k6xzl"}],"9FRBi":[function(require,module,exports) {
"use strict";
var DESCRIPTORS = require("../internals/descriptors");
var hasOwn = require("../internals/has-own-property");
var FunctionPrototype = Function.prototype;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getDescriptor = DESCRIPTORS && Object.getOwnPropertyDescriptor;
var EXISTS = hasOwn(FunctionPrototype, "name");
// additional protection from minified / mangled / dropped function names
var PROPER = EXISTS && (function something() {}).name === "something";
var CONFIGURABLE = EXISTS && (!DESCRIPTORS || DESCRIPTORS && getDescriptor(FunctionPrototype, "name").configurable);
module.exports = {
    EXISTS: EXISTS,
    PROPER: PROPER,
    CONFIGURABLE: CONFIGURABLE
};

},{"../internals/descriptors":"5sGjX","../internals/has-own-property":"k8LoH"}],"1Ofur":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
var isCallable = require("../internals/is-callable");
var store = require("../internals/shared-store");
var functionToString = uncurryThis(Function.toString);
// this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
if (!isCallable(store.inspectSource)) store.inspectSource = function(it) {
    return functionToString(it);
};
module.exports = store.inspectSource;

},{"../internals/function-uncurry-this":"ciO8u","../internals/is-callable":"4eoFc","../internals/shared-store":"1jrjr"}],"k6xzl":[function(require,module,exports) {
"use strict";
var NATIVE_WEAK_MAP = require("../internals/weak-map-basic-detection");
var globalThis = require("../internals/global-this");
var isObject = require("../internals/is-object");
var createNonEnumerableProperty = require("../internals/create-non-enumerable-property");
var hasOwn = require("../internals/has-own-property");
var shared = require("../internals/shared-store");
var sharedKey = require("../internals/shared-key");
var hiddenKeys = require("../internals/hidden-keys");
var OBJECT_ALREADY_INITIALIZED = "Object already initialized";
var TypeError = globalThis.TypeError;
var WeakMap = globalThis.WeakMap;
var set, get, has;
var enforce = function(it) {
    return has(it) ? get(it) : set(it, {});
};
var getterFor = function(TYPE) {
    return function(it) {
        var state;
        if (!isObject(it) || (state = get(it)).type !== TYPE) throw new TypeError("Incompatible receiver, " + TYPE + " required");
        return state;
    };
};
if (NATIVE_WEAK_MAP || shared.state) {
    var store = shared.state || (shared.state = new WeakMap());
    /* eslint-disable no-self-assign -- prototype methods protection */ store.get = store.get;
    store.has = store.has;
    store.set = store.set;
    /* eslint-enable no-self-assign -- prototype methods protection */ set = function(it, metadata) {
        if (store.has(it)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
        metadata.facade = it;
        store.set(it, metadata);
        return metadata;
    };
    get = function(it) {
        return store.get(it) || {};
    };
    has = function(it) {
        return store.has(it);
    };
} else {
    var STATE = sharedKey("state");
    hiddenKeys[STATE] = true;
    set = function(it, metadata) {
        if (hasOwn(it, STATE)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
        metadata.facade = it;
        createNonEnumerableProperty(it, STATE, metadata);
        return metadata;
    };
    get = function(it) {
        return hasOwn(it, STATE) ? it[STATE] : {};
    };
    has = function(it) {
        return hasOwn(it, STATE);
    };
}
module.exports = {
    set: set,
    get: get,
    has: has,
    enforce: enforce,
    getterFor: getterFor
};

},{"../internals/weak-map-basic-detection":"jmYk2","../internals/global-this":"7pHu3","../internals/is-object":"56u2g","../internals/create-non-enumerable-property":"jcucH","../internals/has-own-property":"k8LoH","../internals/shared-store":"1jrjr","../internals/shared-key":"4xKZ7","../internals/hidden-keys":"1OYX9"}],"jmYk2":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var isCallable = require("../internals/is-callable");
var WeakMap = globalThis.WeakMap;
module.exports = isCallable(WeakMap) && /native code/.test(String(WeakMap));

},{"../internals/global-this":"7pHu3","../internals/is-callable":"4eoFc"}],"4xKZ7":[function(require,module,exports) {
"use strict";
var shared = require("../internals/shared");
var uid = require("../internals/uid");
var keys = shared("keys");
module.exports = function(key) {
    return keys[key] || (keys[key] = uid(key));
};

},{"../internals/shared":"eJJkk","../internals/uid":"7S6zE"}],"1OYX9":[function(require,module,exports) {
"use strict";
module.exports = {};

},{}],"6atWd":[function(require,module,exports) {
"use strict";
var makeBuiltIn = require("../internals/make-built-in");
var defineProperty = require("../internals/object-define-property");
module.exports = function(target, name, descriptor) {
    if (descriptor.get) makeBuiltIn(descriptor.get, name, {
        getter: true
    });
    if (descriptor.set) makeBuiltIn(descriptor.set, name, {
        setter: true
    });
    return defineProperty.f(target, name, descriptor);
};

},{"../internals/make-built-in":"5X396","../internals/object-define-property":"eyQwQ"}],"kG1y9":[function(require,module,exports) {
"use strict";
var hasOwn = require("../internals/has-own-property");
var isCallable = require("../internals/is-callable");
var toObject = require("../internals/to-object");
var sharedKey = require("../internals/shared-key");
var CORRECT_PROTOTYPE_GETTER = require("../internals/correct-prototype-getter");
var IE_PROTO = sharedKey("IE_PROTO");
var $Object = Object;
var ObjectPrototype = $Object.prototype;
// `Object.getPrototypeOf` method
// https://tc39.es/ecma262/#sec-object.getprototypeof
// eslint-disable-next-line es/no-object-getprototypeof -- safe
module.exports = CORRECT_PROTOTYPE_GETTER ? $Object.getPrototypeOf : function(O) {
    var object = toObject(O);
    if (hasOwn(object, IE_PROTO)) return object[IE_PROTO];
    var constructor = object.constructor;
    if (isCallable(constructor) && object instanceof constructor) return constructor.prototype;
    return object instanceof $Object ? ObjectPrototype : null;
};

},{"../internals/has-own-property":"k8LoH","../internals/is-callable":"4eoFc","../internals/to-object":"bs0Bh","../internals/shared-key":"4xKZ7","../internals/correct-prototype-getter":"f75ZX"}],"f75ZX":[function(require,module,exports) {
"use strict";
var fails = require("../internals/fails");
module.exports = !fails(function() {
    function F() {}
    F.prototype.constructor = null;
    // eslint-disable-next-line es/no-object-getprototypeof -- required for testing
    return Object.getPrototypeOf(new F()) !== F.prototype;
});

},{"../internals/fails":"enAJz"}],"3pXN4":[function(require,module,exports) {
"use strict";
/* eslint-disable no-proto -- safe */ var uncurryThisAccessor = require("../internals/function-uncurry-this-accessor");
var isObject = require("../internals/is-object");
var requireObjectCoercible = require("../internals/require-object-coercible");
var aPossiblePrototype = require("../internals/a-possible-prototype");
// `Object.setPrototypeOf` method
// https://tc39.es/ecma262/#sec-object.setprototypeof
// Works with __proto__ only. Old v8 can't work with null proto objects.
// eslint-disable-next-line es/no-object-setprototypeof -- safe
module.exports = Object.setPrototypeOf || ("__proto__" in {} ? function() {
    var CORRECT_SETTER = false;
    var test = {};
    var setter;
    try {
        setter = uncurryThisAccessor(Object.prototype, "__proto__", "set");
        setter(test, []);
        CORRECT_SETTER = test instanceof Array;
    } catch (error) {}
    return function setPrototypeOf(O, proto) {
        requireObjectCoercible(O);
        aPossiblePrototype(proto);
        if (!isObject(O)) return O;
        if (CORRECT_SETTER) setter(O, proto);
        else O.__proto__ = proto;
        return O;
    };
}() : undefined);

},{"../internals/function-uncurry-this-accessor":"fAFkv","../internals/is-object":"56u2g","../internals/require-object-coercible":"fHjbZ","../internals/a-possible-prototype":"1QYXr"}],"fAFkv":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
var aCallable = require("../internals/a-callable");
module.exports = function(object, key, method) {
    try {
        // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
        return uncurryThis(aCallable(Object.getOwnPropertyDescriptor(object, key)[method]));
    } catch (error) {}
};

},{"../internals/function-uncurry-this":"ciO8u","../internals/a-callable":"gaASH"}],"1QYXr":[function(require,module,exports) {
"use strict";
var isPossiblePrototype = require("../internals/is-possible-prototype");
var $String = String;
var $TypeError = TypeError;
module.exports = function(argument) {
    if (isPossiblePrototype(argument)) return argument;
    throw new $TypeError("Can't set " + $String(argument) + " as a prototype");
};

},{"../internals/is-possible-prototype":"25808"}],"25808":[function(require,module,exports) {
"use strict";
var isObject = require("../internals/is-object");
module.exports = function(argument) {
    return isObject(argument) || argument === null;
};

},{"../internals/is-object":"56u2g"}],"1Li6S":[function(require,module,exports) {
"use strict";
var toLength = require("../internals/to-length");
// `LengthOfArrayLike` abstract operation
// https://tc39.es/ecma262/#sec-lengthofarraylike
module.exports = function(obj) {
    return toLength(obj.length);
};

},{"../internals/to-length":"7Lhdo"}],"7Lhdo":[function(require,module,exports) {
"use strict";
var toIntegerOrInfinity = require("../internals/to-integer-or-infinity");
var min = Math.min;
// `ToLength` abstract operation
// https://tc39.es/ecma262/#sec-tolength
module.exports = function(argument) {
    var len = toIntegerOrInfinity(argument);
    return len > 0 ? min(len, 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
};

},{"../internals/to-integer-or-infinity":"hArp4"}],"hArp4":[function(require,module,exports) {
"use strict";
var trunc = require("../internals/math-trunc");
// `ToIntegerOrInfinity` abstract operation
// https://tc39.es/ecma262/#sec-tointegerorinfinity
module.exports = function(argument) {
    var number = +argument;
    // eslint-disable-next-line no-self-compare -- NaN check
    return number !== number || number === 0 ? 0 : trunc(number);
};

},{"../internals/math-trunc":"gnq6v"}],"gnq6v":[function(require,module,exports) {
"use strict";
var ceil = Math.ceil;
var floor = Math.floor;
// `Math.trunc` method
// https://tc39.es/ecma262/#sec-math.trunc
// eslint-disable-next-line es/no-math-trunc -- safe
module.exports = Math.trunc || function trunc(x) {
    var n = +x;
    return (n > 0 ? floor : ceil)(n);
};

},{}],"8fkuK":[function(require,module,exports) {
"use strict";
var toPositiveInteger = require("../internals/to-positive-integer");
var $RangeError = RangeError;
module.exports = function(it, BYTES) {
    var offset = toPositiveInteger(it);
    if (offset % BYTES) throw new $RangeError("Wrong offset");
    return offset;
};

},{"../internals/to-positive-integer":"faIFU"}],"faIFU":[function(require,module,exports) {
"use strict";
var toIntegerOrInfinity = require("../internals/to-integer-or-infinity");
var $RangeError = RangeError;
module.exports = function(it) {
    var result = toIntegerOrInfinity(it);
    if (result < 0) throw new $RangeError("The argument can't be less than 0");
    return result;
};

},{"../internals/to-integer-or-infinity":"hArp4"}],"Mtge7":[function(require,module,exports) {
"use strict";
// TODO: Remove this module from `core-js@4` since it's split to modules listed below
require("../modules/web.clear-immediate");
require("../modules/web.set-immediate");

},{"../modules/web.clear-immediate":"03JS4","../modules/web.set-immediate":"giiEt"}],"03JS4":[function(require,module,exports) {
"use strict";
var $ = require("../internals/export");
var globalThis = require("../internals/global-this");
var clearImmediate = require("../internals/task").clear;
// `clearImmediate` method
// http://w3c.github.io/setImmediate/#si-clearImmediate
$({
    global: true,
    bind: true,
    enumerable: true,
    forced: globalThis.clearImmediate !== clearImmediate
}, {
    clearImmediate: clearImmediate
});

},{"../internals/export":"8FKnZ","../internals/global-this":"7pHu3","../internals/task":"1gSoS"}],"8FKnZ":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var getOwnPropertyDescriptor = require("../internals/object-get-own-property-descriptor").f;
var createNonEnumerableProperty = require("../internals/create-non-enumerable-property");
var defineBuiltIn = require("../internals/define-built-in");
var defineGlobalProperty = require("../internals/define-global-property");
var copyConstructorProperties = require("../internals/copy-constructor-properties");
var isForced = require("../internals/is-forced");
/*
  options.target         - name of the target object
  options.global         - target is the global object
  options.stat           - export as static methods of target
  options.proto          - export as prototype methods of target
  options.real           - real prototype method for the `pure` version
  options.forced         - export even if the native feature is available
  options.bind           - bind methods to the target, required for the `pure` version
  options.wrap           - wrap constructors to preventing global pollution, required for the `pure` version
  options.unsafe         - use the simple assignment of property instead of delete + defineProperty
  options.sham           - add a flag to not completely full polyfills
  options.enumerable     - export as enumerable property
  options.dontCallGetSet - prevent calling a getter on target
  options.name           - the .name of the function if it does not match the key
*/ module.exports = function(options, source) {
    var TARGET = options.target;
    var GLOBAL = options.global;
    var STATIC = options.stat;
    var FORCED, target, key, targetProperty, sourceProperty, descriptor;
    if (GLOBAL) target = globalThis;
    else if (STATIC) target = globalThis[TARGET] || defineGlobalProperty(TARGET, {});
    else target = globalThis[TARGET] && globalThis[TARGET].prototype;
    if (target) for(key in source){
        sourceProperty = source[key];
        if (options.dontCallGetSet) {
            descriptor = getOwnPropertyDescriptor(target, key);
            targetProperty = descriptor && descriptor.value;
        } else targetProperty = target[key];
        FORCED = isForced(GLOBAL ? key : TARGET + (STATIC ? "." : "#") + key, options.forced);
        // contained in target
        if (!FORCED && targetProperty !== undefined) {
            if (typeof sourceProperty == typeof targetProperty) continue;
            copyConstructorProperties(sourceProperty, targetProperty);
        }
        // add a flag to not completely full polyfills
        if (options.sham || targetProperty && targetProperty.sham) createNonEnumerableProperty(sourceProperty, "sham", true);
        defineBuiltIn(target, key, sourceProperty, options);
    }
};

},{"../internals/global-this":"7pHu3","../internals/object-get-own-property-descriptor":"dU0rL","../internals/create-non-enumerable-property":"jcucH","../internals/define-built-in":"96dlH","../internals/define-global-property":"2bbQC","../internals/copy-constructor-properties":"i9ctH","../internals/is-forced":"cu0NF"}],"dU0rL":[function(require,module,exports) {
"use strict";
var DESCRIPTORS = require("../internals/descriptors");
var call = require("../internals/function-call");
var propertyIsEnumerableModule = require("../internals/object-property-is-enumerable");
var createPropertyDescriptor = require("../internals/create-property-descriptor");
var toIndexedObject = require("../internals/to-indexed-object");
var toPropertyKey = require("../internals/to-property-key");
var hasOwn = require("../internals/has-own-property");
var IE8_DOM_DEFINE = require("../internals/ie8-dom-define");
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
// `Object.getOwnPropertyDescriptor` method
// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
exports.f = DESCRIPTORS ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
    O = toIndexedObject(O);
    P = toPropertyKey(P);
    if (IE8_DOM_DEFINE) try {
        return $getOwnPropertyDescriptor(O, P);
    } catch (error) {}
    if (hasOwn(O, P)) return createPropertyDescriptor(!call(propertyIsEnumerableModule.f, O, P), O[P]);
};

},{"../internals/descriptors":"5sGjX","../internals/function-call":"LSGTG","../internals/object-property-is-enumerable":"68SMy","../internals/create-property-descriptor":"dIkwH","../internals/to-indexed-object":"cs6cO","../internals/to-property-key":"cpMtP","../internals/has-own-property":"k8LoH","../internals/ie8-dom-define":"bVSCL"}],"68SMy":[function(require,module,exports) {
"use strict";
var $propertyIsEnumerable = {}.propertyIsEnumerable;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
// Nashorn ~ JDK8 bug
var NASHORN_BUG = getOwnPropertyDescriptor && !$propertyIsEnumerable.call({
    1: 2
}, 1);
// `Object.prototype.propertyIsEnumerable` method implementation
// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
exports.f = NASHORN_BUG ? function propertyIsEnumerable(V) {
    var descriptor = getOwnPropertyDescriptor(this, V);
    return !!descriptor && descriptor.enumerable;
} : $propertyIsEnumerable;

},{}],"cs6cO":[function(require,module,exports) {
"use strict";
// toObject with fallback for non-array-like ES3 strings
var IndexedObject = require("../internals/indexed-object");
var requireObjectCoercible = require("../internals/require-object-coercible");
module.exports = function(it) {
    return IndexedObject(requireObjectCoercible(it));
};

},{"../internals/indexed-object":"i27KA","../internals/require-object-coercible":"fHjbZ"}],"i27KA":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
var fails = require("../internals/fails");
var classof = require("../internals/classof-raw");
var $Object = Object;
var split = uncurryThis("".split);
// fallback for non-array-like ES3 and non-enumerable old V8 strings
module.exports = fails(function() {
    // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
    // eslint-disable-next-line no-prototype-builtins -- safe
    return !$Object("z").propertyIsEnumerable(0);
}) ? function(it) {
    return classof(it) === "String" ? split(it, "") : $Object(it);
} : $Object;

},{"../internals/function-uncurry-this":"ciO8u","../internals/fails":"enAJz","../internals/classof-raw":"kxgZU"}],"i9ctH":[function(require,module,exports) {
"use strict";
var hasOwn = require("../internals/has-own-property");
var ownKeys = require("../internals/own-keys");
var getOwnPropertyDescriptorModule = require("../internals/object-get-own-property-descriptor");
var definePropertyModule = require("../internals/object-define-property");
module.exports = function(target, source, exceptions) {
    var keys = ownKeys(source);
    var defineProperty = definePropertyModule.f;
    var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
    for(var i = 0; i < keys.length; i++){
        var key = keys[i];
        if (!hasOwn(target, key) && !(exceptions && hasOwn(exceptions, key))) defineProperty(target, key, getOwnPropertyDescriptor(source, key));
    }
};

},{"../internals/has-own-property":"k8LoH","../internals/own-keys":"5lPgp","../internals/object-get-own-property-descriptor":"dU0rL","../internals/object-define-property":"eyQwQ"}],"5lPgp":[function(require,module,exports) {
"use strict";
var getBuiltIn = require("../internals/get-built-in");
var uncurryThis = require("../internals/function-uncurry-this");
var getOwnPropertyNamesModule = require("../internals/object-get-own-property-names");
var getOwnPropertySymbolsModule = require("../internals/object-get-own-property-symbols");
var anObject = require("../internals/an-object");
var concat = uncurryThis([].concat);
// all object keys, includes non-enumerable and symbols
module.exports = getBuiltIn("Reflect", "ownKeys") || function ownKeys(it) {
    var keys = getOwnPropertyNamesModule.f(anObject(it));
    var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
    return getOwnPropertySymbols ? concat(keys, getOwnPropertySymbols(it)) : keys;
};

},{"../internals/get-built-in":"axbVd","../internals/function-uncurry-this":"ciO8u","../internals/object-get-own-property-names":"g6vsK","../internals/object-get-own-property-symbols":"lF81h","../internals/an-object":"hp0ZV"}],"g6vsK":[function(require,module,exports) {
"use strict";
var internalObjectKeys = require("../internals/object-keys-internal");
var enumBugKeys = require("../internals/enum-bug-keys");
var hiddenKeys = enumBugKeys.concat("length", "prototype");
// `Object.getOwnPropertyNames` method
// https://tc39.es/ecma262/#sec-object.getownpropertynames
// eslint-disable-next-line es/no-object-getownpropertynames -- safe
exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
    return internalObjectKeys(O, hiddenKeys);
};

},{"../internals/object-keys-internal":"bxvUG","../internals/enum-bug-keys":"b9Sbq"}],"bxvUG":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
var hasOwn = require("../internals/has-own-property");
var toIndexedObject = require("../internals/to-indexed-object");
var indexOf = require("../internals/array-includes").indexOf;
var hiddenKeys = require("../internals/hidden-keys");
var push = uncurryThis([].push);
module.exports = function(object, names) {
    var O = toIndexedObject(object);
    var i = 0;
    var result = [];
    var key;
    for(key in O)!hasOwn(hiddenKeys, key) && hasOwn(O, key) && push(result, key);
    // Don't enum bug & hidden keys
    while(names.length > i)if (hasOwn(O, key = names[i++])) ~indexOf(result, key) || push(result, key);
    return result;
};

},{"../internals/function-uncurry-this":"ciO8u","../internals/has-own-property":"k8LoH","../internals/to-indexed-object":"cs6cO","../internals/array-includes":"eL9Pq","../internals/hidden-keys":"1OYX9"}],"eL9Pq":[function(require,module,exports) {
"use strict";
var toIndexedObject = require("../internals/to-indexed-object");
var toAbsoluteIndex = require("../internals/to-absolute-index");
var lengthOfArrayLike = require("../internals/length-of-array-like");
// `Array.prototype.{ indexOf, includes }` methods implementation
var createMethod = function(IS_INCLUDES) {
    return function($this, el, fromIndex) {
        var O = toIndexedObject($this);
        var length = lengthOfArrayLike(O);
        if (length === 0) return !IS_INCLUDES && -1;
        var index = toAbsoluteIndex(fromIndex, length);
        var value;
        // Array#includes uses SameValueZero equality algorithm
        // eslint-disable-next-line no-self-compare -- NaN check
        if (IS_INCLUDES && el !== el) while(length > index){
            value = O[index++];
            // eslint-disable-next-line no-self-compare -- NaN check
            if (value !== value) return true;
        // Array#indexOf ignores holes, Array#includes - not
        }
        else for(; length > index; index++){
            if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
        }
        return !IS_INCLUDES && -1;
    };
};
module.exports = {
    // `Array.prototype.includes` method
    // https://tc39.es/ecma262/#sec-array.prototype.includes
    includes: createMethod(true),
    // `Array.prototype.indexOf` method
    // https://tc39.es/ecma262/#sec-array.prototype.indexof
    indexOf: createMethod(false)
};

},{"../internals/to-indexed-object":"cs6cO","../internals/to-absolute-index":"f8l7Q","../internals/length-of-array-like":"1Li6S"}],"f8l7Q":[function(require,module,exports) {
"use strict";
var toIntegerOrInfinity = require("../internals/to-integer-or-infinity");
var max = Math.max;
var min = Math.min;
// Helper for a popular repeating case of the spec:
// Let integer be ? ToInteger(index).
// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
module.exports = function(index, length) {
    var integer = toIntegerOrInfinity(index);
    return integer < 0 ? max(integer + length, 0) : min(integer, length);
};

},{"../internals/to-integer-or-infinity":"hArp4"}],"b9Sbq":[function(require,module,exports) {
"use strict";
// IE8- don't enum bug keys
module.exports = [
    "constructor",
    "hasOwnProperty",
    "isPrototypeOf",
    "propertyIsEnumerable",
    "toLocaleString",
    "toString",
    "valueOf"
];

},{}],"lF81h":[function(require,module,exports) {
"use strict";
// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
exports.f = Object.getOwnPropertySymbols;

},{}],"cu0NF":[function(require,module,exports) {
"use strict";
var fails = require("../internals/fails");
var isCallable = require("../internals/is-callable");
var replacement = /#|\.prototype\./;
var isForced = function(feature, detection) {
    var value = data[normalize(feature)];
    return value === POLYFILL ? true : value === NATIVE ? false : isCallable(detection) ? fails(detection) : !!detection;
};
var normalize = isForced.normalize = function(string) {
    return String(string).replace(replacement, ".").toLowerCase();
};
var data = isForced.data = {};
var NATIVE = isForced.NATIVE = "N";
var POLYFILL = isForced.POLYFILL = "P";
module.exports = isForced;

},{"../internals/fails":"enAJz","../internals/is-callable":"4eoFc"}],"1gSoS":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var apply = require("../internals/function-apply");
var bind = require("../internals/function-bind-context");
var isCallable = require("../internals/is-callable");
var hasOwn = require("../internals/has-own-property");
var fails = require("../internals/fails");
var html = require("../internals/html");
var arraySlice = require("../internals/array-slice");
var createElement = require("../internals/document-create-element");
var validateArgumentsLength = require("../internals/validate-arguments-length");
var IS_IOS = require("../internals/environment-is-ios");
var IS_NODE = require("../internals/environment-is-node");
var set = globalThis.setImmediate;
var clear = globalThis.clearImmediate;
var process = globalThis.process;
var Dispatch = globalThis.Dispatch;
var Function = globalThis.Function;
var MessageChannel = globalThis.MessageChannel;
var String = globalThis.String;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = "onreadystatechange";
var $location, defer, channel, port;
fails(function() {
    // Deno throws a ReferenceError on `location` access without `--location` flag
    $location = globalThis.location;
});
var run = function(id) {
    if (hasOwn(queue, id)) {
        var fn = queue[id];
        delete queue[id];
        fn();
    }
};
var runner = function(id) {
    return function() {
        run(id);
    };
};
var eventListener = function(event) {
    run(event.data);
};
var globalPostMessageDefer = function(id) {
    // old engines have not location.origin
    globalThis.postMessage(String(id), $location.protocol + "//" + $location.host);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!set || !clear) {
    set = function setImmediate(handler) {
        validateArgumentsLength(arguments.length, 1);
        var fn = isCallable(handler) ? handler : Function(handler);
        var args = arraySlice(arguments, 1);
        queue[++counter] = function() {
            apply(fn, undefined, args);
        };
        defer(counter);
        return counter;
    };
    clear = function clearImmediate(id) {
        delete queue[id];
    };
    // Node.js 0.8-
    if (IS_NODE) defer = function(id) {
        process.nextTick(runner(id));
    };
    else if (Dispatch && Dispatch.now) defer = function(id) {
        Dispatch.now(runner(id));
    };
    else if (MessageChannel && !IS_IOS) {
        channel = new MessageChannel();
        port = channel.port2;
        channel.port1.onmessage = eventListener;
        defer = bind(port.postMessage, port);
    // Browsers with postMessage, skip WebWorkers
    // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
    } else if (globalThis.addEventListener && isCallable(globalThis.postMessage) && !globalThis.importScripts && $location && $location.protocol !== "file:" && !fails(globalPostMessageDefer)) {
        defer = globalPostMessageDefer;
        globalThis.addEventListener("message", eventListener, false);
    // IE8-
    } else if (ONREADYSTATECHANGE in createElement("script")) defer = function(id) {
        html.appendChild(createElement("script"))[ONREADYSTATECHANGE] = function() {
            html.removeChild(this);
            run(id);
        };
    };
    else defer = function(id) {
        setTimeout(runner(id), 0);
    };
}
module.exports = {
    set: set,
    clear: clear
};

},{"../internals/global-this":"7pHu3","../internals/function-apply":"7e39x","../internals/function-bind-context":"27PK3","../internals/is-callable":"4eoFc","../internals/has-own-property":"k8LoH","../internals/fails":"enAJz","../internals/html":"d8fTq","../internals/array-slice":"jk1uA","../internals/document-create-element":"fyV4i","../internals/validate-arguments-length":"7FPWA","../internals/environment-is-ios":"1mXN9","../internals/environment-is-node":"jst0c"}],"7e39x":[function(require,module,exports) {
"use strict";
var NATIVE_BIND = require("../internals/function-bind-native");
var FunctionPrototype = Function.prototype;
var apply = FunctionPrototype.apply;
var call = FunctionPrototype.call;
// eslint-disable-next-line es/no-reflect -- safe
module.exports = typeof Reflect == "object" && Reflect.apply || (NATIVE_BIND ? call.bind(apply) : function() {
    return call.apply(apply, arguments);
});

},{"../internals/function-bind-native":"1KPaH"}],"27PK3":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this-clause");
var aCallable = require("../internals/a-callable");
var NATIVE_BIND = require("../internals/function-bind-native");
var bind = uncurryThis(uncurryThis.bind);
// optional / simple context binding
module.exports = function(fn, that) {
    aCallable(fn);
    return that === undefined ? fn : NATIVE_BIND ? bind(fn, that) : function() {
        return fn.apply(that, arguments);
    };
};

},{"../internals/function-uncurry-this-clause":"69Scw","../internals/a-callable":"gaASH","../internals/function-bind-native":"1KPaH"}],"69Scw":[function(require,module,exports) {
"use strict";
var classofRaw = require("../internals/classof-raw");
var uncurryThis = require("../internals/function-uncurry-this");
module.exports = function(fn) {
    // Nashorn bug:
    //   https://github.com/zloirock/core-js/issues/1128
    //   https://github.com/zloirock/core-js/issues/1130
    if (classofRaw(fn) === "Function") return uncurryThis(fn);
};

},{"../internals/classof-raw":"kxgZU","../internals/function-uncurry-this":"ciO8u"}],"d8fTq":[function(require,module,exports) {
"use strict";
var getBuiltIn = require("../internals/get-built-in");
module.exports = getBuiltIn("document", "documentElement");

},{"../internals/get-built-in":"axbVd"}],"jk1uA":[function(require,module,exports) {
"use strict";
var uncurryThis = require("../internals/function-uncurry-this");
module.exports = uncurryThis([].slice);

},{"../internals/function-uncurry-this":"ciO8u"}],"7FPWA":[function(require,module,exports) {
"use strict";
var $TypeError = TypeError;
module.exports = function(passed, required) {
    if (passed < required) throw new $TypeError("Not enough arguments");
    return passed;
};

},{}],"1mXN9":[function(require,module,exports) {
"use strict";
var userAgent = require("../internals/environment-user-agent");
// eslint-disable-next-line redos/no-vulnerable -- safe
module.exports = /(?:ipad|iphone|ipod).*applewebkit/i.test(userAgent);

},{"../internals/environment-user-agent":"aZ8AQ"}],"jst0c":[function(require,module,exports) {
"use strict";
var ENVIRONMENT = require("../internals/environment");
module.exports = ENVIRONMENT === "NODE";

},{"../internals/environment":"chAMe"}],"chAMe":[function(require,module,exports) {
"use strict";
/* global Bun, Deno -- detection */ var globalThis = require("../internals/global-this");
var userAgent = require("../internals/environment-user-agent");
var classof = require("../internals/classof-raw");
var userAgentStartsWith = function(string) {
    return userAgent.slice(0, string.length) === string;
};
module.exports = function() {
    if (userAgentStartsWith("Bun/")) return "BUN";
    if (userAgentStartsWith("Cloudflare-Workers")) return "CLOUDFLARE";
    if (userAgentStartsWith("Deno/")) return "DENO";
    if (userAgentStartsWith("Node.js/")) return "NODE";
    if (globalThis.Bun && typeof Bun.version == "string") return "BUN";
    if (globalThis.Deno && typeof Deno.version == "object") return "DENO";
    if (classof(globalThis.process) === "process") return "NODE";
    if (globalThis.window && globalThis.document) return "BROWSER";
    return "REST";
}();

},{"../internals/global-this":"7pHu3","../internals/environment-user-agent":"aZ8AQ","../internals/classof-raw":"kxgZU"}],"giiEt":[function(require,module,exports) {
"use strict";
var $ = require("../internals/export");
var globalThis = require("../internals/global-this");
var setTask = require("../internals/task").set;
var schedulersFix = require("../internals/schedulers-fix");
// https://github.com/oven-sh/bun/issues/1633
var setImmediate = globalThis.setImmediate ? schedulersFix(setTask, false) : setTask;
// `setImmediate` method
// http://w3c.github.io/setImmediate/#si-setImmediate
$({
    global: true,
    bind: true,
    enumerable: true,
    forced: globalThis.setImmediate !== setImmediate
}, {
    setImmediate: setImmediate
});

},{"../internals/export":"8FKnZ","../internals/global-this":"7pHu3","../internals/task":"1gSoS","../internals/schedulers-fix":"1lo08"}],"1lo08":[function(require,module,exports) {
"use strict";
var globalThis = require("../internals/global-this");
var apply = require("../internals/function-apply");
var isCallable = require("../internals/is-callable");
var ENVIRONMENT = require("../internals/environment");
var USER_AGENT = require("../internals/environment-user-agent");
var arraySlice = require("../internals/array-slice");
var validateArgumentsLength = require("../internals/validate-arguments-length");
var Function = globalThis.Function;
// dirty IE9- and Bun 0.3.0- checks
var WRAP = /MSIE .\./.test(USER_AGENT) || ENVIRONMENT === "BUN" && function() {
    var version = globalThis.Bun.version.split(".");
    return version.length < 3 || version[0] === "0" && (version[1] < 3 || version[1] === "3" && version[2] === "0");
}();
// IE9- / Bun 0.3.0- setTimeout / setInterval / setImmediate additional parameters fix
// https://html.spec.whatwg.org/multipage/timers-and-user-prompts.html#timers
// https://github.com/oven-sh/bun/issues/1633
module.exports = function(scheduler, hasTimeArg) {
    var firstParamIndex = hasTimeArg ? 2 : 1;
    return WRAP ? function(handler, timeout /* , ...arguments */ ) {
        var boundArgs = validateArgumentsLength(arguments.length, 1) > firstParamIndex;
        var fn = isCallable(handler) ? handler : Function(handler);
        var params = boundArgs ? arraySlice(arguments, firstParamIndex) : [];
        var callback = boundArgs ? function() {
            apply(fn, this, params);
        } : fn;
        return hasTimeArg ? scheduler(callback, timeout) : scheduler(callback);
    } : scheduler;
};

},{"../internals/global-this":"7pHu3","../internals/function-apply":"7e39x","../internals/is-callable":"4eoFc","../internals/environment":"chAMe","../internals/environment-user-agent":"aZ8AQ","../internals/array-slice":"jk1uA","../internals/validate-arguments-length":"7FPWA"}],"9mill":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "vuetifyInit", ()=>vuetifyInit);
parcelHelpers.export(exports, "vuetify", ()=>vuetify);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _vuetify = require("vuetify");
var _vuetifyDefault = parcelHelpers.interopDefault(_vuetify);
var _vuetifyCss = require("vuetify/dist/vuetify.css");
function vuetifyInit(vue) {
    vue.use((0, _vuetifyDefault.default));
}
const vuetify = new (0, _vuetifyDefault.default)({
    theme: {
        themes: {
            light: {
                primary: "#14202c",
                secondary: "#14202c",
                accent: "#14202c"
            }
        }
    }
});

},{"vuetify":"d1ZbB","vuetify/dist/vuetify.css":"5S5jS","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"5S5jS":[function() {},{}],"6uyOv":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "routerInit", ()=>routerInit);
parcelHelpers.export(exports, "router", ()=>router);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _auth = require("../middleware/auth");
var _vueRouter = require("vue-router");
var _vueRouterDefault = parcelHelpers.interopDefault(_vueRouter);
// import HomeView from '../views/HomeView.vue'
var _loginViewVue = require("../views/LoginView.vue");
var _loginViewVueDefault = parcelHelpers.interopDefault(_loginViewVue);
var _homeLayoutVue = require("../layout/HomeLayout.vue");
var _homeLayoutVueDefault = parcelHelpers.interopDefault(_homeLayoutVue);
function routerInit(vue) {
    vue.use((0, _vueRouterDefault.default));
}
const routes = [
    {
        path: "/",
        redirect: "/home",
        name: "_Home"
    },
    {
        path: "/login",
        name: "Login",
        component: (0, _loginViewVueDefault.default)
    },
    {
        path: "/app",
        name: "App",
        component: ()=>require("f1650c7cdad7f992")
    },
    {
        path: "/",
        component: (0, _homeLayoutVueDefault.default),
        children: [
            {
                path: "/home",
                name: "Home",
                component: ()=>require(/* webpackChunkName: "about" */ "efe2ad6c2f8f3e1b")
            }, 
        ]
    }, 
];
const router = new (0, _vueRouterDefault.default)({
    // mode: 'history',
    routes
});
router.beforeEach(async (to, from, next)=>{
    const auth = await (0, _auth.isAuthenticate)();
    if (window.parent) {
        window.parent.router = window.parent.router || {};
        window.parent.router.query = window.parent.router.query || {};
        window.parent.router.query.app = to.query.app;
    }
    if (to.name === "Login" && auth) return next({
        name: "Home"
    });
    if (!auth && to.name !== "Login") return next({
        name: "Login"
    });
    return next();
});
router.customPush = function(path, query) {
    this.push({
        path,
        query
    });
};
router.customReplace = function(path, query) {
    this.replace({
        path,
        query
    });
};
window.routerFontion = router;

},{"../middleware/auth":"dtGXu","vue-router":"5cH0k","../views/LoginView.vue":"9S4FX","../layout/HomeLayout.vue":"cYsi3","f1650c7cdad7f992":"3sgqx","efe2ad6c2f8f3e1b":"9DSez","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"dtGXu":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "isAuthenticate", ()=>isAuthenticate);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 * 
 * This file is part of SpinalCore.
 * 
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 * 
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 * 
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _userData = require("../requests/userData");
var _utils = require("../utils");
async function isAuthenticate() {
    const token = localStorage.getItem("token");
    if (token) {
        const { code , data  } = await (0, _userData.getTokenData)(token);
        if (code == 200) {
            (0, _utils.saveToLocalStorage)(data);
            return true;
        }
    }
    return false;
}

},{"../requests/userData":"dONA1","../utils":"4Y0g6","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"dONA1":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "addAppToFavorite", ()=>addAppToFavorite);
parcelHelpers.export(exports, "removeAppFromFavorite", ()=>removeAppFromFavorite);
parcelHelpers.export(exports, "getFavoriteApps", ()=>getFavoriteApps);
parcelHelpers.export(exports, "getPortofolios", ()=>getPortofolios);
parcelHelpers.export(exports, "getUserApps", ()=>getUserApps);
parcelHelpers.export(exports, "getUserBos", ()=>getUserBos);
parcelHelpers.export(exports, "getAppById", ()=>getAppById);
parcelHelpers.export(exports, "getTokenData", ()=>getTokenData);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 * 
 * This file is part of SpinalCore.
 * 
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 * 
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 * 
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _axios = require("axios");
var _axiosDefault = parcelHelpers.interopDefault(_axios);
var _ = require(".");
const endpoint = "/api/v1/pam";
const host = ((0, _.SERVER_BASE_URL) || "").replace(`/\/$/`, (el)=>"");
const baseURL = host.match(new RegExp(endpoint)) ? host : host + endpoint;
function addAppToFavorite(appIds, { portofolioId , buildingId  }) {
    console.warn(portofolioId, buildingId, " aaaaaaaaaaaaaaaaaaaaaaa");
    let endpoint = `${portofolioId}/${buildingId || ""}`;
    console.warn(endpoint, " aaaaaaaaaaaaaaaaaaaaaaa");
    return (0, _axiosDefault.default).post(`${baseURL}/add_app_to_favoris/${endpoint}`, {
        appIds
    }).then((result)=>{
        return result.data;
    }).catch((err)=>{
        return [];
    });
}
function removeAppFromFavorite(appIds, { portofolioId , buildingId  }) {
    let endpoint = `${portofolioId}/${buildingId || ""}`;
    return (0, _axiosDefault.default).post(`${baseURL}/remove_app_from_favoris/${endpoint}`, {
        appIds
    }).then((result)=>{
        return result.data;
    }).catch((err)=>{
        return [];
    });
}
function getFavoriteApps({ portofolioId , buildingId  }) {
    let endpoint = `${portofolioId}/${buildingId || ""}`;
    return (0, _axiosDefault.default).get(`${baseURL}/get_favorite_apps/${endpoint}`).then((result)=>{
        return result.data;
    }).catch((err)=>{
        return [];
    });
}
function getPortofolios(profileId) {
    if (!profileId) throw new Error("no profileId found");
    return (0, _axiosDefault.default).get(`${baseURL}/user_profile/get_authorized_portofolio/${profileId}`).then((result)=>{
        return result.data;
    });
}
function getUserApps(profileId) {
    if (!profileId) throw new Error("no profileId found");
    return (0, _axiosDefault.default).get(`${baseURL}/user_profile/get_authorized_apps/${profileId}`).then((result)=>{
        return result.data;
    });
}
function getUserBos(profileId) {
    if (!profileId) throw new Error("no profileId found");
    return (0, _axiosDefault.default).get(`${baseURL}/user_profile/get_authorized_bos/${profileId}`).then((result)=>{
        return result.data;
    });
}
function getAppById(appId) {
    return (0, _axiosDefault.default).get(`${baseURL}/get_app_by_id/${appId}`).then((result)=>{
        return result.data;
    });
}
function getTokenData(token) {
    return (0, _axiosDefault.default).post(`${baseURL}/getTokenData`, {
        token
    }).then((result)=>{
        return result.data;
    }).catch((err)=>{
        return {
            code: 401,
            message: "error"
        };
    });
}

},{"axios":"9qbW2",".":"8Ir1L","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"8Ir1L":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SERVER_BASE_URL", ()=>SERVER_BASE_URL);
parcelHelpers.export(exports, "initAxios", ()=>initAxios);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _axios = require("axios");
var _axiosDefault = parcelHelpers.interopDefault(_axios);
const SERVER_BASE_URL = "http://localhost:8065";
function initAxios() {
    // const host = "http://localhost:8065";
    // axios.create({ baseURL: `${serverHost}` });
    (0, _axiosDefault.default).interceptors.request.use((request)=>{
        const t = localStorage.getItem("token");
        // request.url = path.normalize(serverHost + "/" + request.url);
        if (t) request.headers.common.Authorization = `Bearer ${t}`;
        return request;
    });
}

},{"axios":"9qbW2","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"4Y0g6":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 * 
 * This file is part of SpinalCore.
 * 
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 * 
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 * 
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ parcelHelpers.export(exports, "saveToLocalStorage", ()=>saveToLocalStorage);
parcelHelpers.export(exports, "clearLocalStorage", ()=>clearLocalStorage);
function saveToLocalStorage(data) {
    const profileId = data.profile.userProfileBosConfigId || data.profile.profileId;
    const token = data.token;
    const user = btoa(JSON.stringify(data.userInfo));
    localStorage.setItem("profileId", profileId);
    localStorage.setItem("token", token);
    localStorage.setItem("user", user);
}
function clearLocalStorage() {
    localStorage.clear();
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"5cH0k":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "NavigationFailureType", ()=>NavigationFailureType);
parcelHelpers.export(exports, "RouterLink", ()=>Link);
parcelHelpers.export(exports, "RouterView", ()=>View);
parcelHelpers.export(exports, "START_LOCATION", ()=>START);
parcelHelpers.export(exports, "default", ()=>VueRouter$1);
parcelHelpers.export(exports, "isNavigationFailure", ()=>isNavigationFailure);
parcelHelpers.export(exports, "version", ()=>version);
/*!
  * vue-router v3.6.5
  * (c) 2022 Evan You
  * @license MIT
  */ /*  */ function assert(condition, message) {
    if (!condition) throw new Error("[vue-router] " + message);
}
function warn(condition, message) {
    if (!condition) typeof console !== "undefined" && console.warn("[vue-router] " + message);
}
function extend(a, b) {
    for(var key in b)a[key] = b[key];
    return a;
}
/*  */ var encodeReserveRE = /[!'()*]/g;
var encodeReserveReplacer = function(c) {
    return "%" + c.charCodeAt(0).toString(16);
};
var commaRE = /%2C/g;
// fixed encodeURIComponent which is more conformant to RFC3986:
// - escapes [!'()*]
// - preserve commas
var encode = function(str) {
    return encodeURIComponent(str).replace(encodeReserveRE, encodeReserveReplacer).replace(commaRE, ",");
};
function decode(str) {
    try {
        return decodeURIComponent(str);
    } catch (err) {}
    return str;
}
function resolveQuery(query, extraQuery, _parseQuery) {
    if (extraQuery === void 0) extraQuery = {};
    var parse = _parseQuery || parseQuery;
    var parsedQuery;
    try {
        parsedQuery = parse(query || "");
    } catch (e) {
        parsedQuery = {};
    }
    for(var key in extraQuery){
        var value = extraQuery[key];
        parsedQuery[key] = Array.isArray(value) ? value.map(castQueryParamValue) : castQueryParamValue(value);
    }
    return parsedQuery;
}
var castQueryParamValue = function(value) {
    return value == null || typeof value === "object" ? value : String(value);
};
function parseQuery(query) {
    var res = {};
    query = query.trim().replace(/^(\?|#|&)/, "");
    if (!query) return res;
    query.split("&").forEach(function(param) {
        var parts = param.replace(/\+/g, " ").split("=");
        var key = decode(parts.shift());
        var val = parts.length > 0 ? decode(parts.join("=")) : null;
        if (res[key] === undefined) res[key] = val;
        else if (Array.isArray(res[key])) res[key].push(val);
        else res[key] = [
            res[key],
            val
        ];
    });
    return res;
}
function stringifyQuery(obj) {
    var res = obj ? Object.keys(obj).map(function(key) {
        var val = obj[key];
        if (val === undefined) return "";
        if (val === null) return encode(key);
        if (Array.isArray(val)) {
            var result = [];
            val.forEach(function(val2) {
                if (val2 === undefined) return;
                if (val2 === null) result.push(encode(key));
                else result.push(encode(key) + "=" + encode(val2));
            });
            return result.join("&");
        }
        return encode(key) + "=" + encode(val);
    }).filter(function(x) {
        return x.length > 0;
    }).join("&") : null;
    return res ? "?" + res : "";
}
/*  */ var trailingSlashRE = /\/?$/;
function createRoute(record, location, redirectedFrom, router) {
    var stringifyQuery = router && router.options.stringifyQuery;
    var query = location.query || {};
    try {
        query = clone(query);
    } catch (e) {}
    var route = {
        name: location.name || record && record.name,
        meta: record && record.meta || {},
        path: location.path || "/",
        hash: location.hash || "",
        query: query,
        params: location.params || {},
        fullPath: getFullPath(location, stringifyQuery),
        matched: record ? formatMatch(record) : []
    };
    if (redirectedFrom) route.redirectedFrom = getFullPath(redirectedFrom, stringifyQuery);
    return Object.freeze(route);
}
function clone(value) {
    if (Array.isArray(value)) return value.map(clone);
    else if (value && typeof value === "object") {
        var res = {};
        for(var key in value)res[key] = clone(value[key]);
        return res;
    } else return value;
}
// the starting route that represents the initial state
var START = createRoute(null, {
    path: "/"
});
function formatMatch(record) {
    var res = [];
    while(record){
        res.unshift(record);
        record = record.parent;
    }
    return res;
}
function getFullPath(ref, _stringifyQuery) {
    var path = ref.path;
    var query = ref.query;
    if (query === void 0) query = {};
    var hash = ref.hash;
    if (hash === void 0) hash = "";
    var stringify = _stringifyQuery || stringifyQuery;
    return (path || "/") + stringify(query) + hash;
}
function isSameRoute(a, b, onlyPath) {
    if (b === START) return a === b;
    else if (!b) return false;
    else if (a.path && b.path) return a.path.replace(trailingSlashRE, "") === b.path.replace(trailingSlashRE, "") && (onlyPath || a.hash === b.hash && isObjectEqual(a.query, b.query));
    else if (a.name && b.name) return a.name === b.name && (onlyPath || a.hash === b.hash && isObjectEqual(a.query, b.query) && isObjectEqual(a.params, b.params));
    else return false;
}
function isObjectEqual(a, b) {
    if (a === void 0) a = {};
    if (b === void 0) b = {};
    // handle null value #1566
    if (!a || !b) return a === b;
    var aKeys = Object.keys(a).sort();
    var bKeys = Object.keys(b).sort();
    if (aKeys.length !== bKeys.length) return false;
    return aKeys.every(function(key, i) {
        var aVal = a[key];
        var bKey = bKeys[i];
        if (bKey !== key) return false;
        var bVal = b[key];
        // query values can be null and undefined
        if (aVal == null || bVal == null) return aVal === bVal;
        // check nested equality
        if (typeof aVal === "object" && typeof bVal === "object") return isObjectEqual(aVal, bVal);
        return String(aVal) === String(bVal);
    });
}
function isIncludedRoute(current, target) {
    return current.path.replace(trailingSlashRE, "/").indexOf(target.path.replace(trailingSlashRE, "/")) === 0 && (!target.hash || current.hash === target.hash) && queryIncludes(current.query, target.query);
}
function queryIncludes(current, target) {
    for(var key in target){
        if (!(key in current)) return false;
    }
    return true;
}
function handleRouteEntered(route) {
    for(var i = 0; i < route.matched.length; i++){
        var record = route.matched[i];
        for(var name in record.instances){
            var instance = record.instances[name];
            var cbs = record.enteredCbs[name];
            if (!instance || !cbs) continue;
            delete record.enteredCbs[name];
            for(var i$1 = 0; i$1 < cbs.length; i$1++)if (!instance._isBeingDestroyed) cbs[i$1](instance);
        }
    }
}
var View = {
    name: "RouterView",
    functional: true,
    props: {
        name: {
            type: String,
            default: "default"
        }
    },
    render: function render(_, ref) {
        var props = ref.props;
        var children = ref.children;
        var parent = ref.parent;
        var data = ref.data;
        // used by devtools to display a router-view badge
        data.routerView = true;
        // directly use parent context's createElement() function
        // so that components rendered by router-view can resolve named slots
        var h = parent.$createElement;
        var name = props.name;
        var route = parent.$route;
        var cache = parent._routerViewCache || (parent._routerViewCache = {});
        // determine current view depth, also check to see if the tree
        // has been toggled inactive but kept-alive.
        var depth = 0;
        var inactive = false;
        while(parent && parent._routerRoot !== parent){
            var vnodeData = parent.$vnode ? parent.$vnode.data : {};
            if (vnodeData.routerView) depth++;
            if (vnodeData.keepAlive && parent._directInactive && parent._inactive) inactive = true;
            parent = parent.$parent;
        }
        data.routerViewDepth = depth;
        // render previous view if the tree is inactive and kept-alive
        if (inactive) {
            var cachedData = cache[name];
            var cachedComponent = cachedData && cachedData.component;
            if (cachedComponent) {
                // #2301
                // pass props
                if (cachedData.configProps) fillPropsinData(cachedComponent, data, cachedData.route, cachedData.configProps);
                return h(cachedComponent, data, children);
            } else // render previous empty view
            return h();
        }
        var matched = route.matched[depth];
        var component = matched && matched.components[name];
        // render empty node if no matched route or no config component
        if (!matched || !component) {
            cache[name] = null;
            return h();
        }
        // cache component
        cache[name] = {
            component: component
        };
        // attach instance registration hook
        // this will be called in the instance's injected lifecycle hooks
        data.registerRouteInstance = function(vm, val) {
            // val could be undefined for unregistration
            var current = matched.instances[name];
            if (val && current !== vm || !val && current === vm) matched.instances[name] = val;
        };
        (data.hook || (data.hook = {})).prepatch = function(_, vnode) {
            matched.instances[name] = vnode.componentInstance;
        };
        // register instance in init hook
        // in case kept-alive component be actived when routes changed
        data.hook.init = function(vnode) {
            if (vnode.data.keepAlive && vnode.componentInstance && vnode.componentInstance !== matched.instances[name]) matched.instances[name] = vnode.componentInstance;
            // if the route transition has already been confirmed then we weren't
            // able to call the cbs during confirmation as the component was not
            // registered yet, so we call it here.
            handleRouteEntered(route);
        };
        var configProps = matched.props && matched.props[name];
        // save route and configProps in cache
        if (configProps) {
            extend(cache[name], {
                route: route,
                configProps: configProps
            });
            fillPropsinData(component, data, route, configProps);
        }
        return h(component, data, children);
    }
};
function fillPropsinData(component, data, route, configProps) {
    // resolve props
    var propsToPass = data.props = resolveProps(route, configProps);
    if (propsToPass) {
        // clone to prevent mutation
        propsToPass = data.props = extend({}, propsToPass);
        // pass non-declared props as attrs
        var attrs = data.attrs = data.attrs || {};
        for(var key in propsToPass)if (!component.props || !(key in component.props)) {
            attrs[key] = propsToPass[key];
            delete propsToPass[key];
        }
    }
}
function resolveProps(route, config) {
    switch(typeof config){
        case "undefined":
            return;
        case "object":
            return config;
        case "function":
            return config(route);
        case "boolean":
            return config ? route.params : undefined;
        default:
    }
}
/*  */ function resolvePath(relative, base, append) {
    var firstChar = relative.charAt(0);
    if (firstChar === "/") return relative;
    if (firstChar === "?" || firstChar === "#") return base + relative;
    var stack = base.split("/");
    // remove trailing segment if:
    // - not appending
    // - appending to trailing slash (last segment is empty)
    if (!append || !stack[stack.length - 1]) stack.pop();
    // resolve relative path
    var segments = relative.replace(/^\//, "").split("/");
    for(var i = 0; i < segments.length; i++){
        var segment = segments[i];
        if (segment === "..") stack.pop();
        else if (segment !== ".") stack.push(segment);
    }
    // ensure leading slash
    if (stack[0] !== "") stack.unshift("");
    return stack.join("/");
}
function parsePath(path) {
    var hash = "";
    var query = "";
    var hashIndex = path.indexOf("#");
    if (hashIndex >= 0) {
        hash = path.slice(hashIndex);
        path = path.slice(0, hashIndex);
    }
    var queryIndex = path.indexOf("?");
    if (queryIndex >= 0) {
        query = path.slice(queryIndex + 1);
        path = path.slice(0, queryIndex);
    }
    return {
        path: path,
        query: query,
        hash: hash
    };
}
function cleanPath(path) {
    return path.replace(/\/(?:\s*\/)+/g, "/");
}
var isarray = Array.isArray || function(arr) {
    return Object.prototype.toString.call(arr) == "[object Array]";
};
/**
 * Expose `pathToRegexp`.
 */ var pathToRegexp_1 = pathToRegexp;
var parse_1 = parse;
var compile_1 = compile;
var tokensToFunction_1 = tokensToFunction;
var tokensToRegExp_1 = tokensToRegExp;
/**
 * The main path matching regexp utility.
 *
 * @type {RegExp}
 */ var PATH_REGEXP = new RegExp([
    // Match escaped characters that would otherwise appear in future matches.
    // This allows the user to escape special characters that won't transform.
    "(\\\\.)",
    // Match Express-style parameters and un-named parameters with a prefix
    // and optional suffixes. Matches appear as:
    //
    // "/:test(\\d+)?" => ["/", "test", "\d+", undefined, "?", undefined]
    // "/route(\\d+)"  => [undefined, undefined, undefined, "\d+", undefined, undefined]
    // "/*"            => ["/", undefined, undefined, undefined, undefined, "*"]
    "([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"
].join("|"), "g");
/**
 * Parse a string for the raw tokens.
 *
 * @param  {string}  str
 * @param  {Object=} options
 * @return {!Array}
 */ function parse(str, options) {
    var tokens = [];
    var key = 0;
    var index = 0;
    var path = "";
    var defaultDelimiter = options && options.delimiter || "/";
    var res;
    while((res = PATH_REGEXP.exec(str)) != null){
        var m = res[0];
        var escaped = res[1];
        var offset = res.index;
        path += str.slice(index, offset);
        index = offset + m.length;
        // Ignore already escaped sequences.
        if (escaped) {
            path += escaped[1];
            continue;
        }
        var next = str[index];
        var prefix = res[2];
        var name = res[3];
        var capture = res[4];
        var group = res[5];
        var modifier = res[6];
        var asterisk = res[7];
        // Push the current path onto the tokens.
        if (path) {
            tokens.push(path);
            path = "";
        }
        var partial = prefix != null && next != null && next !== prefix;
        var repeat = modifier === "+" || modifier === "*";
        var optional = modifier === "?" || modifier === "*";
        var delimiter = res[2] || defaultDelimiter;
        var pattern = capture || group;
        tokens.push({
            name: name || key++,
            prefix: prefix || "",
            delimiter: delimiter,
            optional: optional,
            repeat: repeat,
            partial: partial,
            asterisk: !!asterisk,
            pattern: pattern ? escapeGroup(pattern) : asterisk ? ".*" : "[^" + escapeString(delimiter) + "]+?"
        });
    }
    // Match any characters still remaining.
    if (index < str.length) path += str.substr(index);
    // If the path exists, push it onto the end.
    if (path) tokens.push(path);
    return tokens;
}
/**
 * Compile a string to a template function for the path.
 *
 * @param  {string}             str
 * @param  {Object=}            options
 * @return {!function(Object=, Object=)}
 */ function compile(str, options) {
    return tokensToFunction(parse(str, options), options);
}
/**
 * Prettier encoding of URI path segments.
 *
 * @param  {string}
 * @return {string}
 */ function encodeURIComponentPretty(str) {
    return encodeURI(str).replace(/[\/?#]/g, function(c) {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
    });
}
/**
 * Encode the asterisk parameter. Similar to `pretty`, but allows slashes.
 *
 * @param  {string}
 * @return {string}
 */ function encodeAsterisk(str) {
    return encodeURI(str).replace(/[?#]/g, function(c) {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
    });
}
/**
 * Expose a method for transforming tokens into the path function.
 */ function tokensToFunction(tokens, options) {
    // Compile all the tokens into regexps.
    var matches = new Array(tokens.length);
    // Compile all the patterns before compilation.
    for(var i = 0; i < tokens.length; i++)if (typeof tokens[i] === "object") matches[i] = new RegExp("^(?:" + tokens[i].pattern + ")$", flags(options));
    return function(obj, opts) {
        var path = "";
        var data = obj || {};
        var options = opts || {};
        var encode = options.pretty ? encodeURIComponentPretty : encodeURIComponent;
        for(var i = 0; i < tokens.length; i++){
            var token = tokens[i];
            if (typeof token === "string") {
                path += token;
                continue;
            }
            var value = data[token.name];
            var segment;
            if (value == null) {
                if (token.optional) {
                    // Prepend partial segment prefixes.
                    if (token.partial) path += token.prefix;
                    continue;
                } else throw new TypeError('Expected "' + token.name + '" to be defined');
            }
            if (isarray(value)) {
                if (!token.repeat) throw new TypeError('Expected "' + token.name + '" to not repeat, but received `' + JSON.stringify(value) + "`");
                if (value.length === 0) {
                    if (token.optional) continue;
                    else throw new TypeError('Expected "' + token.name + '" to not be empty');
                }
                for(var j = 0; j < value.length; j++){
                    segment = encode(value[j]);
                    if (!matches[i].test(segment)) throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received `' + JSON.stringify(segment) + "`");
                    path += (j === 0 ? token.prefix : token.delimiter) + segment;
                }
                continue;
            }
            segment = token.asterisk ? encodeAsterisk(value) : encode(value);
            if (!matches[i].test(segment)) throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"');
            path += token.prefix + segment;
        }
        return path;
    };
}
/**
 * Escape a regular expression string.
 *
 * @param  {string} str
 * @return {string}
 */ function escapeString(str) {
    return str.replace(/([.+*?=^!:${}()[\]|\/\\])/g, "\\$1");
}
/**
 * Escape the capturing group by escaping special characters and meaning.
 *
 * @param  {string} group
 * @return {string}
 */ function escapeGroup(group) {
    return group.replace(/([=!:$\/()])/g, "\\$1");
}
/**
 * Attach the keys as a property of the regexp.
 *
 * @param  {!RegExp} re
 * @param  {Array}   keys
 * @return {!RegExp}
 */ function attachKeys(re, keys) {
    re.keys = keys;
    return re;
}
/**
 * Get the flags for a regexp from the options.
 *
 * @param  {Object} options
 * @return {string}
 */ function flags(options) {
    return options && options.sensitive ? "" : "i";
}
/**
 * Pull out keys from a regexp.
 *
 * @param  {!RegExp} path
 * @param  {!Array}  keys
 * @return {!RegExp}
 */ function regexpToRegexp(path, keys) {
    // Use a negative lookahead to match only capturing groups.
    var groups = path.source.match(/\((?!\?)/g);
    if (groups) for(var i = 0; i < groups.length; i++)keys.push({
        name: i,
        prefix: null,
        delimiter: null,
        optional: false,
        repeat: false,
        partial: false,
        asterisk: false,
        pattern: null
    });
    return attachKeys(path, keys);
}
/**
 * Transform an array into a regexp.
 *
 * @param  {!Array}  path
 * @param  {Array}   keys
 * @param  {!Object} options
 * @return {!RegExp}
 */ function arrayToRegexp(path, keys, options) {
    var parts = [];
    for(var i = 0; i < path.length; i++)parts.push(pathToRegexp(path[i], keys, options).source);
    var regexp = new RegExp("(?:" + parts.join("|") + ")", flags(options));
    return attachKeys(regexp, keys);
}
/**
 * Create a path regexp from string input.
 *
 * @param  {string}  path
 * @param  {!Array}  keys
 * @param  {!Object} options
 * @return {!RegExp}
 */ function stringToRegexp(path, keys, options) {
    return tokensToRegExp(parse(path, options), keys, options);
}
/**
 * Expose a function for taking tokens and returning a RegExp.
 *
 * @param  {!Array}          tokens
 * @param  {(Array|Object)=} keys
 * @param  {Object=}         options
 * @return {!RegExp}
 */ function tokensToRegExp(tokens, keys, options) {
    if (!isarray(keys)) {
        options = keys || options;
        keys = [];
    }
    options = options || {};
    var strict = options.strict;
    var end = options.end !== false;
    var route = "";
    // Iterate over the tokens and create our regexp string.
    for(var i = 0; i < tokens.length; i++){
        var token = tokens[i];
        if (typeof token === "string") route += escapeString(token);
        else {
            var prefix = escapeString(token.prefix);
            var capture = "(?:" + token.pattern + ")";
            keys.push(token);
            if (token.repeat) capture += "(?:" + prefix + capture + ")*";
            if (token.optional) {
                if (!token.partial) capture = "(?:" + prefix + "(" + capture + "))?";
                else capture = prefix + "(" + capture + ")?";
            } else capture = prefix + "(" + capture + ")";
            route += capture;
        }
    }
    var delimiter = escapeString(options.delimiter || "/");
    var endsWithDelimiter = route.slice(-delimiter.length) === delimiter;
    // In non-strict mode we allow a slash at the end of match. If the path to
    // match already ends with a slash, we remove it for consistency. The slash
    // is valid at the end of a path match, not in the middle. This is important
    // in non-ending mode, where "/test/" shouldn't match "/test//route".
    if (!strict) route = (endsWithDelimiter ? route.slice(0, -delimiter.length) : route) + "(?:" + delimiter + "(?=$))?";
    if (end) route += "$";
    else // In non-ending mode, we need the capturing groups to match as much as
    // possible by using a positive lookahead to the end or next path segment.
    route += strict && endsWithDelimiter ? "" : "(?=" + delimiter + "|$)";
    return attachKeys(new RegExp("^" + route, flags(options)), keys);
}
/**
 * Normalize the given path string, returning a regular expression.
 *
 * An empty array can be passed in for the keys, which will hold the
 * placeholder key descriptions. For example, using `/user/:id`, `keys` will
 * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
 *
 * @param  {(string|RegExp|Array)} path
 * @param  {(Array|Object)=}       keys
 * @param  {Object=}               options
 * @return {!RegExp}
 */ function pathToRegexp(path, keys, options) {
    if (!isarray(keys)) {
        options = keys || options;
        keys = [];
    }
    options = options || {};
    if (path instanceof RegExp) return regexpToRegexp(path, keys);
    if (isarray(path)) return arrayToRegexp(path, keys, options);
    return stringToRegexp(path, keys, options);
}
pathToRegexp_1.parse = parse_1;
pathToRegexp_1.compile = compile_1;
pathToRegexp_1.tokensToFunction = tokensToFunction_1;
pathToRegexp_1.tokensToRegExp = tokensToRegExp_1;
/*  */ // $flow-disable-line
var regexpCompileCache = Object.create(null);
function fillParams(path, params, routeMsg) {
    params = params || {};
    try {
        var filler = regexpCompileCache[path] || (regexpCompileCache[path] = pathToRegexp_1.compile(path));
        // Fix #2505 resolving asterisk routes { name: 'not-found', params: { pathMatch: '/not-found' }}
        // and fix #3106 so that you can work with location descriptor object having params.pathMatch equal to empty string
        if (typeof params.pathMatch === "string") params[0] = params.pathMatch;
        return filler(params, {
            pretty: true
        });
    } catch (e) {
        return "";
    } finally{
        // delete the 0 if it was added
        delete params[0];
    }
}
/*  */ function normalizeLocation(raw, current, append, router) {
    var next = typeof raw === "string" ? {
        path: raw
    } : raw;
    // named target
    if (next._normalized) return next;
    else if (next.name) {
        next = extend({}, raw);
        var params = next.params;
        if (params && typeof params === "object") next.params = extend({}, params);
        return next;
    }
    // relative params
    if (!next.path && next.params && current) {
        next = extend({}, next);
        next._normalized = true;
        var params$1 = extend(extend({}, current.params), next.params);
        if (current.name) {
            next.name = current.name;
            next.params = params$1;
        } else if (current.matched.length) {
            var rawPath = current.matched[current.matched.length - 1].path;
            next.path = fillParams(rawPath, params$1, "path " + current.path);
        }
        return next;
    }
    var parsedPath = parsePath(next.path || "");
    var basePath = current && current.path || "/";
    var path = parsedPath.path ? resolvePath(parsedPath.path, basePath, append || next.append) : basePath;
    var query = resolveQuery(parsedPath.query, next.query, router && router.options.parseQuery);
    var hash = next.hash || parsedPath.hash;
    if (hash && hash.charAt(0) !== "#") hash = "#" + hash;
    return {
        _normalized: true,
        path: path,
        query: query,
        hash: hash
    };
}
/*  */ // work around weird flow bug
var toTypes = [
    String,
    Object
];
var eventTypes = [
    String,
    Array
];
var noop = function() {};
var warnedCustomSlot;
var warnedTagProp;
var warnedEventProp;
var Link = {
    name: "RouterLink",
    props: {
        to: {
            type: toTypes,
            required: true
        },
        tag: {
            type: String,
            default: "a"
        },
        custom: Boolean,
        exact: Boolean,
        exactPath: Boolean,
        append: Boolean,
        replace: Boolean,
        activeClass: String,
        exactActiveClass: String,
        ariaCurrentValue: {
            type: String,
            default: "page"
        },
        event: {
            type: eventTypes,
            default: "click"
        }
    },
    render: function render(h) {
        var this$1$1 = this;
        var router = this.$router;
        var current = this.$route;
        var ref = router.resolve(this.to, current, this.append);
        var location = ref.location;
        var route = ref.route;
        var href = ref.href;
        var classes = {};
        var globalActiveClass = router.options.linkActiveClass;
        var globalExactActiveClass = router.options.linkExactActiveClass;
        // Support global empty active class
        var activeClassFallback = globalActiveClass == null ? "router-link-active" : globalActiveClass;
        var exactActiveClassFallback = globalExactActiveClass == null ? "router-link-exact-active" : globalExactActiveClass;
        var activeClass = this.activeClass == null ? activeClassFallback : this.activeClass;
        var exactActiveClass = this.exactActiveClass == null ? exactActiveClassFallback : this.exactActiveClass;
        var compareTarget = route.redirectedFrom ? createRoute(null, normalizeLocation(route.redirectedFrom), null, router) : route;
        classes[exactActiveClass] = isSameRoute(current, compareTarget, this.exactPath);
        classes[activeClass] = this.exact || this.exactPath ? classes[exactActiveClass] : isIncludedRoute(current, compareTarget);
        var ariaCurrentValue = classes[exactActiveClass] ? this.ariaCurrentValue : null;
        var handler = function(e) {
            if (guardEvent(e)) {
                if (this$1$1.replace) router.replace(location, noop);
                else router.push(location, noop);
            }
        };
        var on = {
            click: guardEvent
        };
        if (Array.isArray(this.event)) this.event.forEach(function(e) {
            on[e] = handler;
        });
        else on[this.event] = handler;
        var data = {
            class: classes
        };
        var scopedSlot = !this.$scopedSlots.$hasNormal && this.$scopedSlots.default && this.$scopedSlots.default({
            href: href,
            route: route,
            navigate: handler,
            isActive: classes[activeClass],
            isExactActive: classes[exactActiveClass]
        });
        if (scopedSlot) {
            if (scopedSlot.length === 1) return scopedSlot[0];
            else if (scopedSlot.length > 1 || !scopedSlot.length) return scopedSlot.length === 0 ? h() : h("span", {}, scopedSlot);
        }
        if (this.tag === "a") {
            data.on = on;
            data.attrs = {
                href: href,
                "aria-current": ariaCurrentValue
            };
        } else {
            // find the first <a> child and apply listener and href
            var a = findAnchor(this.$slots.default);
            if (a) {
                // in case the <a> is a static node
                a.isStatic = false;
                var aData = a.data = extend({}, a.data);
                aData.on = aData.on || {};
                // transform existing events in both objects into arrays so we can push later
                for(var event in aData.on){
                    var handler$1 = aData.on[event];
                    if (event in on) aData.on[event] = Array.isArray(handler$1) ? handler$1 : [
                        handler$1
                    ];
                }
                // append new listeners for router-link
                for(var event$1 in on)if (event$1 in aData.on) // on[event] is always a function
                aData.on[event$1].push(on[event$1]);
                else aData.on[event$1] = handler;
                var aAttrs = a.data.attrs = extend({}, a.data.attrs);
                aAttrs.href = href;
                aAttrs["aria-current"] = ariaCurrentValue;
            } else // doesn't have <a> child, apply listener to self
            data.on = on;
        }
        return h(this.tag, data, this.$slots.default);
    }
};
function guardEvent(e) {
    // don't redirect with control keys
    if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) return;
    // don't redirect when preventDefault called
    if (e.defaultPrevented) return;
    // don't redirect on right click
    if (e.button !== undefined && e.button !== 0) return;
    // don't redirect if `target="_blank"`
    if (e.currentTarget && e.currentTarget.getAttribute) {
        var target = e.currentTarget.getAttribute("target");
        if (/\b_blank\b/i.test(target)) return;
    }
    // this may be a Weex event which doesn't have this method
    if (e.preventDefault) e.preventDefault();
    return true;
}
function findAnchor(children) {
    if (children) {
        var child;
        for(var i = 0; i < children.length; i++){
            child = children[i];
            if (child.tag === "a") return child;
            if (child.children && (child = findAnchor(child.children))) return child;
        }
    }
}
var _Vue;
function install(Vue) {
    if (install.installed && _Vue === Vue) return;
    install.installed = true;
    _Vue = Vue;
    var isDef = function(v) {
        return v !== undefined;
    };
    var registerInstance = function(vm, callVal) {
        var i = vm.$options._parentVnode;
        if (isDef(i) && isDef(i = i.data) && isDef(i = i.registerRouteInstance)) i(vm, callVal);
    };
    Vue.mixin({
        beforeCreate: function beforeCreate() {
            if (isDef(this.$options.router)) {
                this._routerRoot = this;
                this._router = this.$options.router;
                this._router.init(this);
                Vue.util.defineReactive(this, "_route", this._router.history.current);
            } else this._routerRoot = this.$parent && this.$parent._routerRoot || this;
            registerInstance(this, this);
        },
        destroyed: function destroyed() {
            registerInstance(this);
        }
    });
    Object.defineProperty(Vue.prototype, "$router", {
        get: function get() {
            return this._routerRoot._router;
        }
    });
    Object.defineProperty(Vue.prototype, "$route", {
        get: function get() {
            return this._routerRoot._route;
        }
    });
    Vue.component("RouterView", View);
    Vue.component("RouterLink", Link);
    var strats = Vue.config.optionMergeStrategies;
    // use the same hook merging strategy for route hooks
    strats.beforeRouteEnter = strats.beforeRouteLeave = strats.beforeRouteUpdate = strats.created;
}
/*  */ var inBrowser = typeof window !== "undefined";
/*  */ function createRouteMap(routes, oldPathList, oldPathMap, oldNameMap, parentRoute) {
    // the path list is used to control path matching priority
    var pathList = oldPathList || [];
    // $flow-disable-line
    var pathMap = oldPathMap || Object.create(null);
    // $flow-disable-line
    var nameMap = oldNameMap || Object.create(null);
    routes.forEach(function(route) {
        addRouteRecord(pathList, pathMap, nameMap, route, parentRoute);
    });
    // ensure wildcard routes are always at the end
    for(var i = 0, l = pathList.length; i < l; i++)if (pathList[i] === "*") {
        pathList.push(pathList.splice(i, 1)[0]);
        l--;
        i--;
    }
    var found, path, pathNames, path1;
    return {
        pathList: pathList,
        pathMap: pathMap,
        nameMap: nameMap
    };
}
function addRouteRecord(pathList, pathMap, nameMap, route, parent, matchAs) {
    var path = route.path;
    var name = route.name;
    var pathToRegexpOptions = route.pathToRegexpOptions || {};
    var normalizedPath = normalizePath(path, parent, pathToRegexpOptions.strict);
    if (typeof route.caseSensitive === "boolean") pathToRegexpOptions.sensitive = route.caseSensitive;
    var record = {
        path: normalizedPath,
        regex: compileRouteRegex(normalizedPath, pathToRegexpOptions),
        components: route.components || {
            default: route.component
        },
        alias: route.alias ? typeof route.alias === "string" ? [
            route.alias
        ] : route.alias : [],
        instances: {},
        enteredCbs: {},
        name: name,
        parent: parent,
        matchAs: matchAs,
        redirect: route.redirect,
        beforeEnter: route.beforeEnter,
        meta: route.meta || {},
        props: route.props == null ? {} : route.components ? route.props : {
            default: route.props
        }
    };
    if (route.children) {
        var child;
        route.children.forEach(function(child) {
            var childMatchAs = matchAs ? cleanPath(matchAs + "/" + child.path) : undefined;
            addRouteRecord(pathList, pathMap, nameMap, child, record, childMatchAs);
        });
    }
    if (!pathMap[record.path]) {
        pathList.push(record.path);
        pathMap[record.path] = record;
    }
    if (route.alias !== undefined) {
        var aliases = Array.isArray(route.alias) ? route.alias : [
            route.alias
        ];
        for(var i = 0; i < aliases.length; ++i){
            var alias = aliases[i];
            var aliasRoute = {
                path: alias,
                children: route.children
            };
            addRouteRecord(pathList, pathMap, nameMap, aliasRoute, parent, record.path || "/" // matchAs
            );
        }
    }
    if (name) {
        if (!nameMap[name]) nameMap[name] = record;
    }
}
function compileRouteRegex(path, pathToRegexpOptions) {
    var regex = pathToRegexp_1(path, [], pathToRegexpOptions);
    var keys, key;
    return regex;
}
function normalizePath(path, parent, strict) {
    if (!strict) path = path.replace(/\/$/, "");
    if (path[0] === "/") return path;
    if (parent == null) return path;
    return cleanPath(parent.path + "/" + path);
}
/*  */ function createMatcher(routes, router) {
    var ref = createRouteMap(routes);
    var pathList = ref.pathList;
    var pathMap = ref.pathMap;
    var nameMap = ref.nameMap;
    function addRoutes(routes) {
        createRouteMap(routes, pathList, pathMap, nameMap);
    }
    function addRoute(parentOrRoute, route) {
        var parent = typeof parentOrRoute !== "object" ? nameMap[parentOrRoute] : undefined;
        // $flow-disable-line
        createRouteMap([
            route || parentOrRoute
        ], pathList, pathMap, nameMap, parent);
        // add aliases of parent
        if (parent && parent.alias.length) createRouteMap(// $flow-disable-line route is defined if parent is
        parent.alias.map(function(alias) {
            return {
                path: alias,
                children: [
                    route
                ]
            };
        }), pathList, pathMap, nameMap, parent);
    }
    function getRoutes() {
        return pathList.map(function(path) {
            return pathMap[path];
        });
    }
    function match(raw, currentRoute, redirectedFrom) {
        var location = normalizeLocation(raw, currentRoute, false, router);
        var name = location.name;
        if (name) {
            var record = nameMap[name];
            if (!record) return _createRoute(null, location);
            var paramNames = record.regex.keys.filter(function(key) {
                return !key.optional;
            }).map(function(key) {
                return key.name;
            });
            if (typeof location.params !== "object") location.params = {};
            if (currentRoute && typeof currentRoute.params === "object") {
                for(var key in currentRoute.params)if (!(key in location.params) && paramNames.indexOf(key) > -1) location.params[key] = currentRoute.params[key];
            }
            location.path = fillParams(record.path, location.params, 'named route "' + name + '"');
            return _createRoute(record, location, redirectedFrom);
        } else if (location.path) {
            location.params = {};
            for(var i = 0; i < pathList.length; i++){
                var path = pathList[i];
                var record$1 = pathMap[path];
                if (matchRoute(record$1.regex, location.path, location.params)) return _createRoute(record$1, location, redirectedFrom);
            }
        }
        // no match
        return _createRoute(null, location);
    }
    function redirect(record, location) {
        var originalRedirect = record.redirect;
        var redirect = typeof originalRedirect === "function" ? originalRedirect(createRoute(record, location, null, router)) : originalRedirect;
        if (typeof redirect === "string") redirect = {
            path: redirect
        };
        if (!redirect || typeof redirect !== "object") return _createRoute(null, location);
        var re = redirect;
        var name = re.name;
        var path = re.path;
        var query = location.query;
        var hash = location.hash;
        var params = location.params;
        query = re.hasOwnProperty("query") ? re.query : query;
        hash = re.hasOwnProperty("hash") ? re.hash : hash;
        params = re.hasOwnProperty("params") ? re.params : params;
        if (name) {
            // resolved named direct
            var targetRecord = nameMap[name];
            return match({
                _normalized: true,
                name: name,
                query: query,
                hash: hash,
                params: params
            }, undefined, location);
        } else if (path) {
            // 1. resolve relative redirect
            var rawPath = resolveRecordPath(path, record);
            // 2. resolve params
            var resolvedPath = fillParams(rawPath, params, 'redirect route with path "' + rawPath + '"');
            // 3. rematch with existing query and hash
            return match({
                _normalized: true,
                path: resolvedPath,
                query: query,
                hash: hash
            }, undefined, location);
        } else return _createRoute(null, location);
    }
    function alias(record, location, matchAs) {
        var aliasedPath = fillParams(matchAs, location.params, 'aliased route with path "' + matchAs + '"');
        var aliasedMatch = match({
            _normalized: true,
            path: aliasedPath
        });
        if (aliasedMatch) {
            var matched = aliasedMatch.matched;
            var aliasedRecord = matched[matched.length - 1];
            location.params = aliasedMatch.params;
            return _createRoute(aliasedRecord, location);
        }
        return _createRoute(null, location);
    }
    function _createRoute(record, location, redirectedFrom) {
        if (record && record.redirect) return redirect(record, redirectedFrom || location);
        if (record && record.matchAs) return alias(record, location, record.matchAs);
        return createRoute(record, location, redirectedFrom, router);
    }
    return {
        match: match,
        addRoute: addRoute,
        getRoutes: getRoutes,
        addRoutes: addRoutes
    };
}
function matchRoute(regex, path, params) {
    var m = path.match(regex);
    if (!m) return false;
    else if (!params) return true;
    for(var i = 1, len = m.length; i < len; ++i){
        var key = regex.keys[i - 1];
        if (key) // Fix #1994: using * with props: true generates a param named 0
        params[key.name || "pathMatch"] = typeof m[i] === "string" ? decode(m[i]) : m[i];
    }
    return true;
}
function resolveRecordPath(path, record) {
    return resolvePath(path, record.parent ? record.parent.path : "/", true);
}
/*  */ // use User Timing api (if present) for more accurate key precision
var Time = inBrowser && window.performance && window.performance.now ? window.performance : Date;
function genStateKey() {
    return Time.now().toFixed(3);
}
var _key = genStateKey();
function getStateKey() {
    return _key;
}
function setStateKey(key) {
    return _key = key;
}
/*  */ var positionStore = Object.create(null);
function setupScroll() {
    // Prevent browser scroll behavior on History popstate
    if ("scrollRestoration" in window.history) window.history.scrollRestoration = "manual";
    // Fix for #1585 for Firefox
    // Fix for #2195 Add optional third attribute to workaround a bug in safari https://bugs.webkit.org/show_bug.cgi?id=182678
    // Fix for #2774 Support for apps loaded from Windows file shares not mapped to network drives: replaced location.origin with
    // window.location.protocol + '//' + window.location.host
    // location.host contains the port and location.hostname doesn't
    var protocolAndPath = window.location.protocol + "//" + window.location.host;
    var absolutePath = window.location.href.replace(protocolAndPath, "");
    // preserve existing history state as it could be overriden by the user
    var stateCopy = extend({}, window.history.state);
    stateCopy.key = getStateKey();
    window.history.replaceState(stateCopy, "", absolutePath);
    window.addEventListener("popstate", handlePopState);
    return function() {
        window.removeEventListener("popstate", handlePopState);
    };
}
function handleScroll(router, to, from, isPop) {
    if (!router.app) return;
    var behavior = router.options.scrollBehavior;
    if (!behavior) return;
    // wait until re-render finishes before scrolling
    router.app.$nextTick(function() {
        var position = getScrollPosition();
        var shouldScroll = behavior.call(router, to, from, isPop ? position : null);
        if (!shouldScroll) return;
        if (typeof shouldScroll.then === "function") shouldScroll.then(function(shouldScroll) {
            scrollToPosition(shouldScroll, position);
        }).catch(function(err) {});
        else scrollToPosition(shouldScroll, position);
    });
}
function saveScrollPosition() {
    var key = getStateKey();
    if (key) positionStore[key] = {
        x: window.pageXOffset,
        y: window.pageYOffset
    };
}
function handlePopState(e) {
    saveScrollPosition();
    if (e.state && e.state.key) setStateKey(e.state.key);
}
function getScrollPosition() {
    var key = getStateKey();
    if (key) return positionStore[key];
}
function getElementPosition(el, offset) {
    var docEl = document.documentElement;
    var docRect = docEl.getBoundingClientRect();
    var elRect = el.getBoundingClientRect();
    return {
        x: elRect.left - docRect.left - offset.x,
        y: elRect.top - docRect.top - offset.y
    };
}
function isValidPosition(obj) {
    return isNumber(obj.x) || isNumber(obj.y);
}
function normalizePosition(obj) {
    return {
        x: isNumber(obj.x) ? obj.x : window.pageXOffset,
        y: isNumber(obj.y) ? obj.y : window.pageYOffset
    };
}
function normalizeOffset(obj) {
    return {
        x: isNumber(obj.x) ? obj.x : 0,
        y: isNumber(obj.y) ? obj.y : 0
    };
}
function isNumber(v) {
    return typeof v === "number";
}
var hashStartsWithNumberRE = /^#\d/;
function scrollToPosition(shouldScroll, position) {
    var isObject = typeof shouldScroll === "object";
    if (isObject && typeof shouldScroll.selector === "string") {
        // getElementById would still fail if the selector contains a more complicated query like #main[data-attr]
        // but at the same time, it doesn't make much sense to select an element with an id and an extra selector
        var el = hashStartsWithNumberRE.test(shouldScroll.selector) // $flow-disable-line
         ? document.getElementById(shouldScroll.selector.slice(1)) // $flow-disable-line
         : document.querySelector(shouldScroll.selector);
        if (el) {
            var offset = shouldScroll.offset && typeof shouldScroll.offset === "object" ? shouldScroll.offset : {};
            offset = normalizeOffset(offset);
            position = getElementPosition(el, offset);
        } else if (isValidPosition(shouldScroll)) position = normalizePosition(shouldScroll);
    } else if (isObject && isValidPosition(shouldScroll)) position = normalizePosition(shouldScroll);
    if (position) {
        // $flow-disable-line
        if ("scrollBehavior" in document.documentElement.style) window.scrollTo({
            left: position.x,
            top: position.y,
            // $flow-disable-line
            behavior: shouldScroll.behavior
        });
        else window.scrollTo(position.x, position.y);
    }
}
/*  */ var supportsPushState = inBrowser && function() {
    var ua = window.navigator.userAgent;
    if ((ua.indexOf("Android 2.") !== -1 || ua.indexOf("Android 4.0") !== -1) && ua.indexOf("Mobile Safari") !== -1 && ua.indexOf("Chrome") === -1 && ua.indexOf("Windows Phone") === -1) return false;
    return window.history && typeof window.history.pushState === "function";
}();
function pushState(url, replace) {
    saveScrollPosition();
    // try...catch the pushState call to get around Safari
    // DOM Exception 18 where it limits to 100 pushState calls
    var history = window.history;
    try {
        if (replace) {
            // preserve existing history state as it could be overriden by the user
            var stateCopy = extend({}, history.state);
            stateCopy.key = getStateKey();
            history.replaceState(stateCopy, "", url);
        } else history.pushState({
            key: setStateKey(genStateKey())
        }, "", url);
    } catch (e) {
        window.location[replace ? "replace" : "assign"](url);
    }
}
function replaceState(url) {
    pushState(url, true);
}
// When changing thing, also edit router.d.ts
var NavigationFailureType = {
    redirected: 2,
    aborted: 4,
    cancelled: 8,
    duplicated: 16
};
function createNavigationRedirectedError(from, to) {
    return createRouterError(from, to, NavigationFailureType.redirected, 'Redirected when going from "' + from.fullPath + '" to "' + stringifyRoute(to) + '" via a navigation guard.');
}
function createNavigationDuplicatedError(from, to) {
    var error = createRouterError(from, to, NavigationFailureType.duplicated, 'Avoided redundant navigation to current location: "' + from.fullPath + '".');
    // backwards compatible with the first introduction of Errors
    error.name = "NavigationDuplicated";
    return error;
}
function createNavigationCancelledError(from, to) {
    return createRouterError(from, to, NavigationFailureType.cancelled, 'Navigation cancelled from "' + from.fullPath + '" to "' + to.fullPath + '" with a new navigation.');
}
function createNavigationAbortedError(from, to) {
    return createRouterError(from, to, NavigationFailureType.aborted, 'Navigation aborted from "' + from.fullPath + '" to "' + to.fullPath + '" via a navigation guard.');
}
function createRouterError(from, to, type, message) {
    var error = new Error(message);
    error._isRouter = true;
    error.from = from;
    error.to = to;
    error.type = type;
    return error;
}
var propertiesToLog = [
    "params",
    "query",
    "hash"
];
function stringifyRoute(to) {
    if (typeof to === "string") return to;
    if ("path" in to) return to.path;
    var location = {};
    propertiesToLog.forEach(function(key) {
        if (key in to) location[key] = to[key];
    });
    return JSON.stringify(location, null, 2);
}
function isError(err) {
    return Object.prototype.toString.call(err).indexOf("Error") > -1;
}
function isNavigationFailure(err, errorType) {
    return isError(err) && err._isRouter && (errorType == null || err.type === errorType);
}
/*  */ function runQueue(queue, fn, cb) {
    var step = function(index) {
        if (index >= queue.length) cb();
        else if (queue[index]) fn(queue[index], function() {
            step(index + 1);
        });
        else step(index + 1);
    };
    step(0);
}
/*  */ function resolveAsyncComponents(matched) {
    return function(to, from, next) {
        var hasAsync = false;
        var pending = 0;
        var error = null;
        flatMapComponents(matched, function(def, _, match, key) {
            // if it's a function and doesn't have cid attached,
            // assume it's an async component resolve function.
            // we are not using Vue's default async resolving mechanism because
            // we want to halt the navigation until the incoming component has been
            // resolved.
            if (typeof def === "function" && def.cid === undefined) {
                hasAsync = true;
                pending++;
                var resolve = once(function(resolvedDef) {
                    if (isESModule(resolvedDef)) resolvedDef = resolvedDef.default;
                    // save resolved on async factory in case it's used elsewhere
                    def.resolved = typeof resolvedDef === "function" ? resolvedDef : _Vue.extend(resolvedDef);
                    match.components[key] = resolvedDef;
                    pending--;
                    if (pending <= 0) next();
                });
                var reject = once(function(reason) {
                    var msg = "Failed to resolve async component " + key + ": " + reason;
                    if (!error) {
                        error = isError(reason) ? reason : new Error(msg);
                        next(error);
                    }
                });
                var res;
                try {
                    res = def(resolve, reject);
                } catch (e) {
                    reject(e);
                }
                if (res) {
                    if (typeof res.then === "function") res.then(resolve, reject);
                    else {
                        // new syntax in Vue 2.3
                        var comp = res.component;
                        if (comp && typeof comp.then === "function") comp.then(resolve, reject);
                    }
                }
            }
        });
        if (!hasAsync) next();
    };
}
function flatMapComponents(matched, fn) {
    return flatten(matched.map(function(m) {
        return Object.keys(m.components).map(function(key) {
            return fn(m.components[key], m.instances[key], m, key);
        });
    }));
}
function flatten(arr) {
    return Array.prototype.concat.apply([], arr);
}
var hasSymbol = typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol";
function isESModule(obj) {
    return obj.__esModule || hasSymbol && obj[Symbol.toStringTag] === "Module";
}
// in Webpack 2, require.ensure now also returns a Promise
// so the resolve/reject functions may get called an extra time
// if the user uses an arrow function shorthand that happens to
// return that Promise.
function once(fn) {
    var called = false;
    return function() {
        var args = [], len = arguments.length;
        while(len--)args[len] = arguments[len];
        if (called) return;
        called = true;
        return fn.apply(this, args);
    };
}
/*  */ var History = function History(router, base) {
    this.router = router;
    this.base = normalizeBase(base);
    // start with a route object that stands for "nowhere"
    this.current = START;
    this.pending = null;
    this.ready = false;
    this.readyCbs = [];
    this.readyErrorCbs = [];
    this.errorCbs = [];
    this.listeners = [];
};
History.prototype.listen = function listen(cb) {
    this.cb = cb;
};
History.prototype.onReady = function onReady(cb, errorCb) {
    if (this.ready) cb();
    else {
        this.readyCbs.push(cb);
        if (errorCb) this.readyErrorCbs.push(errorCb);
    }
};
History.prototype.onError = function onError(errorCb) {
    this.errorCbs.push(errorCb);
};
History.prototype.transitionTo = function transitionTo(location, onComplete, onAbort) {
    var this$1$1 = this;
    var route;
    // catch redirect option https://github.com/vuejs/vue-router/issues/3201
    try {
        route = this.router.match(location, this.current);
    } catch (e) {
        this.errorCbs.forEach(function(cb) {
            cb(e);
        });
        // Exception should still be thrown
        throw e;
    }
    var prev = this.current;
    this.confirmTransition(route, function() {
        this$1$1.updateRoute(route);
        onComplete && onComplete(route);
        this$1$1.ensureURL();
        this$1$1.router.afterHooks.forEach(function(hook) {
            hook && hook(route, prev);
        });
        // fire ready cbs once
        if (!this$1$1.ready) {
            this$1$1.ready = true;
            this$1$1.readyCbs.forEach(function(cb) {
                cb(route);
            });
        }
    }, function(err) {
        if (onAbort) onAbort(err);
        if (err && !this$1$1.ready) // Initial redirection should not mark the history as ready yet
        // because it's triggered by the redirection instead
        // https://github.com/vuejs/vue-router/issues/3225
        // https://github.com/vuejs/vue-router/issues/3331
        {
            if (!isNavigationFailure(err, NavigationFailureType.redirected) || prev !== START) {
                this$1$1.ready = true;
                this$1$1.readyErrorCbs.forEach(function(cb) {
                    cb(err);
                });
            }
        }
    });
};
History.prototype.confirmTransition = function confirmTransition(route, onComplete, onAbort) {
    var this$1$1 = this;
    var current = this.current;
    this.pending = route;
    var abort = function(err) {
        // changed after adding errors with
        // https://github.com/vuejs/vue-router/pull/3047 before that change,
        // redirect and aborted navigation would produce an err == null
        if (!isNavigationFailure(err) && isError(err)) {
            if (this$1$1.errorCbs.length) this$1$1.errorCbs.forEach(function(cb) {
                cb(err);
            });
            else console.error(err);
        }
        onAbort && onAbort(err);
    };
    var lastRouteIndex = route.matched.length - 1;
    var lastCurrentIndex = current.matched.length - 1;
    if (isSameRoute(route, current) && // in the case the route map has been dynamically appended to
    lastRouteIndex === lastCurrentIndex && route.matched[lastRouteIndex] === current.matched[lastCurrentIndex]) {
        this.ensureURL();
        if (route.hash) handleScroll(this.router, current, route, false);
        return abort(createNavigationDuplicatedError(current, route));
    }
    var ref = resolveQueue(this.current.matched, route.matched);
    var updated = ref.updated;
    var deactivated = ref.deactivated;
    var activated = ref.activated;
    var queue = [].concat(// in-component leave guards
    extractLeaveGuards(deactivated), // global before hooks
    this.router.beforeHooks, // in-component update hooks
    extractUpdateHooks(updated), // in-config enter guards
    activated.map(function(m) {
        return m.beforeEnter;
    }), // async components
    resolveAsyncComponents(activated));
    var iterator = function(hook, next) {
        if (this$1$1.pending !== route) return abort(createNavigationCancelledError(current, route));
        try {
            hook(route, current, function(to) {
                if (to === false) {
                    // next(false) -> abort navigation, ensure current URL
                    this$1$1.ensureURL(true);
                    abort(createNavigationAbortedError(current, route));
                } else if (isError(to)) {
                    this$1$1.ensureURL(true);
                    abort(to);
                } else if (typeof to === "string" || typeof to === "object" && (typeof to.path === "string" || typeof to.name === "string")) {
                    // next('/') or next({ path: '/' }) -> redirect
                    abort(createNavigationRedirectedError(current, route));
                    if (typeof to === "object" && to.replace) this$1$1.replace(to);
                    else this$1$1.push(to);
                } else // confirm transition and pass on the value
                next(to);
            });
        } catch (e) {
            abort(e);
        }
    };
    runQueue(queue, iterator, function() {
        // wait until async components are resolved before
        // extracting in-component enter guards
        var enterGuards = extractEnterGuards(activated);
        var queue = enterGuards.concat(this$1$1.router.resolveHooks);
        runQueue(queue, iterator, function() {
            if (this$1$1.pending !== route) return abort(createNavigationCancelledError(current, route));
            this$1$1.pending = null;
            onComplete(route);
            if (this$1$1.router.app) this$1$1.router.app.$nextTick(function() {
                handleRouteEntered(route);
            });
        });
    });
};
History.prototype.updateRoute = function updateRoute(route) {
    this.current = route;
    this.cb && this.cb(route);
};
History.prototype.setupListeners = function setupListeners() {
// Default implementation is empty
};
History.prototype.teardown = function teardown() {
    // clean up event listeners
    // https://github.com/vuejs/vue-router/issues/2341
    this.listeners.forEach(function(cleanupListener) {
        cleanupListener();
    });
    this.listeners = [];
    // reset current history route
    // https://github.com/vuejs/vue-router/issues/3294
    this.current = START;
    this.pending = null;
};
function normalizeBase(base) {
    if (!base) {
        if (inBrowser) {
            // respect <base> tag
            var baseEl = document.querySelector("base");
            base = baseEl && baseEl.getAttribute("href") || "/";
            // strip full URL origin
            base = base.replace(/^https?:\/\/[^\/]+/, "");
        } else base = "/";
    }
    // make sure there's the starting slash
    if (base.charAt(0) !== "/") base = "/" + base;
    // remove trailing slash
    return base.replace(/\/$/, "");
}
function resolveQueue(current, next) {
    var i;
    var max = Math.max(current.length, next.length);
    for(i = 0; i < max; i++){
        if (current[i] !== next[i]) break;
    }
    return {
        updated: next.slice(0, i),
        activated: next.slice(i),
        deactivated: current.slice(i)
    };
}
function extractGuards(records, name, bind, reverse) {
    var guards = flatMapComponents(records, function(def, instance, match, key) {
        var guard = extractGuard(def, name);
        if (guard) return Array.isArray(guard) ? guard.map(function(guard) {
            return bind(guard, instance, match, key);
        }) : bind(guard, instance, match, key);
    });
    return flatten(reverse ? guards.reverse() : guards);
}
function extractGuard(def, key) {
    if (typeof def !== "function") // extend now so that global mixins are applied.
    def = _Vue.extend(def);
    return def.options[key];
}
function extractLeaveGuards(deactivated) {
    return extractGuards(deactivated, "beforeRouteLeave", bindGuard, true);
}
function extractUpdateHooks(updated) {
    return extractGuards(updated, "beforeRouteUpdate", bindGuard);
}
function bindGuard(guard, instance) {
    if (instance) return function boundRouteGuard() {
        return guard.apply(instance, arguments);
    };
}
function extractEnterGuards(activated) {
    return extractGuards(activated, "beforeRouteEnter", function(guard, _, match, key) {
        return bindEnterGuard(guard, match, key);
    });
}
function bindEnterGuard(guard, match, key) {
    return function routeEnterGuard(to, from, next) {
        return guard(to, from, function(cb) {
            if (typeof cb === "function") {
                if (!match.enteredCbs[key]) match.enteredCbs[key] = [];
                match.enteredCbs[key].push(cb);
            }
            next(cb);
        });
    };
}
/*  */ var HTML5History = /*@__PURE__*/ function(History) {
    function HTML5History(router, base) {
        History.call(this, router, base);
        this._startLocation = getLocation(this.base);
    }
    if (History) HTML5History.__proto__ = History;
    HTML5History.prototype = Object.create(History && History.prototype);
    HTML5History.prototype.constructor = HTML5History;
    HTML5History.prototype.setupListeners = function setupListeners() {
        var this$1$1 = this;
        if (this.listeners.length > 0) return;
        var router = this.router;
        var expectScroll = router.options.scrollBehavior;
        var supportsScroll = supportsPushState && expectScroll;
        if (supportsScroll) this.listeners.push(setupScroll());
        var handleRoutingEvent = function() {
            var current = this$1$1.current;
            // Avoiding first `popstate` event dispatched in some browsers but first
            // history route not updated since async guard at the same time.
            var location = getLocation(this$1$1.base);
            if (this$1$1.current === START && location === this$1$1._startLocation) return;
            this$1$1.transitionTo(location, function(route) {
                if (supportsScroll) handleScroll(router, route, current, true);
            });
        };
        window.addEventListener("popstate", handleRoutingEvent);
        this.listeners.push(function() {
            window.removeEventListener("popstate", handleRoutingEvent);
        });
    };
    HTML5History.prototype.go = function go(n) {
        window.history.go(n);
    };
    HTML5History.prototype.push = function push(location, onComplete, onAbort) {
        var this$1$1 = this;
        var ref = this;
        var fromRoute = ref.current;
        this.transitionTo(location, function(route) {
            pushState(cleanPath(this$1$1.base + route.fullPath));
            handleScroll(this$1$1.router, route, fromRoute, false);
            onComplete && onComplete(route);
        }, onAbort);
    };
    HTML5History.prototype.replace = function replace(location, onComplete, onAbort) {
        var this$1$1 = this;
        var ref = this;
        var fromRoute = ref.current;
        this.transitionTo(location, function(route) {
            replaceState(cleanPath(this$1$1.base + route.fullPath));
            handleScroll(this$1$1.router, route, fromRoute, false);
            onComplete && onComplete(route);
        }, onAbort);
    };
    HTML5History.prototype.ensureURL = function ensureURL(push) {
        if (getLocation(this.base) !== this.current.fullPath) {
            var current = cleanPath(this.base + this.current.fullPath);
            push ? pushState(current) : replaceState(current);
        }
    };
    HTML5History.prototype.getCurrentLocation = function getCurrentLocation() {
        return getLocation(this.base);
    };
    return HTML5History;
}(History);
function getLocation(base) {
    var path = window.location.pathname;
    var pathLowerCase = path.toLowerCase();
    var baseLowerCase = base.toLowerCase();
    // base="/a" shouldn't turn path="/app" into "/a/pp"
    // https://github.com/vuejs/vue-router/issues/3555
    // so we ensure the trailing slash in the base
    if (base && (pathLowerCase === baseLowerCase || pathLowerCase.indexOf(cleanPath(baseLowerCase + "/")) === 0)) path = path.slice(base.length);
    return (path || "/") + window.location.search + window.location.hash;
}
/*  */ var HashHistory = /*@__PURE__*/ function(History) {
    function HashHistory(router, base, fallback) {
        History.call(this, router, base);
        // check history fallback deeplinking
        if (fallback && checkFallback(this.base)) return;
        ensureSlash();
    }
    if (History) HashHistory.__proto__ = History;
    HashHistory.prototype = Object.create(History && History.prototype);
    HashHistory.prototype.constructor = HashHistory;
    // this is delayed until the app mounts
    // to avoid the hashchange listener being fired too early
    HashHistory.prototype.setupListeners = function setupListeners() {
        var this$1$1 = this;
        if (this.listeners.length > 0) return;
        var router = this.router;
        var expectScroll = router.options.scrollBehavior;
        var supportsScroll = supportsPushState && expectScroll;
        if (supportsScroll) this.listeners.push(setupScroll());
        var handleRoutingEvent = function() {
            var current = this$1$1.current;
            if (!ensureSlash()) return;
            this$1$1.transitionTo(getHash(), function(route) {
                if (supportsScroll) handleScroll(this$1$1.router, route, current, true);
                if (!supportsPushState) replaceHash(route.fullPath);
            });
        };
        var eventType = supportsPushState ? "popstate" : "hashchange";
        window.addEventListener(eventType, handleRoutingEvent);
        this.listeners.push(function() {
            window.removeEventListener(eventType, handleRoutingEvent);
        });
    };
    HashHistory.prototype.push = function push(location, onComplete, onAbort) {
        var this$1$1 = this;
        var ref = this;
        var fromRoute = ref.current;
        this.transitionTo(location, function(route) {
            pushHash(route.fullPath);
            handleScroll(this$1$1.router, route, fromRoute, false);
            onComplete && onComplete(route);
        }, onAbort);
    };
    HashHistory.prototype.replace = function replace(location, onComplete, onAbort) {
        var this$1$1 = this;
        var ref = this;
        var fromRoute = ref.current;
        this.transitionTo(location, function(route) {
            replaceHash(route.fullPath);
            handleScroll(this$1$1.router, route, fromRoute, false);
            onComplete && onComplete(route);
        }, onAbort);
    };
    HashHistory.prototype.go = function go(n) {
        window.history.go(n);
    };
    HashHistory.prototype.ensureURL = function ensureURL(push) {
        var current = this.current.fullPath;
        if (getHash() !== current) push ? pushHash(current) : replaceHash(current);
    };
    HashHistory.prototype.getCurrentLocation = function getCurrentLocation() {
        return getHash();
    };
    return HashHistory;
}(History);
function checkFallback(base) {
    var location = getLocation(base);
    if (!/^\/#/.test(location)) {
        window.location.replace(cleanPath(base + "/#" + location));
        return true;
    }
}
function ensureSlash() {
    var path = getHash();
    if (path.charAt(0) === "/") return true;
    replaceHash("/" + path);
    return false;
}
function getHash() {
    // We can't use window.location.hash here because it's not
    // consistent across browsers - Firefox will pre-decode it!
    var href = window.location.href;
    var index = href.indexOf("#");
    // empty path
    if (index < 0) return "";
    href = href.slice(index + 1);
    return href;
}
function getUrl(path) {
    var href = window.location.href;
    var i = href.indexOf("#");
    var base = i >= 0 ? href.slice(0, i) : href;
    return base + "#" + path;
}
function pushHash(path) {
    if (supportsPushState) pushState(getUrl(path));
    else window.location.hash = path;
}
function replaceHash(path) {
    if (supportsPushState) replaceState(getUrl(path));
    else window.location.replace(getUrl(path));
}
/*  */ var AbstractHistory = /*@__PURE__*/ function(History) {
    function AbstractHistory(router, base) {
        History.call(this, router, base);
        this.stack = [];
        this.index = -1;
    }
    if (History) AbstractHistory.__proto__ = History;
    AbstractHistory.prototype = Object.create(History && History.prototype);
    AbstractHistory.prototype.constructor = AbstractHistory;
    AbstractHistory.prototype.push = function push(location, onComplete, onAbort) {
        var this$1$1 = this;
        this.transitionTo(location, function(route) {
            this$1$1.stack = this$1$1.stack.slice(0, this$1$1.index + 1).concat(route);
            this$1$1.index++;
            onComplete && onComplete(route);
        }, onAbort);
    };
    AbstractHistory.prototype.replace = function replace(location, onComplete, onAbort) {
        var this$1$1 = this;
        this.transitionTo(location, function(route) {
            this$1$1.stack = this$1$1.stack.slice(0, this$1$1.index).concat(route);
            onComplete && onComplete(route);
        }, onAbort);
    };
    AbstractHistory.prototype.go = function go(n) {
        var this$1$1 = this;
        var targetIndex = this.index + n;
        if (targetIndex < 0 || targetIndex >= this.stack.length) return;
        var route = this.stack[targetIndex];
        this.confirmTransition(route, function() {
            var prev = this$1$1.current;
            this$1$1.index = targetIndex;
            this$1$1.updateRoute(route);
            this$1$1.router.afterHooks.forEach(function(hook) {
                hook && hook(route, prev);
            });
        }, function(err) {
            if (isNavigationFailure(err, NavigationFailureType.duplicated)) this$1$1.index = targetIndex;
        });
    };
    AbstractHistory.prototype.getCurrentLocation = function getCurrentLocation() {
        var current = this.stack[this.stack.length - 1];
        return current ? current.fullPath : "/";
    };
    AbstractHistory.prototype.ensureURL = function ensureURL() {
    // noop
    };
    return AbstractHistory;
}(History);
/*  */ var VueRouter = function VueRouter(options) {
    if (options === void 0) options = {};
    this.app = null;
    this.apps = [];
    this.options = options;
    this.beforeHooks = [];
    this.resolveHooks = [];
    this.afterHooks = [];
    this.matcher = createMatcher(options.routes || [], this);
    var mode = options.mode || "hash";
    this.fallback = mode === "history" && !supportsPushState && options.fallback !== false;
    if (this.fallback) mode = "hash";
    if (!inBrowser) mode = "abstract";
    this.mode = mode;
    switch(mode){
        case "history":
            this.history = new HTML5History(this, options.base);
            break;
        case "hash":
            this.history = new HashHistory(this, options.base, this.fallback);
            break;
        case "abstract":
            this.history = new AbstractHistory(this, options.base);
            break;
        default:
    }
};
var prototypeAccessors = {
    currentRoute: {
        configurable: true
    }
};
VueRouter.prototype.match = function match(raw, current, redirectedFrom) {
    return this.matcher.match(raw, current, redirectedFrom);
};
prototypeAccessors.currentRoute.get = function() {
    return this.history && this.history.current;
};
VueRouter.prototype.init = function init(app /* Vue component instance */ ) {
    var this$1$1 = this;
    this.apps.push(app);
    // set up app destroyed handler
    // https://github.com/vuejs/vue-router/issues/2639
    app.$once("hook:destroyed", function() {
        // clean out app from this.apps array once destroyed
        var index = this$1$1.apps.indexOf(app);
        if (index > -1) this$1$1.apps.splice(index, 1);
        // ensure we still have a main app or null if no apps
        // we do not release the router so it can be reused
        if (this$1$1.app === app) this$1$1.app = this$1$1.apps[0] || null;
        if (!this$1$1.app) this$1$1.history.teardown();
    });
    // main app previously initialized
    // return as we don't need to set up new history listener
    if (this.app) return;
    this.app = app;
    var history = this.history;
    if (history instanceof HTML5History || history instanceof HashHistory) {
        var handleInitialScroll = function(routeOrError) {
            var from = history.current;
            var expectScroll = this$1$1.options.scrollBehavior;
            var supportsScroll = supportsPushState && expectScroll;
            if (supportsScroll && "fullPath" in routeOrError) handleScroll(this$1$1, routeOrError, from, false);
        };
        var setupListeners = function(routeOrError) {
            history.setupListeners();
            handleInitialScroll(routeOrError);
        };
        history.transitionTo(history.getCurrentLocation(), setupListeners, setupListeners);
    }
    history.listen(function(route) {
        this$1$1.apps.forEach(function(app) {
            app._route = route;
        });
    });
};
VueRouter.prototype.beforeEach = function beforeEach(fn) {
    return registerHook(this.beforeHooks, fn);
};
VueRouter.prototype.beforeResolve = function beforeResolve(fn) {
    return registerHook(this.resolveHooks, fn);
};
VueRouter.prototype.afterEach = function afterEach(fn) {
    return registerHook(this.afterHooks, fn);
};
VueRouter.prototype.onReady = function onReady(cb, errorCb) {
    this.history.onReady(cb, errorCb);
};
VueRouter.prototype.onError = function onError(errorCb) {
    this.history.onError(errorCb);
};
VueRouter.prototype.push = function push(location, onComplete, onAbort) {
    var this$1$1 = this;
    // $flow-disable-line
    if (!onComplete && !onAbort && typeof Promise !== "undefined") return new Promise(function(resolve, reject) {
        this$1$1.history.push(location, resolve, reject);
    });
    else this.history.push(location, onComplete, onAbort);
};
VueRouter.prototype.replace = function replace(location, onComplete, onAbort) {
    var this$1$1 = this;
    // $flow-disable-line
    if (!onComplete && !onAbort && typeof Promise !== "undefined") return new Promise(function(resolve, reject) {
        this$1$1.history.replace(location, resolve, reject);
    });
    else this.history.replace(location, onComplete, onAbort);
};
VueRouter.prototype.go = function go(n) {
    this.history.go(n);
};
VueRouter.prototype.back = function back() {
    this.go(-1);
};
VueRouter.prototype.forward = function forward() {
    this.go(1);
};
VueRouter.prototype.getMatchedComponents = function getMatchedComponents(to) {
    var route = to ? to.matched ? to : this.resolve(to).route : this.currentRoute;
    if (!route) return [];
    return [].concat.apply([], route.matched.map(function(m) {
        return Object.keys(m.components).map(function(key) {
            return m.components[key];
        });
    }));
};
VueRouter.prototype.resolve = function resolve(to, current, append) {
    current = current || this.history.current;
    var location = normalizeLocation(to, current, append, this);
    var route = this.match(location, current);
    var fullPath = route.redirectedFrom || route.fullPath;
    var base = this.history.base;
    var href = createHref(base, fullPath, this.mode);
    return {
        location: location,
        route: route,
        href: href,
        // for backwards compat
        normalizedTo: location,
        resolved: route
    };
};
VueRouter.prototype.getRoutes = function getRoutes() {
    return this.matcher.getRoutes();
};
VueRouter.prototype.addRoute = function addRoute(parentOrRoute, route) {
    this.matcher.addRoute(parentOrRoute, route);
    if (this.history.current !== START) this.history.transitionTo(this.history.getCurrentLocation());
};
VueRouter.prototype.addRoutes = function addRoutes(routes) {
    this.matcher.addRoutes(routes);
    if (this.history.current !== START) this.history.transitionTo(this.history.getCurrentLocation());
};
Object.defineProperties(VueRouter.prototype, prototypeAccessors);
var VueRouter$1 = VueRouter;
function registerHook(list, fn) {
    list.push(fn);
    return function() {
        var i = list.indexOf(fn);
        if (i > -1) list.splice(i, 1);
    };
}
function createHref(base, fullPath, mode) {
    var path = mode === "hash" ? "#" + fullPath : fullPath;
    return base ? cleanPath(base + "/" + path) : path;
}
// We cannot remove this as it would be a breaking change
VueRouter.install = install;
VueRouter.version = "3.6.5";
VueRouter.isNavigationFailure = isNavigationFailure;
VueRouter.NavigationFailureType = NavigationFailureType;
VueRouter.START_LOCATION = START;
if (inBrowser && window.Vue) window.Vue.use(VueRouter);
var version = "3.6.5";

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"9S4FX":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./LoginView.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./LoginView.vue").render;
    script.staticRenderFns = require("template:./LoginView.vue").staticRenderFns;
    script._scopeId = "data-v-416312";
    script.__cssModules = require("style:./LoginView.vue").default;
    require("custom:./LoginView.vue").default(script);
    script.__scopeId = "data-v-416312";
    script.__file = "LoginView.vue";
};
initialize();
exports.default = script;

},{"script:./LoginView.vue":"79vsd","template:./LoginView.vue":"b2abE","style:./LoginView.vue":"1Z8sA","custom:./LoginView.vue":"178wk","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"79vsd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
var _vuex = require("vuex");
var _logoJpg = require("../../assets/img/logo.jpg");
var _logoJpgDefault = parcelHelpers.interopDefault(_logoJpg);
var _passwordForgotVue = require("./password-forgot.vue");
var _passwordForgotVueDefault = parcelHelpers.interopDefault(_passwordForgotVue);
// import logoSvg from "../assets/logo.jpg";
var scriptExports = (0, _vueDefault.default).extend({
    name: "Login",
    components: {
        ForGotPassword: (0, _passwordForgotVueDefault.default)
    },
    data () {
        return {
            forgotPassword: false,
            logoSvg: (0, _logoJpgDefault.default),
            showPassword: false,
            showError: false,
            hide: true,
            credential: {
                userName: "",
                password: ""
            }
        };
    },
    created () {},
    mounted () {},
    methods: {
        ...(0, _vuex.mapActions)("logingStore", [
            "logUser",
            "storeCookie"
        ]),
        async login () {
            this.hide = false;
            const logged = await this.logUser(this.credential);
            this.showError = !logged;
            if (logged) {
                this.storeCookie(this.$cookie);
                this.$router.push("/home");
            }
        }
    },
    computed: {
        ...(0, _vuex.mapState)("logingStore", [
            "incorrect"
        ])
    },
    watch: {
        credential: {
            handler () {
                this.hide = true;
            },
            deep: true
        }
    }
});
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"vue":"kjivF","vuex":"ccMRg","../../assets/img/logo.jpg":"aR41t","./password-forgot.vue":"aixmw","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"aR41t":[function(require,module,exports) {
module.exports = require("./helpers/bundle-url").getBundleURL("4wOkc") + require("./helpers/bundle-manifest").resolve("dpak1");

},{"./helpers/bundle-url":"jkqJ4","./helpers/bundle-manifest":"8Y9me"}],"jkqJ4":[function(require,module,exports) {
"use strict";
var bundleURL = {};
function getBundleURLCached(id) {
    var value = bundleURL[id];
    if (!value) {
        value = getBundleURL();
        bundleURL[id] = value;
    }
    return value;
}
function getBundleURL() {
    try {
        throw new Error();
    } catch (err) {
        var matches = ("" + err.stack).match(/(https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/[^)\n]+/g);
        if (matches) // The first two stack frames will be this function and getBundleURLCached.
        // Use the 3rd one, which will be a runtime in the original bundle.
        return getBaseURL(matches[2]);
    }
    return "/";
}
function getBaseURL(url) {
    return ("" + url).replace(/^((?:https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/.+)\/[^/]+$/, "$1") + "/";
} // TODO: Replace uses with `new URL(url).origin` when ie11 is no longer supported.
function getOrigin(url) {
    var matches = ("" + url).match(/(https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/[^/]+/);
    if (!matches) throw new Error("Origin not found");
    return matches[0];
}
exports.getBundleURL = getBundleURLCached;
exports.getBaseURL = getBaseURL;
exports.getOrigin = getOrigin;

},{}],"aixmw":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./password-forgot.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./password-forgot.vue").render;
    script.staticRenderFns = require("template:./password-forgot.vue").staticRenderFns;
    script._scopeId = "data-v-92f939";
    require("custom:./password-forgot.vue").default(script);
    script.__scopeId = "data-v-92f939";
    script.__file = "password-forgot.vue";
};
initialize();
exports.default = script;

},{"script:./password-forgot.vue":"jQ8PU","template:./password-forgot.vue":"gKCde","custom:./password-forgot.vue":"ekTpw","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"jQ8PU":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "Dialog",
    props: {
        dialog: {
            type: Boolean,
            default: ()=>false
        }
    },
    methods: {
        close () {
            this.$emit("close");
        }
    }
};
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"gKCde":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("div", {
        staticClass: "text-center"
    }, [
        _c("v-dialog", {
            attrs: {
                "transition": "dialog-top-transition",
                "persistent": "",
                "width": "500"
            },
            model: {
                value: _vm.dialog,
                callback: function($$v) {
                    _vm.dialog = $$v;
                },
                expression: "dialog"
            }
        }, [
            _c("v-card", [
                _c("v-card-title", {
                    staticClass: "text-h5 lighten-2"
                }, [
                    _vm._v("\n        Mot de passe oubli\xe9 ?\n      ")
                ]),
                _vm._v(" "),
                _c("v-card-text", [
                    _vm._v("\n        Veuillez contactez votre administrateur, pour changer votre mot de\n        passe !\n      ")
                ]),
                _vm._v(" "),
                _c("v-divider"),
                _vm._v(" "),
                _c("v-card-actions", [
                    _c("v-spacer"),
                    _vm._v(" "),
                    _c("v-btn", {
                        attrs: {
                            "color": "primary",
                            "text": ""
                        },
                        on: {
                            "click": _vm.close
                        }
                    }, [
                        _vm._v("\n          OK\n        ")
                    ])
                ], 1)
            ], 1)
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"ekTpw":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"b2abE":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("v-container", {
        staticClass: "loginAppContainer",
        attrs: {
            "fluid": ""
        }
    }, [
        _c("for-got-password", {
            attrs: {
                "dialog": _vm.forgotPassword
            },
            on: {
                "close": function() {
                    return _vm.forgotPassword = false;
                }
            }
        }),
        _vm._v(" "),
        _c("form", {
            on: {
                "submit": function($event) {
                    $event.preventDefault();
                    return _vm.login.apply(null, arguments);
                }
            }
        }, [
            _c("v-card", {
                staticClass: "loginCard",
                attrs: {
                    "elevation": "4"
                }
            }, [
                _c("v-card-title", {
                    staticClass: "loginCardTitle"
                }, [
                    _c("div", {
                        staticClass: "logoImg"
                    }, [
                        _c("div", {
                            staticClass: "logo"
                        }, [
                            _c("img", {
                                staticClass: "img",
                                attrs: {
                                    "alt": "logo",
                                    "src": _vm.logoSvg
                                }
                            })
                        ])
                    ]),
                    _vm._v(" "),
                    _c("div", {
                        staticClass: "description"
                    }, [
                        _vm._v("\n          Consultez toutes les donn\xe9es de vos b\xe2timents connect\xe9s.\n        ")
                    ])
                ]),
                _vm._v(" "),
                _c("v-card-text", {
                    staticClass: "loginCardContent"
                }, [
                    _c("v-alert", {
                        directives: [
                            {
                                name: "show",
                                rawName: "v-show",
                                value: !_vm.hide && _vm.showError,
                                expression: "!hide && showError"
                            }
                        ],
                        attrs: {
                            "dense": "",
                            "outlined": "",
                            "type": "error"
                        }
                    }, [
                        _vm._v("\n          incorrect login and/or password !\n        ")
                    ]),
                    _vm._v(" "),
                    _c("v-text-field", {
                        attrs: {
                            "outlined": "",
                            "height": "35",
                            "autocomplete": "username",
                            "dense": "",
                            "label": "Login",
                            "required": ""
                        },
                        model: {
                            value: _vm.credential.userName,
                            callback: function($$v) {
                                _vm.$set(_vm.credential, "userName", $$v);
                            },
                            expression: "credential.userName"
                        }
                    }),
                    _vm._v(" "),
                    _c("v-text-field", {
                        staticClass: "input-group--focused",
                        attrs: {
                            "outlined": "",
                            "height": "35",
                            "dense": "",
                            "label": "Password",
                            "autocomplete": "current-password",
                            "required": "",
                            "append-icon": _vm.showPassword ? "mdi-eye" : "mdi-eye-off",
                            "type": _vm.showPassword ? "text" : "password"
                        },
                        on: {
                            "click:append": function($event) {
                                _vm.showPassword = !_vm.showPassword;
                            }
                        },
                        model: {
                            value: _vm.credential.password,
                            callback: function($$v) {
                                _vm.$set(_vm.credential, "password", $$v);
                            },
                            expression: "credential.password"
                        }
                    }),
                    _vm._v(" "),
                    _c("v-btn", {
                        attrs: {
                            "x-small": "",
                            "text": ""
                        },
                        on: {
                            "click": function($event) {
                                _vm.forgotPassword = true;
                            }
                        }
                    }, [
                        _vm._v(" mot de passe oubli\xe9 ? ")
                    ])
                ], 1),
                _vm._v(" "),
                _c("v-card-actions", {
                    staticClass: "loginCardAction"
                }, [
                    _c("v-btn", {
                        attrs: {
                            "dark": "",
                            "type": "submit"
                        }
                    }, [
                        _vm._v(" Connexion ")
                    ])
                ], 1)
            ], 1)
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"1Z8sA":[function() {},{}],"178wk":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"cYsi3":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./HomeLayout.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./HomeLayout.vue").render;
    script.staticRenderFns = require("template:./HomeLayout.vue").staticRenderFns;
    script._scopeId = "data-v-522496";
    script.__cssModules = require("style:./HomeLayout.vue").default;
    require("custom:./HomeLayout.vue").default(script);
    script.__scopeId = "data-v-522496";
    script.__file = "HomeLayout.vue";
};
initialize();
exports.default = script;

},{"script:./HomeLayout.vue":"hDOHl","template:./HomeLayout.vue":"b7vMb","style:./HomeLayout.vue":"3GQRE","custom:./HomeLayout.vue":"aPGjP","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"hDOHl":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _vuex = require("vuex");
var _navVue = require("../components/nav.vue");
var _navVueDefault = parcelHelpers.interopDefault(_navVue);
var _selectVue = require("../components/select.vue");
var _selectVueDefault = parcelHelpers.interopDefault(_selectVue);
var scriptExports = {
    components: {
        NavBar: (0, _navVueDefault.default),
        SelectComponent: (0, _selectVueDefault.default)
    },
    async mounted () {
        await this.init();
    },
    methods: {
        ...(0, _vuex.mapActions)("appDataStore", [
            "getPortofolios",
            "getApps",
            "getBos",
            "getUserInfo",
            "selectSpace",
            "getFavoriteApps", 
        ]),
        init () {
            return Promise.all([
                this.getPortofolios(),
                this.getUserInfo(), 
            ]);
        },
        closeSelect () {
            const ref = this.$refs["select-component"];
            if (ref) ref.close();
        },
        changeApps (data) {
            console.log("action data : ", data);
            this.selectSpace(data);
        }
    },
    computed: {
        ...(0, _vuex.mapState)("appDataStore", [
            "appsDisplayed",
            "userInfo",
            "portofolios"
        ]),
        isMobile () {
            const breakpoint = this.$vuetify.breakpoint.name;
            if ([
                "xs",
                "sm"
            ].indexOf(breakpoint) !== -1) return true;
            return false;
        }
    }
};
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"vuex":"ccMRg","../components/nav.vue":"hAOMv","../components/select.vue":"3sDRL","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"hAOMv":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./nav.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./nav.vue").render;
    script.staticRenderFns = require("template:./nav.vue").staticRenderFns;
    script._scopeId = "data-v-a8fd93";
    require("custom:./nav.vue").default(script);
    script.__scopeId = "data-v-a8fd93";
    script.__file = "nav.vue";
};
initialize();
exports.default = script;

},{"script:./nav.vue":"kBhE7","template:./nav.vue":"1JInC","custom:./nav.vue":"99IAB","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"kBhE7":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _vuex = require("vuex");
var _logoJpg = require("../../assets/img/logo.jpg");
var _logoJpgDefault = parcelHelpers.interopDefault(_logoJpg);
var _navVue = require("./mobile/nav.vue");
var _navVueDefault = parcelHelpers.interopDefault(_navVue);
var scriptExports = {
    props: {
        isMobile: {
            type: Boolean,
            default: false
        }
    },
    components: {
        "mobile-nav": (0, _navVueDefault.default)
    },
    async mounted () {
        await Promise.all([
            this.getPortofolios(),
            this.getUserInfo()
        ]);
        this.setLocalAppSelected();
    // this.setApps();
    },
    data () {
        this.homeApp = {
            path: "Home",
            name: "toutes les applications"
        };
        return {
            logoSvg: (0, _logoJpgDefault.default),
            localAppSelected: this.homeApp,
            navBarMainMenuShow: false,
            navBarAppMenuShow: false,
            apps: [],
            mainbuttons: [
                {
                    name: "",
                    action: ()=>console.log("click Param\xe8tres")
                },
                {
                    name: "D\xe9connexion",
                    action: ()=>this.logOut()
                }, 
            ]
        };
    },
    methods: {
        ...(0, _vuex.mapActions)("logingStore", [
            "clearLocalStorage"
        ]),
        ...(0, _vuex.mapActions)("appDataStore", [
            "getApps",
            "getUserInfo",
            "getPortofolios"
        ]),
        clickMainMenu () {
            this.navBarMainMenuShow = !this.navBarMainMenuShow;
            this.navBarAppMenuShow = false;
        },
        clickAppMenu () {
            this.navBarMainMenuShow = false;
            this.navBarAppMenuShow = !this.navBarAppMenuShow;
        },
        logOut () {
            this.clearLocalStorage();
            this.$router.push({
                name: "Login"
            });
        },
        goToHome (event) {
            if (event.ctrlKey) {
                let routeData = this.$router.resolve({
                    name: "Home"
                });
                window.open(routeData.href, "_blank");
            } else this.$router.push({
                name: "Home"
            }).catch(()=>{});
            this.navBarAppMenuShow = false;
        },
        goToApp (item, event) {
            console.log("item is my app", item);
            if (item.isExternalApp) {
                window.open(item.link, "_blank");
                return;
            }
            if (event.ctrlKey) {
                let routeData = this.$router.resolve({
                    name: "App",
                    query: {
                        app: item.name
                    }
                });
                window.open(routeData.href, "_blank");
            } else this.$router.push({
                name: "App",
                query: {
                    app: item.name
                }
            }).catch((error)=>{});
            this.navBarAppMenuShow = false;
        },
        setLocalAppSelected () {
            this.localAppSelected = this.appSelected || this.homeApp;
        }
    },
    computed: {
        ...(0, _vuex.mapState)("appDataStore", [
            "appsDisplayed",
            "userInfo",
            "appSelected",
            "portofolios", 
        ]),
        mainMenuTabIndexComputed () {
            return this.navBarMainMenuShow ? "" : "-1";
        },
        appMenuTabIndexComputed () {
            return this.navBarAppMenuShow ? "" : "-1";
        }
    },
    watch: {
        appSelected () {
            this.setLocalAppSelected();
        }
    }
};
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"vuex":"ccMRg","../../assets/img/logo.jpg":"aR41t","./mobile/nav.vue":"kxPyB","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"kxPyB":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./nav.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./nav.vue").render;
    script.staticRenderFns = require("template:./nav.vue").staticRenderFns;
    script._scopeId = "data-v-b5d033";
    script.__cssModules = require("style:./nav.vue").default;
    require("custom:./nav.vue").default(script);
    script.__scopeId = "data-v-b5d033";
    script.__file = "nav.vue";
};
initialize();
exports.default = script;

},{"script:./nav.vue":"8ECns","template:./nav.vue":"7xUCU","style:./nav.vue":"dfOhy","custom:./nav.vue":"7Qjc3","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"8ECns":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
// const logo = require("../../../assets/img/favicon.png");
var scriptExports = {
    props: {
        logoSvg: {},
        userInfo: {},
        apps: {}
    },
    data: ()=>({
            drawer: false,
            group: null
        }),
    methods: {
        logOut () {
            this.$emit("logout");
        },
        goToHome (event) {
            this.$emit("home", event);
        },
        goToApp (item, event) {
            this.$emit("goToApp", {
                item,
                event
            });
        }
    },
    watch: {
        group () {
            this.drawer = false;
        }
    }
};
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"7xUCU":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("div", {
        staticClass: "mobile-nav-container",
        class: {
            "enabled": _vm.drawer
        }
    }, [
        _c("div", {
            staticClass: "navPickerApp",
            on: {
                "click": function($event) {
                    $event.stopPropagation();
                    _vm.drawer = !_vm.drawer;
                }
            }
        }, [
            _vm._m(0)
        ]),
        _vm._v(" "),
        _c("v-navigation-drawer", {
            attrs: {
                "absolute": "",
                "temporary": ""
            },
            scopedSlots: _vm._u([
                {
                    key: "append",
                    fn: function() {
                        return [
                            _c("div", {
                                staticStyle: {
                                    "height": "60px"
                                }
                            }, [
                                _c("v-btn", {
                                    staticStyle: {
                                        "height": "100%"
                                    },
                                    attrs: {
                                        "block": "",
                                        "color": "error"
                                    },
                                    on: {
                                        "click": _vm.logOut
                                    }
                                }, [
                                    _c("v-icon", {
                                        attrs: {
                                            "left": ""
                                        }
                                    }, [
                                        _vm._v("\n            mdi-logout\n          ")
                                    ]),
                                    _vm._v("\n          D\xe9connexion\n        ")
                                ], 1)
                            ], 1)
                        ];
                    },
                    proxy: true
                }
            ]),
            model: {
                value: _vm.drawer,
                callback: function($$v) {
                    _vm.drawer = $$v;
                },
                expression: "drawer"
            }
        }, [
            _c("v-list-item", [
                _c("v-list-item-content", [
                    _c("v-list-item-title", {
                        staticClass: "text-h6"
                    }, [
                        _c("v-avatar", {
                            attrs: {
                                "size": "36",
                                "color": "grey"
                            }
                        }, [
                            _c("v-icon", {
                                attrs: {
                                    "dark": ""
                                }
                            }, [
                                _vm._v("\n              mdi-account\n            ")
                            ])
                        ], 1),
                        _vm._v("\n          " + _vm._s(_vm.userInfo && _vm.userInfo.name) + "\n        ")
                    ], 1),
                    _vm._v(" "),
                    _c("v-list-item-subtitle", [
                        _vm._v("\n          " + _vm._s(_vm.userInfo && _vm.userInfo.email) + "\n        ")
                    ])
                ], 1)
            ], 1),
            _vm._v(" "),
            _c("v-divider"),
            _vm._v(" "),
            _c("v-list", {
                attrs: {
                    "nav": "",
                    "rounded": ""
                }
            }, [
                _c("v-list-item", {
                    attrs: {
                        "link": ""
                    },
                    on: {
                        "click": _vm.goToHome
                    }
                }, [
                    _c("v-list-item-icon", [
                        _c("v-icon", [
                            _vm._v("mdi-domain")
                        ])
                    ], 1),
                    _vm._v(" "),
                    _c("v-list-item-content", [
                        _c("v-list-item-title", [
                            _vm._v("Accueil")
                        ])
                    ], 1)
                ], 1),
                _vm._v(" "),
                _vm._l(_vm.apps, function(item) {
                    return _c("v-list-item", {
                        attrs: {
                            "link": ""
                        },
                        on: {
                            "click": function($event) {
                                return _vm.goToApp(item, $event);
                            }
                        }
                    }, [
                        _c("v-list-item-icon", [
                            _c("v-icon", [
                                _vm._v(_vm._s(item.icon || "mdi-domain"))
                            ])
                        ], 1),
                        _vm._v(" "),
                        _c("v-list-item-content", [
                            _c("v-list-item-title", [
                                _vm._v(_vm._s(item.name))
                            ])
                        ], 1)
                    ], 1);
                })
            ], 2)
        ], 1)
    ], 1);
};
var staticRenderFns = [
    function() {
        var _vm = this;
        var _h = _vm.$createElement;
        var _c = _vm._self._c || _h;
        return _c("div", {
            staticClass: "navPickerApp-container"
        }, [
            _c("div", {
                staticClass: "navPickerApp-mainMenu"
            }, [
                _c("button", {
                    staticClass: "navPickerApp-mainMenu-button"
                }, [
                    _c("span"),
                    _vm._v(" "),
                    _c("span"),
                    _vm._v(" "),
                    _c("span")
                ])
            ])
        ]);
    }
];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"dfOhy":[function() {},{}],"7Qjc3":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"1JInC":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("div", [
        _c("mobile-nav", {
            directives: [
                {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.isMobile,
                    expression: "isMobile"
                }
            ],
            staticStyle: {
                "width": "100%",
                "height": "100%"
            },
            attrs: {
                "logoSvg": _vm.logoSvg,
                "userInfo": _vm.userInfo,
                "apps": _vm.appsDisplayed
            },
            on: {
                "logout": _vm.logOut,
                "home": _vm.goToHome,
                "goToApp": function(ref) {
                    var item = ref.item;
                    var event = ref.event;
                    return _vm.goToApp(item, event);
                }
            }
        }),
        _vm._v(" "),
        _c("nav", {
            directives: [
                {
                    name: "show",
                    rawName: "v-show",
                    value: !_vm.isMobile,
                    expression: "!isMobile"
                }
            ]
        }, [
            _c("div", {
                staticClass: "navPickerApp"
            }, [
                _c("div", {
                    staticClass: "navPickerApp-container"
                }, [
                    _c("div", {
                        staticClass: "navPickerApp-mainMenu"
                    }, [
                        _c("button", {
                            staticClass: "navPickerApp-mainMenu-button",
                            class: {
                                actived: _vm.navBarMainMenuShow
                            },
                            on: {
                                "click": function($event) {
                                    return _vm.clickMainMenu();
                                }
                            }
                        }, [
                            _c("span"),
                            _vm._v(" "),
                            _c("span"),
                            _vm._v(" "),
                            _c("span")
                        ]),
                        _vm._v(" "),
                        _c("div", {
                            staticClass: "navPickerApp-mainMenu-content",
                            class: {
                                actived: _vm.navBarMainMenuShow
                            }
                        }, [
                            _c("div", {
                                staticClass: "navPickerApp-mainMenu-content-profil"
                            }, [
                                _c("div", {
                                    staticClass: "navPickerApp-mainMenu-content-profil-name"
                                }, [
                                    _vm._v("\n                " + _vm._s(_vm.userInfo && _vm.userInfo.name) + "\n              ")
                                ]),
                                _vm._v(" "),
                                _c("div", {
                                    staticClass: "navPickerApp-mainMenu-content-profil-role"
                                }, [
                                    _vm._v("\n                " + _vm._s(_vm.userInfo && _vm.userInfo.email) + "\n              ")
                                ])
                            ]),
                            _vm._v(" "),
                            _c("div", {
                                staticClass: "navPickerApp-mainMenu-content-buttonContainer"
                            }, _vm._l(_vm.mainbuttons, function(btn) {
                                return _c("button", {
                                    staticClass: "navPickerApp-mainMenu-content-buttonContainer-button",
                                    attrs: {
                                        "tabindex": _vm.mainMenuTabIndexComputed
                                    },
                                    on: {
                                        "click": btn.action
                                    }
                                }, [
                                    _c("div", {
                                        staticClass: "navPickerApp-mainMenu-content-buttonContainer-button-icon"
                                    }),
                                    _vm._v(" "),
                                    _c("div", {
                                        staticClass: "navPickerApp-mainMenu-content-buttonContainer-button-title"
                                    }, [
                                        _vm._v("\n                  " + _vm._s(btn.name) + "\n                ")
                                    ])
                                ]);
                            }), 0)
                        ])
                    ]),
                    _vm._v(" "),
                    _c("div", {
                        staticClass: "navPickerApp-companyLogo"
                    }, [
                        _c("img", {
                            attrs: {
                                "src": _vm.logoSvg
                            }
                        })
                    ]),
                    _vm._v(" "),
                    _c("div", {
                        staticClass: "navPickerApp-appMenu"
                    }, [
                        _c("button", {
                            staticClass: "navPickerApp-appMenu-button",
                            class: {
                                actived: _vm.navBarAppMenuShow
                            },
                            on: {
                                "click": function($event) {
                                    return _vm.clickAppMenu();
                                }
                            }
                        }, [
                            _c("div", {
                                staticClass: "buttonLabel"
                            }, [
                                _vm._v("application")
                            ]),
                            _vm._v(" "),
                            _c("div", {
                                staticClass: "navPickerApp-appMenu-iconContainer"
                            }, [
                                _c("v-icon", [
                                    _vm._v(_vm._s(_vm.localAppSelected.icon || "mdi-domain"))
                                ])
                            ], 1),
                            _vm._v(" "),
                            _c("div", {
                                staticClass: "navPickerApp-appMenu-title"
                            }, [
                                _vm._v("\n              " + _vm._s(_vm.localAppSelected.name) + "\n            ")
                            ])
                        ]),
                        _vm._v(" "),
                        _c("div", {
                            staticClass: "navPickerApp-appMenu-content",
                            class: {
                                actived: _vm.navBarAppMenuShow
                            }
                        }, [
                            _c("button", {
                                staticClass: "navPickerApp-appMenu-content-app",
                                attrs: {
                                    "tabindex": _vm.appMenuTabIndexComputed
                                },
                                on: {
                                    "click": _vm.goToHome
                                }
                            }, [
                                _c("div", {
                                    staticClass: "navPickerApp-appMenu-content-app-iconContainer"
                                }, [
                                    _c("span", {
                                        staticClass: "material-icons"
                                    }, [
                                        _vm._v("\n                  " + _vm._s(_vm.homeApp.icon || "location_city") + "\n                ")
                                    ])
                                ]),
                                _vm._v(" "),
                                _c("div", {
                                    staticClass: "navPickerApp-appMenu-content-app-title"
                                }, [
                                    _vm._v("\n                " + _vm._s(_vm.homeApp.name) + "\n              ")
                                ])
                            ]),
                            _vm._v(" "),
                            _vm._l(_vm.appsDisplayed, function(app) {
                                return _c("button", {
                                    staticClass: "navPickerApp-appMenu-content-app",
                                    attrs: {
                                        "tabindex": _vm.appMenuTabIndexComputed
                                    },
                                    on: {
                                        "click": function($event) {
                                            return _vm.goToApp(app, $event);
                                        }
                                    }
                                }, [
                                    _c("div", {
                                        staticClass: "navPickerApp-appMenu-content-app-iconContainer"
                                    }, [
                                        _c("v-icon", [
                                            _vm._v(_vm._s(app.icon || "mdi-domain"))
                                        ])
                                    ], 1),
                                    _vm._v(" "),
                                    _c("div", {
                                        staticClass: "navPickerApp-appMenu-content-app-title"
                                    }, [
                                        _vm._v("\n                " + _vm._s(app.name) + "\n              ")
                                    ])
                                ]);
                            })
                        ], 2)
                    ])
                ])
            ])
        ])
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"99IAB":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"3sDRL":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./select.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./select.vue").render;
    script.staticRenderFns = require("template:./select.vue").staticRenderFns;
    script._scopeId = "data-v-76451a";
    script.__cssModules = require("style:./select.vue").default;
    require("custom:./select.vue").default(script);
    script.__scopeId = "data-v-76451a";
    script.__file = "select.vue";
};
initialize();
exports.default = script;

},{"script:./select.vue":"kuqyx","template:./select.vue":"jpEO9","style:./select.vue":"i9XuU","custom:./select.vue":"kIyXj","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"kuqyx":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _appDataStore = require("../store/appDataStore");
var _vuex = require("vuex");
var _globalComponents = require("../../global-components");
var scriptExports = {
    components: {
        SpaceSelector: (0, _globalComponents.SpaceSelector)
    },
    props: {
        portofolios: {},
        isMobile: {
            type: Boolean,
            default: false
        }
    },
    data () {
        // this.default = {
        //   name: "Patrimoine",
        //   id: "patrimoine",
        // };
        this.TYPES = {
            portofolio: "portofolio",
            building: "building"
        };
        return {
            // data: [this.default],
            // selected: this.default.id,
            openSpaceSelector: false,
            selected: null,
            selectedZone: {
                parents: []
            }
        };
    },
    mounted () {
    // this.selected = this.default.id;
    },
    methods: {
        selectedChanged (val) {
        // console.log(val);
        },
        async onSpaceSelectOpen (item) {
            if (!item) return this.portofolios.map((portofolio)=>({
                    name: portofolio.name,
                    categories: portofolio.buildings,
                    staticId: portofolio.id,
                    dynamicId: 0,
                    type: this.TYPES.portofolio
                }));
            if (item.type === this.TYPES.portofolio) return (item.categories || []).map((building)=>{
                return {
                    name: building.name,
                    id: building.id,
                    categories: [],
                    staticId: building.id,
                    dynamicId: 0,
                    type: this.TYPES.building
                };
            });
            return [];
        },
        getSelectedItem (item) {
            console.log("action salut hihihih", item);
            this.$store.commit(`appDataStore/${(0, _appDataStore.SELECT_PORTOFOLIO)}`, item);
            this.selectedZone = item;
            let portofolioId;
            let buildingId;
            const realItem = this.getInfos(item);
            if (realItem.type === this.TYPES.portofolio) {
                localStorage.setItem("patrimoine", JSON.stringify({
                    id: realItem.staticId,
                    name: realItem.name,
                    buildings: realItem.categories
                }));
                // localStorage.removeItem("idBuilding")
                // sessionStorage.removeItem('idBuilding');
                portofolioId = realItem.staticId;
            } else if (realItem.type === this.TYPES.building) {
                // localStorage.setItem('idBuilding', realItem.staticId);
                // sessionStorage.setItem('idBuilding', realItem.staticId);
                portofolioId = realItem.parents[0];
                buildingId = realItem.staticId;
            }
            localStorage.setItem("idPortofolio", portofolioId);
            if (!buildingId) {
                localStorage.removeItem("idBuilding");
                sessionStorage.removeItem("idBuilding");
            } else {
                localStorage.setItem("idBuilding", buildingId);
                sessionStorage.setItem("idBuilding", buildingId);
            }
            console.log("action du portfolio", portofolioId);
            console.log("action du batiment", buildingId);
            this.$emit("selected", {
                portofolioId,
                buildingId
            });
        },
        close () {
            this.openSpaceSelector = false;
        },
        getInfos (item) {
            return this.portofolios.reduce((temp, portofolio)=>{
                if (portofolio.id === item.staticId) temp = {
                    name: portofolio.name,
                    type: this.TYPES.portofolio,
                    staticId: portofolio.id,
                    categories: portofolio.buildings
                };
                else {
                    const found = portofolio.buildings.find((el)=>el.id === item.staticId);
                    if (found) temp = {
                        type: this.TYPES.building,
                        staticId: found.id,
                        name: found.name,
                        parents: [
                            portofolio.id
                        ]
                    };
                }
                return temp;
            }, undefined);
        }
    },
    computed: {
        ...(0, _vuex.mapState)("appDataStore", [
            "selectedPortofolio"
        ])
    },
    watch: {
        selected () {
            this.$emit("selected", this.selected);
        },
        portofolios () {
            const element = this.selectedPortofolio || this.portofolios[0];
            if (Object.keys(this.selectedZone).length === 1 && element) {
                this.selectedZone = {
                    platformId: "",
                    name: element.name,
                    staticId: element.id || element.staticId,
                    categories: [],
                    color: "#FFFFFF",
                    dynamicId: 0,
                    type: this.TYPES.portofolio,
                    level: 0,
                    isOpen: true,
                    loading: false,
                    patrimoineId: "",
                    parents: [],
                    isLastInGrp: true,
                    drawLink: [],
                    haveChildren: true
                };
                this.getSelectedItem(this.selectedZone);
            }
        }
    }
};
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../store/appDataStore":"6b0bJ","vuex":"ccMRg","../../global-components":"em1cG","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"6b0bJ":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SET_USER_APPS", ()=>SET_USER_APPS);
parcelHelpers.export(exports, "SET_USER_BOS", ()=>SET_USER_BOS);
parcelHelpers.export(exports, "SET_USER_INFO", ()=>SET_USER_INFO);
parcelHelpers.export(exports, "SET_AND_FORMAT_APPS", ()=>SET_AND_FORMAT_APPS);
parcelHelpers.export(exports, "SET_SELECTED_APP", ()=>SET_SELECTED_APP);
parcelHelpers.export(exports, "SET_PORTOFOLIOS", ()=>SET_PORTOFOLIOS);
parcelHelpers.export(exports, "SELECT_PORTOFOLIO", ()=>SELECT_PORTOFOLIO);
parcelHelpers.export(exports, "ADD_FAVORITE_APP", ()=>ADD_FAVORITE_APP);
parcelHelpers.export(exports, "SET_FAVORITE_APP", ()=>SET_FAVORITE_APP);
parcelHelpers.export(exports, "DELETE_FAVORITE_APP", ()=>DELETE_FAVORITE_APP);
parcelHelpers.export(exports, "appDataStore", ()=>appDataStore);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _userData = require("../requests/userData");
const SET_USER_APPS = "SET_USER_APPS";
const SET_USER_BOS = "SET_USER_BOS";
const SET_USER_INFO = "SET_USER_INFO";
const SET_AND_FORMAT_APPS = "SET_AND_FORMAT_APPS";
const SET_SELECTED_APP = "SET_SELECTED_APP";
const SET_PORTOFOLIOS = "SET_PORTOFOLIOS";
const SELECT_PORTOFOLIO = "SELECT_PORTOFOLIO";
const ADD_FAVORITE_APP = "ADD_FAVORITE_APP";
const SET_FAVORITE_APP = "SET_FAVORITE_APP";
const DELETE_FAVORITE_APP = "DELETE_FAVORITE_APP";
const names = {
    apps: "Applications"
};
function classifyByCategory(apps) {
    const obj = {};
    apps.forEach((data)=>{
        const categoryId = data.categoryName.toLowerCase();
        if (!obj[categoryId]) obj[categoryId] = {
            id: categoryId,
            name: data.categoryName,
            apps: []
        };
        obj[categoryId].apps.push(data);
    });
    return Array.from(Object.values(obj));
}
function classifyByCategoryAndGroup(apps, favoriteApps = []) {
    let categories = classifyByCategory(apps);
    categories.unshift({
        name: "Favoris",
        id: "favoris",
        apps: favoriteApps
    }); // Ajouter la categorie favorites
    const groups = {};
    const data = categories.map(({ name , id , apps  })=>{
        let t = {
            name,
            id
        };
        apps.forEach((el)=>{
            // const groupId = el.groupName.toLowerCase();
            const groupId = "Applications";
            if (!t[groupId]) {
                t[groupId] = [];
                // groups[groupId] = { name: el.groupName, id: groupId }
                groups[groupId] = {
                    name: "Applications",
                    id: groupId
                };
            }
            t[groupId].push(el);
        });
        return t;
    });
    return {
        groups: Array.from(Object.values(groups)),
        data
    };
}
function reinitFavoris(old_list, newList) {
    if (!newList || !old_list) return [];
    // re-init favorites
    return old_list.map((el)=>{
        if (el.value === "favoris") el.Applications = newList;
        return el;
    });
}
const appsFormattedMap = new Map();
let inProcess = false;
const appDataStore = {
    namespaced: true,
    state: {
        selectedPortofolio: undefined,
        portofolios: undefined,
        spaceSelected: "",
        appSelected: undefined,
        appsDisplayed: [],
        pamApps: [],
        bos: [],
        appsFormatted: undefined,
        userInfo: {},
        _privateData: {
            userInfoIsSet: false,
            appsIsSet: false
        },
        favoriteApps: []
    },
    mutations: {
        [SELECT_PORTOFOLIO] (state, playload) {
            state.selectedPortofolio = playload;
        },
        [SET_PORTOFOLIOS] (state, playload) {
            state.portofolios = playload;
        },
        [SET_USER_INFO] (state, playload) {
            state.userInfo = playload;
            state._privateData.userInfoIsSet = true;
        },
        [SET_AND_FORMAT_APPS] (state, { apps , appsFormatted  }) {
            state.appsDisplayed = apps;
            state.appsFormatted = appsFormatted;
        },
        [SET_SELECTED_APP] (state, playload) {
            state.appSelected = playload;
        },
        [ADD_FAVORITE_APP] (state, playload) {
            state.favoriteApps = [
                ...state.favoriteApps,
                ...playload
            ];
            // re-init favorites
            if (state.appsFormatted?.data) state.appsFormatted.data = reinitFavoris(state.appsFormatted.data, state.favoriteApps);
        },
        [SET_FAVORITE_APP] (state, playload) {
            state.favoriteApps = playload;
            // re-init favorites
            if (state.appsFormatted?.data) state.appsFormatted.data = reinitFavoris(state.appsFormatted.data, state.favoriteApps);
        },
        [DELETE_FAVORITE_APP] (state, playload) {
            const obj = {};
            playload.forEach((el)=>obj[el.id] = el);
            state.favoriteApps = state.favoriteApps.filter((el)=>!obj[el.id]);
            if (state.appsFormatted?.data) state.appsFormatted.data = reinitFavoris(state.appsFormatted.data, state.favoriteApps);
        }
    },
    actions: {
        async getPortofolios ({ commit , dispatch , state  }) {
            try {
                const profileId = await dispatch("getProfileId");
                const portofolios = await (0, _userData.getPortofolios)(profileId);
                commit(SET_PORTOFOLIOS, portofolios);
            } catch (error) {}
        },
        getProfileId () {
            if (localStorage.getItem("profileId")) return Promise.resolve(localStorage.getItem("profileId"));
        // send request
        },
        getUserInfo ({ commit , state  }) {
            if (state._privateData.userInfoIsSet) return state.userInfo;
            let userInfo = {};
            const storage = localStorage.getItem("user");
            if (storage) userInfo = JSON.parse(atob(storage));
            //send request;
            commit(SET_USER_INFO, userInfo);
            return userInfo;
        },
        async selectSpace ({ commit , dispatch , state  }, data) {
            if (!state.portofolios) await dispatch("getPortofolios");
            console.log(data, "dataa action");
            let apps = [];
            const portofolio = state.portofolios.find((el)=>el.id === data.portofolioId);
            if (portofolio && !data.buildingId) {
                apps = portofolio.apps.map((el)=>{
                    el.parent = {
                        portofolioId: data.portofolioId,
                        buildingId: data.buildingId
                    };
                    return el;
                });
                state.spaceSelected = data.portofolioId;
            } else if (portofolio && data.buildingId) {
                const building = portofolio.buildings.find((el)=>el.id === data.buildingId);
                if (building) {
                    state.spaceSelected = data.buildingId;
                    apps = building.apps.map((el)=>{
                        el.parent = {
                            portofolioId: data.portofolioId,
                            buildingId: data.buildingId
                        };
                        return el;
                    });
                }
            }
            const favoris = await dispatch("getFavoriteApps");
            let appsFormatted = classifyByCategoryAndGroup(apps, favoris);
            commit(SET_AND_FORMAT_APPS, {
                apps,
                appsFormatted
            });
        },
        async addToFavoriteApps ({ commit , state , getters  }, appIds) {
            const data = {
                portofolioId: getters.getPortofolioId,
                buildingId: getters.getBuildingId
            };
            // if (!data.portofolioId) { }
            const apps = await (0, _userData.addAppToFavorite)(appIds, data);
            commit(ADD_FAVORITE_APP, apps);
        },
        async getFavoriteApps ({ commit , getters  }) {
            const data = {
                portofolioId: getters.getPortofolioId,
                buildingId: getters.getBuildingId
            };
            const apps = await (0, _userData.getFavoriteApps)(data);
            commit(SET_FAVORITE_APP, apps);
            return apps;
        },
        async deleteFavoriteApps ({ commit , getters  }, appIds) {
            const data = {
                portofolioId: getters.getPortofolioId,
                buildingId: getters.getBuildingId
            };
            const apps = await (0, _userData.removeAppFromFavorite)(appIds, data);
            commit(DELETE_FAVORITE_APP, apps);
        }
    },
    getters: {
        getPortofolioId (state) {
            console.warn("state action ", state.selectedPortofolio);
            if (!state.selectedPortofolio) return;
            if (state.selectedPortofolio.type === "building" && state.selectedPortofolio.parents) // return state.selectedPortofolio.parents[0];
            return state.selectedPortofolio.staticId;
            if (state.selectedPortofolio.type === "portofolio") return state.selectedPortofolio.staticId;
        },
        getBuildingId (state) {
            if (!state.selectedPortofolio) return;
            if (state.selectedPortofolio.type === "building") return state.selectedPortofolio.staticId;
        }
    }
};

},{"../requests/userData":"dONA1","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"em1cG":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
/*
 * Copyright 2023 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _spaceSelector = require("./SpaceSelector");
parcelHelpers.exportAll(_spaceSelector, exports);

},{"./SpaceSelector":"4Pxlc","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"jpEO9":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _vm.portofolios ? _c("div", {
        staticClass: "headerSelect"
    }, [
        _c("space-selector", {
            ref: "space-selector",
            attrs: {
                "open": _vm.openSpaceSelector,
                "maxDepth": 1,
                "GetChildrenFct": _vm.onSpaceSelectOpen,
                "value": _vm.selectedZone,
                "isMobile": _vm.isMobile
            },
            on: {
                "update:open": function($event) {
                    _vm.openSpaceSelector = $event;
                },
                "input": _vm.getSelectedItem
            }
        })
    ], 1) : _vm._e();
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"i9XuU":[function() {},{}],"kIyXj":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"b7vMb":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("v-container", {
        staticClass: "homeContainer",
        attrs: {
            "fluid": ""
        },
        on: {
            "click": function($event) {
                $event.stopPropagation();
                return _vm.closeSelect.apply(null, arguments);
            }
        }
    }, [
        _c("div", {
            staticClass: "header"
        }, [
            _c("div", {
                staticClass: "nav"
            }, [
                _c("NavBar", {
                    attrs: {
                        "isMobile": _vm.isMobile
                    }
                })
            ], 1),
            _vm._v(" "),
            _c("div", {
                staticClass: "select"
            }, [
                _c("select-component", {
                    ref: "select-component",
                    attrs: {
                        "isMobile": _vm.isMobile,
                        "portofolios": _vm.portofolios
                    },
                    on: {
                        "selected": _vm.changeApps
                    }
                })
            ], 1)
        ]),
        _vm._v(" "),
        _c("router-view", {
            staticClass: "content",
            attrs: {
                "isMobile": _vm.isMobile
            }
        })
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"3GQRE":[function() {},{}],"aPGjP":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"3sgqx":[function(require,module,exports) {
module.exports = Promise.all([
    require("./helpers/browser/css-loader")(require("./helpers/bundle-url").getBundleURL("4wOkc") + require("./helpers/bundle-manifest").resolve("53ivn")),
    require("./helpers/browser/css-loader")(require("./helpers/bundle-url").getBundleURL("4wOkc") + require("./helpers/bundle-manifest").resolve("5ixwV")),
    require("./helpers/browser/js-loader")(require("./helpers/bundle-url").getBundleURL("4wOkc") + require("./helpers/bundle-manifest").resolve("elXhd"))
]).then(()=>module.bundle.root("hf8BV"));

},{"./helpers/browser/css-loader":"jhZtD","./helpers/bundle-url":"jkqJ4","./helpers/bundle-manifest":"8Y9me","./helpers/browser/js-loader":"3dDkg"}],"jhZtD":[function(require,module,exports) {
"use strict";
var cacheLoader = require("../cacheLoader");
module.exports = cacheLoader(function(bundle) {
    return new Promise(function(resolve, reject) {
        // Don't insert the same link element twice (e.g. if it was already in the HTML)
        var existingLinks = document.getElementsByTagName("link");
        if ([].concat(existingLinks).some(function isCurrentBundle(link) {
            return link.href === bundle && link.rel.indexOf("stylesheet") > -1;
        })) {
            resolve();
            return;
        }
        var link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = bundle;
        link.onerror = function(e) {
            link.onerror = link.onload = null;
            link.remove();
            reject(e);
        };
        link.onload = function() {
            link.onerror = link.onload = null;
            resolve();
        };
        document.getElementsByTagName("head")[0].appendChild(link);
    });
});

},{"../cacheLoader":"khH0r"}],"khH0r":[function(require,module,exports) {
"use strict";
var cachedBundles = {};
var cachedPreloads = {};
var cachedPrefetches = {};
function getCache(type) {
    switch(type){
        case "preload":
            return cachedPreloads;
        case "prefetch":
            return cachedPrefetches;
        default:
            return cachedBundles;
    }
}
module.exports = function(loader, type) {
    return function(bundle) {
        var cache = getCache(type);
        if (cache[bundle]) return cache[bundle];
        return cache[bundle] = loader.apply(null, arguments).catch(function(e) {
            delete cache[bundle];
            throw e;
        });
    };
};

},{}],"3dDkg":[function(require,module,exports) {
"use strict";
var cacheLoader = require("../cacheLoader");
module.exports = cacheLoader(function(bundle) {
    return new Promise(function(resolve, reject) {
        // Don't insert the same script twice (e.g. if it was already in the HTML)
        var existingScripts = document.getElementsByTagName("script");
        if ([].concat(existingScripts).some(function isCurrentBundle(script) {
            return script.src === bundle;
        })) {
            resolve();
            return;
        }
        var preloadLink = document.createElement("link");
        preloadLink.href = bundle;
        preloadLink.rel = "preload";
        preloadLink.as = "script";
        document.head.appendChild(preloadLink);
        var script = document.createElement("script");
        script.async = true;
        script.type = "text/javascript";
        script.src = bundle;
        script.onerror = function(e) {
            var error = new TypeError("Failed to fetch dynamically imported module: ".concat(bundle, ". Error: ").concat(e.message));
            script.onerror = script.onload = null;
            script.remove();
            reject(error);
        };
        script.onload = function() {
            script.onerror = script.onload = null;
            resolve();
        };
        document.getElementsByTagName("head")[0].appendChild(script);
    });
});

},{"../cacheLoader":"khH0r"}],"9DSez":[function(require,module,exports) {
module.exports = Promise.all([
    require("./helpers/browser/js-loader")(require("./helpers/bundle-url").getBundleURL("4wOkc") + require("./helpers/bundle-manifest").resolve("9s27O")),
    require("./helpers/browser/css-loader")(require("./helpers/bundle-url").getBundleURL("4wOkc") + require("./helpers/bundle-manifest").resolve("3kKuF")),
    require("./helpers/browser/js-loader")(require("./helpers/bundle-url").getBundleURL("4wOkc") + require("./helpers/bundle-manifest").resolve("jXCzs"))
]).then(()=>module.bundle.root("hhjkK"));

},{"./helpers/browser/js-loader":"3dDkg","./helpers/bundle-url":"jkqJ4","./helpers/bundle-manifest":"8Y9me","./helpers/browser/css-loader":"jhZtD"}],"xP4vH":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 * 
 * This file is part of SpinalCore.
 * 
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 * 
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 * 
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
var _vuex = require("vuex");
var _vuexDefault = parcelHelpers.interopDefault(_vuex);
var _loginStore = require("./loginStore");
var _appDataStore = require("./appDataStore");
(0, _vueDefault.default).use((0, _vuexDefault.default));
exports.default = new (0, _vuexDefault.default).Store({
    modules: {
        logingStore: (0, _loginStore.logingStore),
        appDataStore: (0, _appDataStore.appDataStore)
    }
});

},{"vue":"kjivF","vuex":"ccMRg","./loginStore":"kfT0e","./appDataStore":"6b0bJ","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"kfT0e":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SUCCESS_LOGGED", ()=>SUCCESS_LOGGED);
parcelHelpers.export(exports, "ERROR_LOGGED", ()=>ERROR_LOGGED);
parcelHelpers.export(exports, "logingStore", ()=>logingStore);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 * 
 * This file is part of SpinalCore.
 * 
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 * 
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 * 
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _utils = require("../utils");
var _login = require("../requests/login");
const SUCCESS_LOGGED = "SUCCESS_LOGGED";
const ERROR_LOGGED = "ERROR_LOGGED";
const logingStore = {
    namespaced: true,
    state: {
        data: {}
    },
    mutations: {
        [SUCCESS_LOGGED] (state, playload) {
            if (playload.logged) state.data = playload.data || {};
        }
    },
    actions: {
        async logUser ({ commit  }, userData) {
            try {
                const data = await (0, _login.loginRequest)(userData);
                commit(SUCCESS_LOGGED, {
                    data,
                    logged: true
                });
                return true;
            } catch (error) {
                console.error(error);
                commit(SUCCESS_LOGGED, {
                    logged: false
                });
                return false;
            }
        },
        storeCookie ({ state  }, vueCookieInstance) {
            // vueCookieInstance.set('token', state.data.token, { expires: state.data.expieres });
            (0, _utils.saveToLocalStorage)(state.data);
        },
        clearLocalStorage () {
            (0, _utils.clearLocalStorage)();
        }
    },
    getters: {}
};

},{"../utils":"4Y0g6","../requests/login":"6aRMh","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"6aRMh":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "loginRequest", ()=>loginRequest);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _axios = require("axios");
var _axiosDefault = parcelHelpers.interopDefault(_axios);
var _ = require(".");
const endpoint = "/api/v1/pam";
const host = ((0, _.SERVER_BASE_URL) || "").replace(`/\/$/`, (el)=>"");
const baseURL = host.match(new RegExp(endpoint)) ? host : host + endpoint;
function loginRequest(userData) {
    return (0, _axiosDefault.default).post(`${baseURL}/auth`, userData).then((result)=>{
        return result.data;
    });
}

},{"axios":"9qbW2",".":"8Ir1L","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"hYzMD":[function(require,module,exports) {
(function() {
    Number.isInteger = Number.isInteger || function(value) {
        return typeof value === "number" && isFinite(value) && Math.floor(value) === value;
    };
    var Cookie = require("tiny-cookie");
    var VueCookie = {
        install: function(Vue) {
            Vue.prototype.$cookie = this;
            Vue.cookie = this;
        },
        set: function(name, value, daysOrOptions) {
            var opts = daysOrOptions;
            if (Number.isInteger(daysOrOptions)) opts = {
                expires: daysOrOptions
            };
            return Cookie.set(name, value, opts);
        },
        get: function(name) {
            return Cookie.get(name);
        },
        delete: function(name, options) {
            var opts = {
                expires: -1
            };
            if (options !== undefined) opts = Object.assign(options, opts);
            this.set(name, "", opts);
        }
    };
    module.exports = VueCookie;
})();

},{"tiny-cookie":"2MscC"}],"2MscC":[function(require,module,exports) {
/*!
 * tiny-cookie - A tiny cookie manipulation plugin
 * https://github.com/Alex1990/tiny-cookie
 * Under the MIT license | (c) Alex Chao
 */ !function(root, factory) {
    // Uses CommonJS, AMD or browser global to create a jQuery plugin.
    // See: https://github.com/umdjs/umd
    if (typeof define === "function" && define.amd) // Expose this plugin as an AMD module. Register an anonymous module.
    define(factory);
    else // Node/CommonJS module
    module.exports = factory();
}(this, function() {
    "use strict";
    // The public function which can get/set/remove cookie.
    function Cookie(key, value, opts) {
        if (value === void 0) return Cookie.get(key);
        else if (value === null) Cookie.remove(key);
        else Cookie.set(key, value, opts);
    }
    // Check if the cookie is enabled.
    Cookie.enabled = function() {
        var key = "__test_key";
        var enabled;
        document.cookie = key + "=1";
        enabled = !!document.cookie;
        if (enabled) Cookie.remove(key);
        return enabled;
    };
    // Get the cookie value by the key.
    Cookie.get = function(key, raw) {
        if (typeof key !== "string" || !key) return null;
        key = "(?:^|; )" + escapeRe(key) + "(?:=([^;]*?))?(?:;|$)";
        var reKey = new RegExp(key);
        var res = reKey.exec(document.cookie);
        return res !== null ? raw ? res[1] : decodeURIComponent(res[1]) : null;
    };
    // Get the cookie's value without decoding.
    Cookie.getRaw = function(key) {
        return Cookie.get(key, true);
    };
    // Set a cookie.
    Cookie.set = function(key, value, raw, opts) {
        if (raw !== true) {
            opts = raw;
            raw = false;
        }
        opts = opts ? convert(opts) : convert({});
        var cookie = key + "=" + (raw ? value : encodeURIComponent(value)) + opts;
        document.cookie = cookie;
    };
    // Set a cookie without encoding the value.
    Cookie.setRaw = function(key, value, opts) {
        Cookie.set(key, value, true, opts);
    };
    // Remove a cookie by the specified key.
    Cookie.remove = function(key) {
        Cookie.set(key, "a", {
            expires: new Date()
        });
    };
    // Helper function
    // ---------------
    // Escape special characters.
    function escapeRe(str) {
        return str.replace(/[.*+?^$|[\](){}\\-]/g, "\\$&");
    }
    // Convert an object to a cookie option string.
    function convert(opts) {
        var res = "";
        for(var p in opts)if (opts.hasOwnProperty(p)) {
            if (p === "expires") {
                var expires = opts[p];
                if (typeof expires !== "object") {
                    expires += typeof expires === "number" ? "D" : "";
                    expires = computeExpires(expires);
                }
                opts[p] = expires.toUTCString();
            }
            if (p === "secure") {
                if (opts[p]) res += ";" + p;
                continue;
            }
            res += ";" + p + "=" + opts[p];
        }
        if (!opts.hasOwnProperty("path")) res += ";path=/";
        return res;
    }
    // Return a future date by the given string.
    function computeExpires(str) {
        var expires = new Date();
        var lastCh = str.charAt(str.length - 1);
        var value = parseInt(str, 10);
        switch(lastCh){
            case "Y":
                expires.setFullYear(expires.getFullYear() + value);
                break;
            case "M":
                expires.setMonth(expires.getMonth() + value);
                break;
            case "D":
                expires.setDate(expires.getDate() + value);
                break;
            case "h":
                expires.setHours(expires.getHours() + value);
                break;
            case "m":
                expires.setMinutes(expires.getMinutes() + value);
                break;
            case "s":
                expires.setSeconds(expires.getSeconds() + value);
                break;
            default:
                expires = new Date(str);
        }
        return expires;
    }
    return Cookie;
});

},{}],"ccoPX":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./App.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./App.vue").render;
    script.staticRenderFns = require("template:./App.vue").staticRenderFns;
    script._scopeId = "data-v-1b0acb";
    script.__cssModules = require("style:./App.vue").default;
    require("custom:./App.vue").default(script);
    script.__scopeId = "data-v-1b0acb";
    script.__file = "App.vue";
};
initialize();
exports.default = script;

},{"script:./App.vue":"fJIR0","template:./App.vue":"5ojf6","style:./App.vue":"hZoI5","custom:./App.vue":"AXbBO","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"fJIR0":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _tsDecorateMjs = require("@swc/helpers/src/_ts_decorate.mjs");
var _tsDecorateMjsDefault = parcelHelpers.interopDefault(_tsDecorateMjs);
var _vuePropertyDecorator = require("vue-property-decorator");
let App = class App extends (0, _vuePropertyDecorator.Vue) {
};
App = (0, _tsDecorateMjsDefault.default)([
    (0, _vuePropertyDecorator.Component)
], App);
var scriptExports = App;
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@swc/helpers/src/_ts_decorate.mjs":"ksIVK","vue-property-decorator":"iwmLK","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"5ojf6":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("v-app", {
        staticClass: "apps"
    }, [
        _c("v-main", [
            _c("router-view")
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"hZoI5":[function() {},{}],"AXbBO":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"2bdJo":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
/*
 * Copyright 2022 SpinalCom - www.spinalcom.com
 * 
 * This file is part of SpinalCore.
 * 
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 * 
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 * 
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
var _store = require("../store");
var _storeDefault = parcelHelpers.interopDefault(_store);
const EventBus = new (0, _vueDefault.default)({
    store: (0, _storeDefault.default)
});
window.document.addEventListener("iframe_event", ({ detail: { eventName , data  }  })=>{
    EventBus.$emit(eventName, data);
}, false);
EventBus.$on("reload_portofolio", ()=>{
    EventBus.$store.dispatch("appDataStore/getPortofolios");
});
exports.default = EventBus;

},{"vue":"kjivF","../store":"xP4vH","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"3R6lQ":[function() {},{}],"7UmA6":[function() {},{}],"8aAZ7":[function() {},{}],"eXINW":[function() {},{}]},["2drtI","6qBNO"], "6qBNO", "parcelRequire2d5a")

//# sourceMappingURL=index.968516aa.js.map
