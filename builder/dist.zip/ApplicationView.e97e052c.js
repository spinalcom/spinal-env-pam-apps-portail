// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"hf8BV":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./ApplicationView.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./ApplicationView.vue").render;
    script.staticRenderFns = require("template:./ApplicationView.vue").staticRenderFns;
    script._scopeId = "data-v-83ddb4";
    script.__cssModules = require("style:./ApplicationView.vue").default;
    require("custom:./ApplicationView.vue").default(script);
    script.__scopeId = "data-v-83ddb4";
    script.__file = "ApplicationView.vue";
};
initialize();
exports.default = script;

},{"script:./ApplicationView.vue":"lfQpD","template:./ApplicationView.vue":"310SH","style:./ApplicationView.vue":"4qBUw","custom:./ApplicationView.vue":"c5dmX","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"lfQpD":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _tsDecorateMjs = require("@swc/helpers/src/_ts_decorate.mjs");
var _tsDecorateMjsDefault = parcelHelpers.interopDefault(_tsDecorateMjs);
var _navVue = require("../components/nav.vue");
var _navVueDefault = parcelHelpers.interopDefault(_navVue);
var _appDataStore = require("../store/appDataStore");
var _vuePropertyDecorator = require("vue-property-decorator");
var _viewerIframeVue = require("./ViewerIframe.vue");
var _viewerIframeVueDefault = parcelHelpers.interopDefault(_viewerIframeVue);
let ApplicationView = class ApplicationView extends (0, _vuePropertyDecorator.Vue) {
    appSelected = null;
    showViewer = false;
    appPath = null;
    inDrag = false;
    async mounted() {
        window.router = this.$route;
        await this.initApp();
    }
    async initApp() {
        // console.log("initApp");
        const { appId , portofolioId , buildingId  } = this.getAppInfo();
        console.log(appId, portofolioId, buildingId);
        // this.appPath = this.getAppPath();
        if (!appId) return;
        await this.$store.dispatch(`appDataStore/selectSpace`, {
            portofolioId,
            buildingId
        });
        console.log("hello from appView");
        this.appSelected = this.getAppSelected(appId);
        this.$store.commit(`appDataStore/${(0, _appDataStore.SET_SELECTED_APP)}`, this.appSelected);
        this.appPath = this.getAppPath();
    // await this.$store.dispatch(
    //   `appDataStore/selectSpace`,
    //   (<any>this.appSelected).parent
    // );
    // this.$store.commit(`appDataStore/${SET_SELECTED_APP}`, this.appSelected);
    }
    getAppInfo() {
        try {
            const { query  } = this.$route;
            const appId = query.app;
            const portofolioId = localStorage.getItem("idPortofolio");
            const buildingId = localStorage.getItem("idBuilding");
            return {
                appId,
                portofolioId,
                buildingId
            };
        } catch (error) {}
    }
    getAppPath() {
        if (!this.appSelected) return;
        if (this.appSelected.hasViewer) {
            this.showViewer = true;
            return `/micro-apps/spinal-env-pam-dataview`;
        }
        return `/micro-apps/${this.appSelected.packageName}`;
    }
    getAppSelected(appId) {
        const appsDisplayed = this.$store.state.appDataStore.appsDisplayed;
        console.log("mes application", appsDisplayed);
        return appsDisplayed.find((app)=>app.name === appId);
    }
    watchRoute() {
        this.initApp();
    }
    get isMobile() {
        const breakpoint = this.$vuetify.breakpoint.name;
        if ([
            "xs",
            "sm"
        ].indexOf(breakpoint) !== -1) return true;
        return false;
    }
};
(0, _tsDecorateMjsDefault.default)([
    (0, _vuePropertyDecorator.Watch)("$route")
], ApplicationView.prototype, "watchRoute", null);
ApplicationView = (0, _tsDecorateMjsDefault.default)([
    (0, _vuePropertyDecorator.Component)({
        components: {
            NavBar: (0, _navVueDefault.default),
            ViewerIFrame: (0, _viewerIframeVueDefault.default)
        }
    })
], ApplicationView);
var scriptExports = ApplicationView;
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@swc/helpers/src/_ts_decorate.mjs":"ksIVK","../components/nav.vue":"hAOMv","../store/appDataStore":"6b0bJ","vue-property-decorator":"iwmLK","./ViewerIframe.vue":"69Y8M","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"69Y8M":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("script:./ViewerIframe.vue");
    if (script.__esModule) script = script.default;
    script.render = require("template:./ViewerIframe.vue").render;
    script.staticRenderFns = require("template:./ViewerIframe.vue").staticRenderFns;
    script._scopeId = "data-v-9a2108";
    require("custom:./ViewerIframe.vue").default(script);
    script.__scopeId = "data-v-9a2108";
    script.__file = "ViewerIframe.vue";
};
initialize();
exports.default = script;

},{"script:./ViewerIframe.vue":"9qh1n","template:./ViewerIframe.vue":"eBdEr","custom:./ViewerIframe.vue":"964Du","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"9qh1n":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _tsDecorateMjs = require("@swc/helpers/src/_ts_decorate.mjs");
var _tsDecorateMjsDefault = parcelHelpers.interopDefault(_tsDecorateMjs);
var _vuePropertyDecorator = require("vue-property-decorator");
let ViewerIFrame = class ViewerIFrame extends (0, _vuePropertyDecorator.Vue) {
    mounted() {
        this.setUpEvent();
        this.checkSetUpInter = setInterval(()=>{
            this.setUpEvent();
        }, 200);
    }
    setUpEvent() {
        // @ts-ignore
        const viewerIframeWindow = this.$refs.viewerIframe?.contentWindow;
        if (viewerIframeWindow && viewerIframeWindow.VIEWER_IFRAME_EVENT_SERUP === undefined) {
            viewerIframeWindow.VIEWER_IFRAME_EVENT_SERUP = true;
            viewerIframeWindow.addEventListener("mousedown", this.onMouseDown, true);
            viewerIframeWindow.addEventListener("mouseup", this.onMouseUp, true);
        }
    }
    beforeDestroy() {
        clearInterval(this.checkSetUpInter);
        // @ts-ignore
        const viewerIframeWindow = this.$refs.viewerIframe?.contentWindow;
        viewerIframeWindow?.removeEventListener("mousedown", this.onMouseDown, true);
        viewerIframeWindow?.removeEventListener("mouseup", this.onMouseUp, true);
    }
    onMouseDown = (()=>{
        this.$emit("update:inDrag", true);
    }).bind(this);
    onMouseUp = (()=>{
        this.$emit("update:inDrag", false);
    }).bind(this);
};
(0, _tsDecorateMjsDefault.default)([
    (0, _vuePropertyDecorator.Prop)({
        type: Boolean,
        required: true
    })
], ViewerIFrame.prototype, "inDrag", void 0);
ViewerIFrame = (0, _tsDecorateMjsDefault.default)([
    (0, _vuePropertyDecorator.Component)
], ViewerIFrame);
var scriptExports = ViewerIFrame;
var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@swc/helpers/src/_ts_decorate.mjs":"ksIVK","vue-property-decorator":"iwmLK","@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"eBdEr":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("iframe", {
        ref: "viewerIframe",
        attrs: {
            "src": "micro-apps/spinal-env-pam-viewer/index.html"
        }
    });
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"964Du":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}],"310SH":[function(require,module,exports) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("v-container", {
        staticClass: "appLoadContainer",
        attrs: {
            "fluid": ""
        }
    }, [
        _c("NavBar", {
            staticClass: "navbar",
            attrs: {
                "isMobile": _vm.isMobile
            }
        }),
        _vm._v(" "),
        _vm.showViewer ? _c("ViewerIFrame", {
            staticClass: "iframeViewerContainer",
            attrs: {
                "inDrag": _vm.inDrag
            },
            on: {
                "update:inDrag": function($event) {
                    _vm.inDrag = $event;
                }
            }
        }) : _vm._e(),
        _vm._v(" "),
        _vm.appPath ? _c("iframe", {
            staticClass: "iframeContainer",
            class: {
                "disabled-event": _vm.inDrag
            },
            attrs: {
                "src": _vm.appPath
            }
        }) : _c("div", {
            staticClass: "iframeContainer notFoundDiv"
        }, [
            _c("h1", {
                staticClass: "code"
            }, [
                _vm._v("404")
            ]),
            _vm._v(" "),
            _c("h1", [
                _vm._v("No app found")
            ])
        ])
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"4qBUw":[function() {},{}],"c5dmX":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5oERU"}]},[], null, "parcelRequire2d5a")

//# sourceMappingURL=ApplicationView.e97e052c.js.map
